export type WatchdogJobStatus =
  | "DISCOVERED" | "WAITING_FOR_FILES" | "STABILIZING" | "PREFLIGHT"
  | "READY" | "PROCESSING" | "POST_VALIDATING" | "COMPLETED"
  | "RETRY_WAIT" | "REJECTED_DATA" | "BLOCKED_PROFILE" | "FAILED" | "QUARANTINED";

export interface ConditionAssetHealth {
  asset_id: string;
  name: string;
  type?: string | null;
  status?: string | null;
  health_score?: number | null;
  current_health_score?: number | null;
  vibration_health_score?: number | null;
  overall_health_score?: number | null;
  diagnostic_validity?: string | null;
  assessment_at?: string | null;
  rul?: number | null;
}

export interface ConditionOverview {
  assets: {
    asset_count?: number;
    online_count?: number;
    average_health?: number | null;
    critical_count?: number;
    warning_count?: number;
  };
  latest_run?: Record<string, unknown> | null;
  asset_health: ConditionAssetHealth[];
  active_faults: { mcsa: Record<string, unknown>[]; vibration: Record<string, unknown>[] };
  rul: { estimate_count?: number; available_count?: number; minimum_rul_hours?: number | null };
  watchdog: {
    online: boolean;
    jobs: Record<string, number>;
    instances: Record<string, unknown>[];
    recent_jobs: WatchdogJob[];
    reason?: string;
  };
}

export interface WatchdogJob {
  id: string;
  asset_id?: string | null;
  status: WatchdogJobStatus | string;
  attempts?: number;
  max_attempts?: number;
  run_id?: string | null;
  discovered_at?: string;
  started_at?: string | null;
  finished_at?: string | null;
  error_code?: string | null;
  error_message?: string | null;
  output_dir?: string | null;
  preflight_json?: unknown;
  post_validation_json?: unknown;
  summary_json?: unknown;
}

export interface AssetConditionSnapshot {
  asset: Record<string, unknown>;
  health?: Record<string, unknown> | null;
  mcsa?: (Record<string, unknown> & { faults?: Record<string, unknown>[] }) | null;
  vibration: (Record<string, unknown> & { faults?: Record<string, unknown>[] })[];
  rul: Record<string, unknown>[];
  processing?: Record<string, unknown> | null;
  energy?: Record<string, unknown> | null;
  sensors: Record<string, unknown>[];
}
