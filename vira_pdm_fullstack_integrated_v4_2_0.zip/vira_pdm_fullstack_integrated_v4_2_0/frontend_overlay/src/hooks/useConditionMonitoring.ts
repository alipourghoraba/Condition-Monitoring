import { useQuery } from "@tanstack/react-query";
import { conditionApi } from "@/lib/condition-monitoring-api";

export function useConditionOverview() {
  return useQuery({
    queryKey: ["condition", "overview"],
    queryFn: conditionApi.overview,
    refetchInterval: 2500,
    staleTime: 1000,
  });
}

export function useAssetConditionSnapshot(assetId?: string | null) {
  return useQuery({
    queryKey: ["condition", "snapshot", assetId],
    queryFn: () => conditionApi.snapshot(assetId!),
    enabled: Boolean(assetId),
    refetchInterval: 5000,
  });
}
