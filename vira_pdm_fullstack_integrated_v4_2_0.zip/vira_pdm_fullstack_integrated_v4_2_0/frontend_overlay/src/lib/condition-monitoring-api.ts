import type { AssetConditionSnapshot, ConditionOverview, WatchdogJob } from "@/types/condition-monitoring";

const API = (import.meta.env.VITE_API_URL || "/v1").replace(/\/$/, "");

function token(): string | null {
  const explicitKey = import.meta.env.VITE_AUTH_TOKEN_KEY;
  if (explicitKey) {
    const value = localStorage.getItem(explicitKey);
    if (value) return value;
  }
  for (const key of ["access_token", "accessToken", "vira_access_token", "token"]) {
    const value = localStorage.getItem(key);
    if (value) return value;
  }
  // Last-resort compatibility with existing auth implementations that choose a custom key.
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i) || "";
    if (/access.*token|token.*access/i.test(key)) {
      const value = localStorage.getItem(key);
      if (value) return value;
    }
  }
  return null;
}

async function get<T>(path: string): Promise<T> {
  const headers: Record<string, string> = { Accept: "application/json" };
  const t = token();
  if (t) headers.Authorization = `Bearer ${t}`;
  const response = await fetch(`${API}${path}`, { headers, credentials: "include" });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`${response.status} ${response.statusText}: ${body}`);
  }
  return response.json() as Promise<T>;
}

export const conditionApi = {
  overview: () => get<ConditionOverview>("/condition/overview"),
  snapshot: (assetId: string) => get<AssetConditionSnapshot>(`/condition/assets/${encodeURIComponent(assetId)}/snapshot`),
  mcsa: (assetId: string, limit = 20) => get<Record<string, unknown>[]>(`/condition/assets/${encodeURIComponent(assetId)}/mcsa?limit=${limit}`),
  vibration: (assetId: string, limit = 20) => get<Record<string, unknown>[]>(`/condition/assets/${encodeURIComponent(assetId)}/vibration?limit=${limit}`),
  rul: (assetId: string, limit = 100) => get<Record<string, unknown>[]>(`/condition/assets/${encodeURIComponent(assetId)}/rul?limit=${limit}`),
  health: (assetId: string, limit = 200) => get<Record<string, unknown>[]>(`/condition/assets/${encodeURIComponent(assetId)}/health?limit=${limit}`),
  runs: (assetId?: string) => get<Record<string, unknown>[]>(`/condition/runs${assetId ? `?asset_id=${encodeURIComponent(assetId)}` : ""}`),
  watchdog: () => get<ConditionOverview["watchdog"]>("/condition/watchdog"),
  watchdogJob: (jobId: string) => get<WatchdogJob>(`/condition/watchdog/jobs/${encodeURIComponent(jobId)}`),
};
