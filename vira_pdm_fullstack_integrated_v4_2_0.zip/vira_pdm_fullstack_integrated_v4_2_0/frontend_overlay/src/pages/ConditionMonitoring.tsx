import React, { useEffect, useMemo, useState } from "react";
import { ConditionEngineBadge } from "@/components/ConditionEngineBadge";
import { useAssetConditionSnapshot, useConditionOverview } from "@/hooks/useConditionMonitoring";

const n = (v: unknown, digits = 1) => typeof v === "number" && Number.isFinite(v) ? v.toFixed(digits) : "—";
const s = (v: unknown) => v == null || v === "" ? "—" : String(v);

function Card({ title, value, hint }: { title: string; value: React.ReactNode; hint?: string }) {
  return <div className="rounded-xl border bg-card p-4 shadow-sm"><div className="text-xs text-muted-foreground">{title}</div><div className="mt-1 text-2xl font-semibold">{value}</div>{hint ? <div className="mt-1 text-xs text-muted-foreground">{hint}</div> : null}</div>;
}

export default function ConditionMonitoring() {
  const overview = useConditionOverview();
  const assets = overview.data?.asset_health ?? [];
  const [assetId, setAssetId] = useState<string | null>(null);
  useEffect(() => { if (!assetId && assets.length) setAssetId(assets[0].asset_id); }, [assetId, assets]);
  const snapshot = useAssetConditionSnapshot(assetId);
  const jobs = overview.data?.watchdog?.jobs ?? {};
  const activeFaults = useMemo(() => [ ...(overview.data?.active_faults.mcsa ?? []), ...(overview.data?.active_faults.vibration ?? []) ], [overview.data]);

  if (overview.isLoading) return <div className="p-6">Loading condition-monitoring data…</div>;
  if (overview.error) return <div className="p-6 text-rose-600">{String(overview.error)}</div>;

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-semibold">Condition Monitoring Core</h1><p className="text-sm text-muted-foreground">Live rule-based MCSA, vibration, health, RUL and watchdog execution state.</p></div>
        <ConditionEngineBadge online={Boolean(overview.data?.watchdog.online)} processing={jobs.PROCESSING ?? 0} />
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <Card title="Assets" value={overview.data?.assets.asset_count ?? 0} />
        <Card title="Average health" value={`${n(overview.data?.assets.average_health)}%`} />
        <Card title="Warning assets" value={overview.data?.assets.warning_count ?? 0} />
        <Card title="Critical assets" value={overview.data?.assets.critical_count ?? 0} />
        <Card title="Available RUL estimates" value={overview.data?.rul.available_count ?? 0} hint={`Min: ${n(overview.data?.rul.minimum_rul_hours)} h`} />
      </div>

      <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
        <div className="rounded-xl border bg-card">
          <div className="border-b p-4 font-medium">Assets</div>
          <div className="max-h-[620px] overflow-auto">
            {assets.map(a => <button key={a.asset_id} onClick={() => setAssetId(a.asset_id)} className={`w-full border-b p-3 text-left hover:bg-muted/50 ${assetId === a.asset_id ? "bg-muted" : ""}`}>
              <div className="flex items-center justify-between gap-2"><span className="font-medium">{a.name || a.asset_id}</span><span className="text-sm">{n(a.health_score)}%</span></div>
              <div className="mt-1 text-xs text-muted-foreground">{a.asset_id} · {s(a.diagnostic_validity)}</div>
            </button>)}
          </div>
        </div>

        <div className="space-y-5">
          {!assetId || snapshot.isLoading ? <div className="rounded-xl border p-6">Loading asset snapshot…</div> : snapshot.error ? <div className="rounded-xl border p-6 text-rose-600">{String(snapshot.error)}</div> : snapshot.data ? <>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <Card title="Overall health" value={`${n(snapshot.data.health?.overall_health_score ?? snapshot.data.asset.health_score)}%`} />
              <Card title="Current health" value={`${n(snapshot.data.health?.current_health_score)}%`} />
              <Card title="Vibration health" value={`${n(snapshot.data.health?.vibration_health_score)}%`} />
              <Card title="Processing" value={s(snapshot.data.processing?.status)} hint={s(snapshot.data.processing?.run_id)} />
            </div>

            <div className="rounded-xl border bg-card p-4">
              <h2 className="font-semibold">Latest MCSA diagnosis</h2>
              <div className="mt-3 grid gap-2">
                {(snapshot.data.mcsa?.faults ?? []).slice(0, 8).map((f, i) => <div key={i} className="flex items-start justify-between gap-4 rounded-lg border p-3"><div><div className="font-medium">{s(f.fault_name ?? f.fault_code)}</div><div className="text-xs text-muted-foreground">{s(f.severity)} · coverage {n(f.coverage_pct)}%</div></div><div className="text-right font-semibold">{n(f.evidence_pct)}%</div></div>)}
                {!snapshot.data.mcsa ? <div className="text-sm text-muted-foreground">No MCSA run persisted yet.</div> : null}
              </div>
            </div>

            <div className="rounded-xl border bg-card p-4">
              <h2 className="font-semibold">Vibration diagnosis</h2>
              <div className="mt-3 grid gap-2">
                {snapshot.data.vibration.flatMap(v => (v.faults ?? []).map(f => ({...f, channel: v.channel}))).slice(0, 10).map((f, i) => <div key={i} className="flex items-start justify-between gap-4 rounded-lg border p-3"><div><div className="font-medium">{s(f.fault_name ?? f.fault_code)}</div><div className="text-xs text-muted-foreground">{s(f.channel)} · {s(f.source_method)} · {s(f.severity)}</div></div><div className="font-semibold">{n(f.evidence_score, 3)}</div></div>)}
              </div>
            </div>

            <div className="rounded-xl border bg-card p-4">
              <h2 className="font-semibold">RUL / maintenance horizon</h2>
              <div className="mt-3 overflow-auto"><table className="w-full text-sm"><thead><tr className="text-left text-muted-foreground"><th className="pb-2">Component</th><th>Status</th><th>State</th><th>Damage</th><th>RUL median</th><th>Quality</th></tr></thead><tbody>{snapshot.data.rul.slice(0, 20).map((r, i) => <tr key={i} className="border-t"><td className="py-2">{s(r.component)}</td><td>{s(r.status)}</td><td>{s(r.state)}</td><td>{n(r.damage_index, 3)}</td><td>{r.rul_available ? `${n(r.rul_median_hours)} h` : "Unavailable"}</td><td>{n(r.estimate_quality, 2)}</td></tr>)}</tbody></table></div>
            </div>
          </> : null}
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <div className="rounded-xl border bg-card p-4"><h2 className="font-semibold">Watchdog queue</h2><div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">{Object.entries(jobs).map(([k,v]) => <div key={k} className="rounded-lg border p-2"><div className="text-xs text-muted-foreground">{k}</div><div className="text-xl font-semibold">{v}</div></div>)}</div></div>
        <div className="rounded-xl border bg-card p-4"><h2 className="font-semibold">Active diagnostic evidence</h2><div className="mt-3 space-y-2">{activeFaults.slice(0, 8).map((f,i) => <div key={i} className="rounded-lg border p-2 text-sm"><span className="font-medium">{s(f.fault_name ?? f.fault_code)}</span><span className="ml-2 text-muted-foreground">{s(f.asset_id)} · {s(f.severity)}</span></div>)}{!activeFaults.length ? <div className="text-sm text-muted-foreground">No active warning/critical evidence.</div> : null}</div></div>
      </div>
    </div>
  );
}
