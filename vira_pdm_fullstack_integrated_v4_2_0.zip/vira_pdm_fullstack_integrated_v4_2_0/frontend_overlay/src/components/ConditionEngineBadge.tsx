import React from "react";

export function ConditionEngineBadge({ online, processing = 0 }: { online: boolean; processing?: number }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-medium">
      <span className={`h-2 w-2 rounded-full ${online ? "bg-emerald-500" : "bg-rose-500"}`} />
      {online ? "Rule Engine Online" : "Rule Engine Offline"}
      {processing > 0 ? <span className="text-muted-foreground">· {processing} processing</span> : null}
    </span>
  );
}
