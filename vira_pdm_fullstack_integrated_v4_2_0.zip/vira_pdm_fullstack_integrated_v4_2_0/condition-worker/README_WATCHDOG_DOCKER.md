# Vira Fault Detector v4.1.0 — Production Watchdog + Docker Wrapper

This package wraps the uploaded **Vira Fault Detector v4.1.0 rule-based condition-monitoring core** without rewriting its signal-processing algorithms.

The core still runs through `runtime/run_condition_monitoring_pipeline.py`. The new `condition_service` layer owns capture discovery, data readiness, strict validation, retries, idempotency, watchdog state, health/status APIs, and Docker lifecycle.

## 1. What is included

```text
vira_watchdog_docker_v4_1_0/
├── condition_service/              # new watchdog/service layer
│   ├── api.py                      # /health /ready /status /jobs /metrics
│   ├── bootstrap.py                # data dirs + core DB initialization
│   ├── config.py                   # service configuration
│   ├── discovery.py                # metadata/segment discovery + stability gate
│   ├── executor.py                 # subprocess wrapper around v4.1 core
│   ├── main.py                     # serve/watch/once/status CLI
│   ├── state_db.py                 # independent watchdog_jobs database
│   ├── types.py
│   ├── validation.py               # JSON schema + strict preflight + post-validation
│   └── worker.py                   # production state machine
├── runtime/                        # uploaded v4.1 scientific core, copied unchanged
│   ├── run_condition_monitoring_pipeline.py
│   ├── mcsa_*.py
│   ├── fault_scoring_layer.py
│   ├── rule_based_rul.py
│   ├── vibration_diagnostics.py
│   └── vibration_core/
├── config/
│   ├── watchdog_config.json
│   ├── metadata.schema.json
│   ├── fault_scoring_config.json
│   ├── vibration_config.realtime.json
│   ├── vibration_config.json
│   └── rul_config.json
├── database/
│   └── vira_schema_template.db     # empty 40-table schema cloned from validated contract DB
├── examples/
├── scripts/
├── tests/
├── Dockerfile
├── docker-compose.yml
├── requirements-watchdog.txt
└── .env.example
```

## 2. Watchdog execution model

```text
DAQ / acquisition
      |
      v
metadata.json + .bin files
      |
      v
DISCOVERED
      |
      +---- missing .bin ----------> WAITING_FOR_FILES
      |
      v
STABILIZING
      |
      v
metadata.schema.json validation
      |
      +---- invalid ---------------> REJECTED_DATA
      |
      v
strict recorded-data preflight
      |
      +---- invalid/duplicates ----> REJECTED_DATA
      |
      v
content SHA-256 fingerprint
      |
      +---- same completed data ---> COMPLETED (deduplicated)
      |
      v
profile resolution
      |
      +---- no healthy profile ----> BLOCKED_PROFILE
      |
      v
READY -> PROCESSING
          |
          | subprocess
          v
runtime/run_condition_monitoring_pipeline.py
          |
          +---- failure -----------> RETRY_WAIT -> retry -> QUARANTINED
          |
          v
POST_VALIDATING
          |
          +---- DB/output failure -> RETRY_WAIT / QUARANTINED
          |
          v
COMPLETED
```

The source acquisition files are never moved or deleted. A quarantined capture creates an audit report in `/data/quarantine/<job-id>/` while leaving the original acquisition bundle untouched.

## 3. Important database separation

Two databases have different responsibilities:

```text
/data/db/vira.db
    scientific/application output database
    MCSA, vibration, health, RUL, telemetry, processing_runs, etc.

/data/state/watchdog.db
    watchdog orchestration database only
    watchdog_jobs, watchdog_instances, watchdog_locks
```

This intentionally removes the ownership collision in the original realtime worker, where both the worker and the core used `processing_runs` with different capture-key semantics.

## 4. The nominal profile is intentionally NOT fabricated

The MCSA fault scorer requires a real healthy nominal profile. The package does not create a fake production profile.

The default config maps:

```text
MOTOR_01 -> /data/profiles/MOTOR_01/nominal-load.json
```

With default Compose mounts, put the file at:

```text
./data/profiles/MOTOR_01/nominal-load.json
```

If it is absent, the watchdog remains operational but the capture becomes `BLOCKED_PROFILE` instead of being diagnosed with an invalid reference.

Optional vibration and RUL baselines are not required to start the deterministic core. Add them to `watchdog_config.json` only after they actually exist and have been calibrated.

## 5. Docker startup

### Windows PowerShell

From this folder:

```powershell
Copy-Item .env.example .env
.\scripts\prepare_windows_dirs.ps1
```

Edit `.env` if your acquisition data is elsewhere. Docker Desktop accepts paths such as:

```text
VIRA_INBOX_HOST=D:/Fault_Detector/Data/inbox
VIRA_PROFILES_HOST=D:/Fault_Detector/Data/profiles
VIRA_DB_HOST=D:/Fault_Detector/Data/db
```

Then:

```powershell
docker compose build
docker compose up -d
```

Inspect logs:

```powershell
docker compose logs -f condition-worker
```

Service status:

```powershell
Invoke-RestMethod http://localhost:8088/health
Invoke-RestMethod http://localhost:8088/ready
Invoke-RestMethod http://localhost:8088/status
Invoke-RestMethod "http://localhost:8088/jobs?limit=50"
```

Stop:

```powershell
docker compose down
```

Do not add `-v` unless you deliberately want Docker-managed volumes removed; this Compose file primarily uses host bind mounts.

## 6. Input directory contract

A recommended capture layout is:

```text
/data/inbox/
└── MOTOR_01/
    └── capture_000001/
        ├── metadata.json
        └── raw/
            ├── CT_A_1787160000.bin
            ├── CT_B_1787160000.bin
            ├── CT_C_1787160000.bin
            ├── VIB_radial_1787160000.bin
            └── VIB_axial_1787160000.bin
```

The watchdog recursively scans for `metadata.json`.

For acquisition software, the safest write sequence is:

```text
1. write all .bin files
2. flush/close them
3. write metadata.json.tmp
4. atomically rename metadata.json.tmp -> metadata.json
```

The watchdog still applies its file-stability gate after discovery.

A metadata example is provided in `examples/metadata.production.example.json`.

## 7. Strict preflight behavior

The production config uses:

```json
"preflight": {
  "duration_policy": "strict",
  "duplicate_policy": "strict"
}
```

Therefore production processing is rejected when, for example:

- CT_A/CT_B/CT_C are missing;
- a referenced file cannot be resolved;
- binary decoding is invalid;
- non-finite samples make a channel invalid;
- channel duration/sample-count contract is inconsistent;
- byte-identical sensor channels are detected.

Do not change these settings to `trim`/`warn` for production simply to make bad acquisition data pass. Those modes are useful for software testing only.

## 8. Content-safe idempotency

The original realtime worker used path/segment identity. This wrapper adds a second, final identity after file stability:

```text
SHA256(
  canonical staged metadata
  + channel names
  + channel SHA-256 hashes
  + file sizes
  + segment index
)
```

That means reusing a filename with changed binary content creates a different capture fingerprint. Identical content discovered through another path is deduplicated.

The v4.1 core receives a deterministic run ID:

```text
wd-<asset>-<fingerprint-prefix>
```

so its own normalized database writes remain idempotent as well.

## 9. Retry and quarantine policy

Default:

```json
"max_retries": 3,
"retry_delays_seconds": [10, 30, 120]
```

Data-contract failures are not retried; they become `REJECTED_DATA`.

Core/runtime or post-validation failures are retried. After the maximum number of execution attempts, the job becomes `QUARANTINED` and an audit record is written.

## 10. Completion means more than exit code 0

A job is marked `COMPLETED` only when both conditions hold:

1. `run_condition_monitoring_pipeline.py` exits successfully and `run_summary.json` reports `success=true`;
2. post-validation confirms required output artifacts and normalized database rows, plus SQLite integrity and foreign-key checks.

Post-validation checks include the core artifacts such as:

```text
run_summary.json
ui_payload.json
database_payload.json
database_write_report.json
fault_score_report.json
vibration_diagnostic_report.json
rule_based_rul_report.json
energy_report.json
raw_sensor_manifest.json
feature_contract_audit.json
mmd_fullstack.csv
vibration_features.csv
pipeline.log
```

It also checks MCSA, telemetry, health, pipeline-stage, processing-run, RUL, and when applicable vibration persistence.

`prediction_count=0`, `alert_count=0`, or unavailable RUL do not by themselves mean watchdog failure. Those may be scientifically valid outcomes of the existing rule core.

## 11. Energy behavior

The v4.1 energy module requires rated voltage and power factor. This wrapper does not silently invent them.

If they are present in metadata, energy runs normally. They may also be configured globally under `energy` in `watchdog_config.json`.

If neither source supplies the required values and:

```json
"skip_energy_if_unconfigured": true
```

the core is launched with `--skip-energy`; the rest of condition monitoring continues.

## 12. Realtime vibration profile

The container uses:

```text
config/vibration_config.realtime.json
```

which keeps the uploaded realtime-balanced method selection instead of forcing every expensive specialist method into every continuous capture.

Optional ML methods remain harmless when their artifact path is null. If you later provide trained FSCNN/SVM/supervised artifacts, mount them under `/data/profiles` and update the relevant config paths.

## 13. Service API

The worker API is operational/administrative; the React frontend should normally continue talking to FastAPI backend, not directly to this service.

### Health

```http
GET /health
```

### Readiness

```http
GET /ready
```

### Worker/job summary

```http
GET /status
```

### Recent jobs

```http
GET /jobs?limit=100
GET /jobs?status=COMPLETED&limit=100
```

### One job

```http
GET /jobs/{job_id}
```

### Prometheus-style basic metrics

```http
GET /metrics
```

## 14. Native commands without Docker

After installing `requirements-watchdog.txt`, you can run the service directly. Change paths in a local copy of `watchdog_config.json` first because the supplied config uses container paths.

```bash
python -m condition_service.main once   --config config/local_watchdog_config.json
python -m condition_service.main watch  --config config/local_watchdog_config.json
python -m condition_service.main serve  --config config/local_watchdog_config.json
python -m condition_service.main status --config config/local_watchdog_config.json
```

`once --force-stable` exists for controlled testing only; normal continuous deployment should never bypass the stability interval.

## 15. Tests included

Run:

```bash
python -m unittest discover -s tests -v
```

The package tests verify:

- the schema template contains the validated 40-table empty contract;
- metadata schema validation;
- independent watchdog state persistence;
- the watchdog state DB does not create/own `processing_runs`;
- capture fingerprints change when channel content hashes change.

The uploaded v4.1 package had its own rule-core unit/integration validation before this wrapper. This package deliberately does not alter those algorithms.

## 16. Backend integration in the next step

The durable files intended for later backend integration are:

```text
/data/db/vira.db             # scientific/application data
/data/state/watchdog.db      # processing/watchdog operational state
/data/outputs/<run-id>/...   # auditable reports/artifacts
```

The clean integration is:

```text
React frontend
      |
      v
FastAPI backend
      |
      +------ read condition results from vira.db
      |
      +------ read/expose watchdog status from watchdog.db

condition-worker
      |
      +------ writes core outputs to vira.db
      +------ writes orchestration status to watchdog.db
```

Before sharing the SQLite file with the current backend container, align the backend ORM with the v4.1 normalized 40-table schema. Do not let the backend create a competing older schema in the same file.

For the first deployment keep **one condition worker**. If later moving to multiple simultaneous workers or many assets/sites, migrate the persistence layer to PostgreSQL and introduce a distributed queue as a separate upgrade rather than mixing that migration into this watchdog rollout.
