$dirs = @(
  ".\data\inbox",
  ".\data\profiles\MOTOR_01",
  ".\data\db",
  ".\data\state",
  ".\data\outputs",
  ".\data\staging",
  ".\data\quarantine",
  ".\data\logs"
)
foreach ($dir in $dirs) {
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
}
Write-Host "Watchdog data directories are ready."
Write-Host "Place the real healthy nominal profile in .\data\profiles\MOTOR_01\nominal-load.json"
