Invoke-RestMethod -Uri "http://localhost:8088/status" | ConvertTo-Json -Depth 8
