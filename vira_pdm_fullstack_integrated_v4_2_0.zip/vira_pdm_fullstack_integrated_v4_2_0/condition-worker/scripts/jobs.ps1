Invoke-RestMethod -Uri "http://localhost:8088/jobs?limit=50" | ConvertTo-Json -Depth 12
