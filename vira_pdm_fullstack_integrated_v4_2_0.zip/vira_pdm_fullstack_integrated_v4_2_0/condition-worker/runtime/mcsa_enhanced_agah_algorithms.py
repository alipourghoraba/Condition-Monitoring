import json
import os
import numpy as np
import pandas as pd
from scipy import signal, stats
from scipy.fftpack import dct
import pywt
import warnings
warnings.filterwarnings('ignore')

try:
    from PyEMD import EMD
except ImportError as exc:
    raise SystemExit(
        "Missing dependency: PyEMD. Install it with:\n"
        "    python -m pip install EMD-signal"
    ) from exc


# ─────────────────────────────────────────────────────────────────────────────
# Progress helper
# ─────────────────────────────────────────────────────────────────────────────
def log(message: str) -> None:
    print(message, flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# Core statistical helpers  (unchanged from original)
# ─────────────────────────────────────────────────────────────────────────────
def rms(x):
    x = np.asarray(x)
    return (np.sqrt(np.mean(np.abs(x) ** 2))
            if np.iscomplexobj(x)
            else np.sqrt(np.mean(x ** 2)))

def peak2rms(x):
    x = np.asarray(x)
    x_abs = np.abs(x)
    return np.max(x_abs) / rms(x)

def impulse_factor(x):
    x = np.asarray(x)
    x_abs = np.abs(x)
    return np.max(x_abs) / np.mean(x_abs)

def kurt(x):
    # scipy kurtosis with fisher=False → ordinary (non-excess) kurtosis
    return stats.kurtosis(x, fisher=False, bias=False)

def skw(x):
    return stats.skew(x, bias=False)

def entropy_hist(sig, bins='auto'):
    counts, _ = np.histogram(sig, bins=bins)
    return stats.entropy(counts, base=2)

def thd_ratio(sig, fs, n_harm=3):
    """THD as ratio of RMS of harmonics 2..n_harm to fundamental."""
    sig = np.asarray(sig)
    N = len(sig)
    fft_vals = np.fft.rfft(sig)
    freq = np.fft.rfftfreq(N, d=1 / fs)
    mask_f0 = (freq >= 40) & (freq <= 70)
    if not np.any(mask_f0):
        i_fund = np.argmax(np.abs(fft_vals))
        f0 = freq[i_fund]
    else:
        i_fund = np.argmax(np.abs(fft_vals)[mask_f0]) + np.where(mask_f0)[0][0]
        f0 = freq[i_fund]
    V1 = np.abs(fft_vals[i_fund])
    Vh2 = 0.0
    for h in range(2, n_harm + 1):
        fh = h * f0
        idx = np.argmin(np.abs(freq - fh))
        if np.abs(freq[idx] - fh) < f0 / 2:
            Vh2 += np.abs(fft_vals[idx]) ** 2
    return np.sqrt(Vh2) / V1 if V1 != 0 else 0.0

def thf_from_thd(thd):
    return thd / np.sqrt(1 + thd ** 2)

def compute_stft(sig, fs):
    log(f"  STFT start: n={len(sig)}")
    f, t, Zxx = signal.stft(sig, fs=fs, nperseg=256, noverlap=128,
                              return_onesided=False)
    out = np.abs(Zxx).ravel()
    log(f"  STFT done: output length={len(out)}")
    return out

def compute_emd(sig, label="signal"):
    log(f"  EMD start: {label}, n={len(sig)}")
    emd_obj = EMD()
    imfs = emd_obj.emd(sig, max_imf=1)
    if imfs.shape[0] == 0:
        log(f"  EMD done: {label}, no IMF found")
        return np.zeros_like(sig)
    log(f"  EMD done: {label}, IMF shape={imfs.shape}")
    return imfs[0]


# ═════════════════════════════════════════════════════════════════════════════
#   NEW ALGORITHMS  ─  Agah et al. [Paper 1, 2023] and [Paper 2, 2022]
# ═════════════════════════════════════════════════════════════════════════════

# ─── TKEO (Teager-Kaiser Energy Operator)  [Paper 2, Section II-B] ──────────
def tkeo(x: np.ndarray) -> np.ndarray:
    """
    Discrete Teager-Kaiser Energy Operator.

    Definition [Kaiser 1990; Agah et al. 2022 Eq. (4)]:
        ψ[x[n]]  =  x[n]²  −  x[n−1] · x[n+1]

    For a sinusoid  x[n] = A·cos(ω₀·n + φ):
        ψ[x[n]]  ≈  A² · sin²(ω₀)

    When applied to a DWT detail coefficient that has been narrowband-
    filtered around f₁, the operator demodulates the amplitude modulation
    caused by BRB fault: the sidebands at (1 ± 2ks)f₁ are shifted to
    2ks·f₁ (baseband), where s = slip, k = 1,2,3 …
    Only three consecutive samples are needed → virtually instantaneous.

    Boundary: first and last output values copied from their neighbours.
    """
    x   = np.asarray(x, dtype=np.float64)
    N   = len(x)
    if N < 3:
        return np.zeros(N)
    out        = np.empty(N)
    out[1:-1]  = x[1:-1] ** 2 - x[:-2] * x[2:]
    out[0]     = out[1]
    out[-1]    = out[-2]
    return out


# ─── Welch Power Spectral Density  [Paper 2, Section II-C] ──────────────────
def compute_welch_psd(sig: np.ndarray, fs: float,
                       nperseg: int = None) -> tuple:
    """
    Averaged periodogram (Welch) PSD [Paper 2: final feature extraction].

    Welch's method divides the signal into overlapping windows, computes
    the periodogram of each, and averages, reducing variance by ~ 1/K
    compared to a single periodogram of the same record length.

    Returns (f, Pxx) – one-sided PSD in units²/Hz.
    """
    sig     = np.asarray(sig, dtype=np.float64)
    n       = len(sig)
    if nperseg is None:
        nperseg = min(256, max(4, n // 2))
    nperseg = min(max(nperseg, 4), n)
    f, Pxx  = signal.welch(sig, fs=fs,
                            nperseg=nperseg,
                            noverlap=nperseg // 2,
                            window='hann',
                            return_onesided=True,
                            scaling='density')
    return f, Pxx


def _psd_at(f_arr: np.ndarray, Pxx: np.ndarray,
            f_target: float, bw: float = 2.0) -> float:
    """Max PSD value inside the band [f_target − bw/2,  f_target + bw/2]."""
    mask = np.abs(f_arr - f_target) <= bw / 2.0
    if not np.any(mask):
        idx = np.argmin(np.abs(f_arr - f_target))
        return float(Pxx[idx]) if idx < len(Pxx) else 0.0
    return float(np.max(Pxx[mask]))


# ─── Wavelet Packet Decomposition energies  [Paper 1, Section III-A] ────────
def compute_wpd_energies(sig: np.ndarray,
                          wavelet: str = 'db4',
                          level:   int = 4) -> dict:
    """
    Wavelet Packet Decomposition (WPD) — terminal node energies.

    WPD extends the standard DWT by recursively decomposing BOTH the
    approximation and detail sub-bands at each level, resulting in a
    uniform tiling of the frequency axis with 2^level sub-bands:

        E[node] = Σ c_k²    (L2 energy of node coefficients)

    Under ITSC fault the inter-turn short circuit introduces a negative-
    sequence component and current harmonics that shift the WPD energy
    distribution away from the healthy pattern.  Combined with the 3-D
    locus shape, this gives a load-independent fault indicator [Paper 1].

    Returns dict { node_path (e.g. 'aad'): energy }.
    """
    sig_f   = np.asarray(sig, dtype=np.float64)
    # Ensure level does not exceed what the signal length supports
    dec_len = pywt.Wavelet(wavelet).dec_len
    max_lvl = int(np.floor(np.log2(max(len(sig_f), 1) /
                                   max(dec_len - 1, 1) + 1)))
    level   = min(level, max(1, max_lvl))

    wp      = pywt.WaveletPacket(data=sig_f, wavelet=wavelet,
                                   mode='symmetric', maxlevel=level)
    nodes   = wp.get_level(level, order='natural')
    return {node.path: float(np.sum(node.data ** 2)) for node in nodes}


# ─── 3-D Current Space Locus  [Paper 1, Section III-B / Fig. 5] ─────────────
def compute_3d_locus_features(Ia: np.ndarray,
                               Ib: np.ndarray,
                               Ic: np.ndarray) -> dict:
    """
    Three-phase current 3-D locus features (PCA of trajectory).

    Healthy balanced motor [Paper 1, Eq. (6-8)]:
        Ia + Ib + Ic ≈ 0  (Kirchhoff)
        → trajectory lies on the plane  x+y+z=0
        → covariance matrix has one near-zero eigenvalue λ₃ ≈ 0
        → locus is a flat ellipse (circle for perfectly balanced supply)

    Under ITSC in phase A (μ shorted turns out of N_s total):
        Ia → Ia + ΔI_fault   (magnitude/phase change in phase A)
        Kirchhoff no longer holds exactly for the healthy portion
        → λ₃ increases, shape_ratio rises, volume increases

    Eigenvalue features:  λ₁ ≥ λ₂ ≥ λ₃  (sorted absolute eigenvalues
    of the 3×3 covariance matrix C = cov([Ia, Ib, Ic]))

    locus3d_volume      = √(λ₁·λ₂·λ₃)   ← volume of principal ellipsoid
    locus3d_shape_ratio = λ₁/λ₃          ← rises with fault severity
    locus3d_planarity   = λ₃/λ₁          ← near 0 for healthy motor
    locus3d_sphericity  = λ₃/λ₂
    """
    n  = min(len(Ia), len(Ib), len(Ic))
    X  = np.column_stack([Ia[:n], Ib[:n], Ic[:n]])
    C  = np.cov(X.T)
    ev = np.sort(np.abs(np.linalg.eigvals(C)))[::-1]    # λ₁ ≥ λ₂ ≥ λ₃

    vol         = float(np.prod(np.sqrt(ev + 1e-30)))
    shape_ratio = float(ev[0] / (ev[2] + 1e-30))
    planarity   = float(ev[2] / (ev[0] + 1e-30))
    sphericity  = float(ev[2] / (ev[1] + 1e-30))

    r = np.sqrt(Ia[:n]**2 + Ib[:n]**2 + Ic[:n]**2)

    return {
        'locus3d_eigval1'     : float(ev[0]),
        'locus3d_eigval2'     : float(ev[1]),
        'locus3d_eigval3'     : float(ev[2]),
        'locus3d_volume'      : vol,
        'locus3d_shape_ratio' : shape_ratio,
        'locus3d_planarity'   : planarity,
        'locus3d_sphericity'  : sphericity,
        'locus3d_r_mean'      : float(np.mean(r)),
        'locus3d_r_std'       : float(np.std(r)),
        'locus3d_r_rms'       : float(rms(r)),
        'locus3d_r_kurt'      : float(kurt(r)),
        'locus3d_r_skew'      : float(skw(r)),
    }


# ─── Current Unbalance Factor  [Paper 1, Sect. II-C] ────────────────────────
def current_unbalance_factor(Ia: np.ndarray,
                              Ib: np.ndarray,
                              Ic: np.ndarray) -> float:
    """
    CUF = max|RMS_ph − RMS_avg| / RMS_avg        [Paper 1, after Eq. (14)]

    Healthy balanced motor → CUF ≈ 0 (< 2 % per IEC 60034-26).
    ITSC on phase A         → RMS_a changes, CUF rises sharply,
                               indicating fault severity and location.
    """
    ra  = rms(Ia);  rb = rms(Ib);  rc = rms(Ic)
    avg = (ra + rb + rc) / 3.0
    return float(max(abs(ra - avg), abs(rb - avg), abs(rc - avg)) /
                 (avg + 1e-30))


# ─── Negative-Sequence Harmonic Analysis  [Paper 1, Sect. II-D] ─────────────
def neg_seq_harmonic_features(Ia: np.ndarray, Ib: np.ndarray, Ic: np.ndarray,
                               fs: float, f1: float = 50.0,
                               harmonics: tuple = (3, 5, 7)) -> dict:
    """
    Harmonic content of the negative-sequence current component [Paper 1].

    Negative-sequence phasor  [Symmetrical Components, Fortescue 1918]:
        I₂ = (Ia  +  α²·Ib  +  α·Ic) / 3      α = e^{j2π/3}

    Healthy motor: I₂ ≈ 0 (balanced three-phase system).
    ITSC fault   : I₂ ≠ 0, proportional to fault severity μ/N_s.
                   Harmonics 3rd, 5th, 7th are particularly diagnostic
                   because the inter-turn short circuit injects an
                   asymmetric flux component at these frequencies.

    Returned ratios are normalised to the negative-sequence fundamental,
    allowing load-independent thresholding.
    """
    alpha = np.exp(1j * 2.0 * np.pi / 3.0)
    N     = min(len(Ia), len(Ib), len(Ic))

    I2    = (np.asarray(Ia[:N], complex)
             + alpha**2 * np.asarray(Ib[:N], complex)
             + alpha    * np.asarray(Ic[:N], complex)) / 3.0

    spec  = np.fft.rfft(np.real(I2))
    freq  = np.fft.rfftfreq(N, d=1.0 / fs)
    mag   = np.abs(spec) / (N / 2.0)           # physical amplitude

    # Normalisation base: amplitude of I₂ at f₁
    mask_f1 = (freq >= f1 * 0.85) & (freq <= f1 * 1.15)
    base    = float(np.max(mag[mask_f1])) if np.any(mask_f1) else \
              max(float(np.max(mag)), 1e-30)

    feats = {
        'neg_seq_rms_ratio': float(rms(np.abs(I2)) / (rms(Ia[:N]) + 1e-30))
    }

    for h in harmonics:
        fh   = h * f1
        mask = (freq >= fh * 0.90) & (freq <= fh * 1.10)
        amp  = float(np.max(mag[mask])) if np.any(mask) else 0.0
        feats[f'neg_seq_h{h}']       = amp
        feats[f'neg_seq_h{h}_ratio'] = amp / (base + 1e-30)

    return feats


# ─── ITSC Full Feature Block  [Paper 1] ──────────────────────────────────────
def compute_itsc_features(Ia: np.ndarray, Ib: np.ndarray, Ic: np.ndarray,
                           fs: float, f1: float = 50.0,
                           wavelet_wpd: str = 'db4',
                           wpd_level:   int = 4) -> dict:
    """
    Complete ITSC feature set from Agah et al. [Paper 1, 2023].

    ┌─────────────────────────────────────────────────────────────────┐
    │                      ITSC Detection Pipeline                    │
    │  (Ia, Ib, Ic) ──┬── WPD (db4, lvl 4) ── node energies & ratios│
    │                  ├── 3-D locus PCA     ── λ₁,λ₂,λ₃, volume …  │
    │                  ├── CUF               ── current unbalance     │
    │                  └── Neg-seq FFT       ── h3, h5, h7 ratios    │
    └─────────────────────────────────────────────────────────────────┘

    Parameters
    ----------
    Ia, Ib, Ic   : three-phase stator current arrays (same length)
    fs           : sampling frequency (Hz)
    f1           : supply fundamental frequency (Hz, default 50)
    wavelet_wpd  : mother wavelet for WPD (default 'db4')
    wpd_level    : WPD decomposition depth (default 4 → 16 sub-bands)
    """
    log("  [Paper1-ITSC] WPD + 3D-locus pipeline …")
    feat = {}

    # ── 1. WPD energy per terminal node  ─────────────────────────────────
    for ph, sig in zip(['a', 'b', 'c'], [Ia, Ib, Ic]):
        energies = compute_wpd_energies(sig, wavelet=wavelet_wpd, level=wpd_level)
        total_e  = max(sum(energies.values()), 1e-30)
        e_vals   = np.array(list(energies.values()), dtype=float)

        for path, e in energies.items():
            feat[f'wpd_{ph}_e_{path}']  = float(e)           # absolute energy
            feat[f'wpd_{ph}_er_{path}'] = float(e / total_e) # relative energy

        # Statistical descriptors across nodes
        feat[f'wpd_{ph}_total_e']   = float(total_e)
        feat[f'wpd_{ph}_e_entropy'] = float(
            stats.entropy(e_vals / total_e + 1e-30, base=2))
        feat[f'wpd_{ph}_e_max']     = float(np.max(e_vals))
        feat[f'wpd_{ph}_e_max_idx'] = int(np.argmax(e_vals))
        feat[f'wpd_{ph}_e_kurt']    = float(kurt(e_vals))
        feat[f'wpd_{ph}_e_skew']    = float(skw(e_vals))

    # ── 2. 3-D current space locus (PCA-based)  ──────────────────────────
    feat.update(compute_3d_locus_features(Ia, Ib, Ic))

    # ── 3. Current Unbalance Factor  ──────────────────────────────────────
    feat['itsc_cuf'] = current_unbalance_factor(Ia, Ib, Ic)

    # ── 4. Negative-sequence harmonic content  ────────────────────────────
    feat.update(neg_seq_harmonic_features(Ia, Ib, Ic, fs, f1=f1))

    log(f"  [Paper1-ITSC] Done — {len(feat)} new features")
    return feat


# ─── BRB + Eccentricity Feature Block  [Paper 2] ─────────────────────────────
def compute_brb_eccentricity_features(Ia: np.ndarray,
                                        fs:        float = 10000.0,
                                        f1:        float = 50.0,
                                        slip:      float = 0.05,
                                        n_poles:   int   = 4,
                                        wavelet_d: str   = 'db4',
                                        dwt_level: int   = 7) -> dict:
    """
    BRB and mixed-eccentricity features  [Paper 2, Agah et al. 2022].

    ┌─────────────────────────────────────────────────────────────────────┐
    │              BRB / Eccentricity Detection Pipeline                  │
    │                                                                     │
    │  Ia(t) ──DWT(db4,lvl7)──► cD7 ──TKEO──► ψ[cD7] ──Welch──► Pxx   │
    │                        ──► cD6 ──TKEO──► ψ[cD6] ──Welch──► Pxx   │
    │                                  ↓                                  │
    │                        PSD peaks at 2k·s·f₁ → BRB indicators       │
    │                                                                     │
    │  Ia(t) ──Welch PSD──────────────────────────────────────────────►  │
    │            peaks at (1±2ks)f₁            → BRB sidebands (raw)     │
    │            peaks at (k·p±1)f₁            → static eccentricity     │
    │            peaks at (k·p±1)f₁ ± fr       → dynamic eccentricity   │
    └─────────────────────────────────────────────────────────────────────┘

    BRB frequency formula [Paper 2, Eq. (1)]:
        f_BRB = (1 ± 2k·s) · f₁       k = 1, 2, 3 …

    Eccentricity formulae [Paper 2, Eq. (2-3)]:
        f_ecc_static   = (k·p ± 1) · f₁
        f_ecc_dynamic  = (k·p ± 1) · f₁ ± m·fr
    where  p  = pole pairs = n_poles/2
           fr = f₁·(1−s)/p  (rotor frequency in electrical units)

    DWT level-to-frequency mapping at fs = 10 kHz (db4):
        Level 7 (cD7): [39.06, 78.12] Hz  → contains f₁ = 50 Hz
        Level 6 (cD6): [78.12, 156.25] Hz → contains 2·f₁ = 100 Hz

    After TKEO on cD7, the fundamental f₁ becomes a slowly-varying
    envelope (near DC); the BRB sidebands at (1±2ks)f₁ appear as
    components at 2ks·f₁ in the TKEO spectrum → easily resolved by
    a short Welch PSD on the TKEO output.

    Parameters
    ----------
    Ia         : phase-A stator current (10 kHz, length ≥ 512 samples)
    fs         : sampling frequency (Hz)
    f1         : supply fundamental (Hz)
    slip       : estimated slip (0 < s < 1; default 0.05 = 5%)
    n_poles    : number of poles (default 4)
    wavelet_d  : mother wavelet for DWT (default 'db4')
    dwt_level  : DWT decomposition depth (default 7 for fs=10 kHz)
    """
    log("  [Paper2-BRB/Ecc] DWT-TKEO-Welch PSD pipeline …")
    feat = {}

    p     = max(1, n_poles // 2)             # pole pairs
    fr    = f1 * (1.0 - slip) / p            # rotor frequency (Hz)

    # ── Step 1: DWT of stator current  ───────────────────────────────────
    #  coeffs = [cA_L, cD_L, cD_(L-1), …, cD_1]
    #  index:     [0]    [1]     [2]          [L]
    coeffs = pywt.wavedec(Ia, wavelet=wavelet_d, level=dwt_level)

    # ── Steps 2 & 3: TKEO → Welch PSD on two DWT levels  ────────────────
    #  Use the level that brackets the fundamental (d7) and the next (d6)
    tkeo_levels = [dwt_level, max(1, dwt_level - 1)]   # [7, 6] for default

    for lvl in tkeo_levels:
        c_idx  = dwt_level - lvl + 1          # position in coeffs list
        if c_idx >= len(coeffs):
            continue
        cD     = coeffs[c_idx]
        fs_eff = fs / (2.0 ** lvl)            # effective fs after decimation

        # ---- TKEO --------------------------------------------------------
        tk     = tkeo(cD)

        # ---- Welch PSD of TKEO output  -----------------------------------
        np_seg = min(256, max(4, len(tk) // 2))
        f_tk, Pxx_tk = compute_welch_psd(tk, fs=fs_eff, nperseg=np_seg)

        # BRB demodulated peaks at 2k·s·f₁  (after TKEO removes carrier f₁)
        for k in range(1, 4):
            f_bm = 2.0 * k * slip * f1
            feat[f'brb_tkeo_d{lvl}_k{k}'] = _psd_at(f_tk, Pxx_tk, f_bm, bw=2.0)

        # TKEO signal statistics
        feat[f'tkeo_d{lvl}_energy']    = float(np.sum(tk ** 2))
        feat[f'tkeo_d{lvl}_rms']       = float(rms(tk))
        feat[f'tkeo_d{lvl}_kurtosis']  = float(kurt(tk))
        feat[f'tkeo_d{lvl}_skewness']  = float(skw(tk))
        feat[f'tkeo_d{lvl}_std']       = float(np.std(tk))
        feat[f'tkeo_d{lvl}_peak2rms']  = float(peak2rms(tk))

    # ── Step 4: Direct Welch PSD of raw stator current  ──────────────────
    np_full       = min(2048, max(4, len(Ia) // 4))
    f_raw, Pxx_raw = compute_welch_psd(Ia, fs=fs, nperseg=np_full)

    # BRB sidebands  (1 ± 2ks) · f₁  in raw current PSD
    for k in range(1, 4):
        for sign, tag in [(+1, 'upper'), (-1, 'lower')]:
            f_b = (1.0 + sign * 2.0 * k * slip) * f1
            if f_b > 0:
                feat[f'brb_raw_{tag}_k{k}'] = _psd_at(f_raw, Pxx_raw, f_b, bw=2.0)

    # Static eccentricity  (k·p ± 1) · f₁
    for k in range(1, 3):
        for sign, tag in [(+1, 'pos'), (-1, 'neg')]:
            f_s = (k * p + sign) * f1
            if f_s > 0:
                feat[f'ecc_static_k{k}_{tag}'] = _psd_at(f_raw, Pxx_raw, f_s, bw=2.0)

    # Dynamic eccentricity  (k·p ± 1) · f₁ ± fr
    for k in range(1, 3):
        for s1, t1 in [(+1, 'pos'), (-1, 'neg')]:
            for s2, t2 in [(+1, 'r'), (-1, 'l')]:
                f_d = (k * p + s1) * f1 + s2 * fr
                if f_d > 0:
                    feat[f'ecc_dynamic_k{k}_{t1}_{t2}'] = _psd_at(f_raw, Pxx_raw, f_d, bw=2.0)

    # Key spectral reference values
    feat['psd_raw_f1']       = _psd_at(f_raw, Pxx_raw, f1,    bw=1.5)
    feat['psd_raw_2f1']      = _psd_at(f_raw, Pxx_raw, 2*f1,  bw=1.5)
    feat['psd_raw_fr']       = _psd_at(f_raw, Pxx_raw, fr,    bw=1.5)
    feat['psd_raw_max_freq'] = float(f_raw[np.argmax(Pxx_raw)]) if len(Pxx_raw) > 0 else 0.0
    feat['psd_raw_max_val']  = float(np.max(Pxx_raw)) if len(Pxx_raw) > 0 else 0.0
    feat['estimated_slip']   = float(slip)
    feat['rotor_freq_hz']    = float(fr)

    log(f"  [Paper2-BRB/Ecc] Done — {len(feat)} new features")
    return feat


# ═════════════════════════════════════════════════════════════════════════════
#   MOTOR / SUPPLY CONFIGURATION
#   ── Adjust these to match your motor nameplate ──
# ═════════════════════════════════════════════════════════════════════════════
SUPPLY_FREQ_HZ   = 50.0    # f₁  (Hz) – change to 60.0 for North America
N_POLES          = 4       # number of poles (4-pole → p=2 pole pairs)
RATED_SLIP       = 0.05    # estimated slip at rated load (5 % typical for
                            # 1.5 kW motor at full load; adjust if known)
WPD_WAVELET      = 'db4'   # wavelet for Paper 1 WPD
WPD_LEVEL        = 4       # WPD decomposition level (16 sub-bands)
DWT_WAVELET_BRB  = 'db4'   # wavelet for Paper 2 DWT
DWT_LEVEL_BRB    = 7       # DWT level for BRB/Ecc (7 → d7 contains f₁)


# ─────────────────────────────────────────────────────────────────────────────
# Load data (three-phase currents from files)
# ─────────────────────────────────────────────────────────────────────────────
log("[1/12] Starting script")
fs_raw   = 10000      # original sampling frequency (10 kHz)
data_dir = r"D:\Fault_Detector\Technical\Sample_Data"
file_a   = os.path.join(data_dir, "CT_A.txt")
file_b   = os.path.join(data_dir, "CT_B.txt")
file_c   = os.path.join(data_dir, "CT_C.txt")

log("[2/12] Checking input files")
for path in (file_a, file_b, file_c):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Required input file not found: {path}")
    log(f"  Found: {path}")

log("[3/12] Loading signals")
Ia = np.loadtxt(file_a).ravel()
Ib = np.loadtxt(file_b).ravel()
Ic = np.loadtxt(file_c).ravel()
log(f"  Ia={len(Ia)}, Ib={len(Ib)}, Ic={len(Ic)} samples")


# ─────────────────────────────────────────────────────────────────────────────
# 1. FFT features  (original)
# ─────────────────────────────────────────────────────────────────────────────
log("[4/12] Computing FFT features")
fs_down  = 1000
b, a     = signal.butter(2, 1 / 10, fs=fs_raw)
Ia_filt  = signal.filtfilt(b, a, Ia)
Ia_ds    = Ia_filt[::10]

N_ds     = len(Ia_ds)
spec     = np.abs(np.fft.rfft(Ia_ds))
spec_db  = 20 * np.log10(spec + 1e-12)
spec_db[0] = 0.0

freq_ds  = np.fft.rfftfreq(N_ds, d=1 / fs_down)
i_max    = np.argmax(spec_db)
maxim    = freq_ds[i_max]

fftRMS        = rms(spec_db)
fftMean       = np.mean(spec_db)
fftkurtosis   = kurt(spec_db)
fftSTD        = np.std(spec_db)
crestfft      = peak2rms(spec_db)
fftskewness   = skw(spec_db)
fftIMPfac     = np.max(spec_db) / np.mean(spec_db)
log("  FFT done")


# ─────────────────────────────────────────────────────────────────────────────
# 2. Symmetrical components  (original)
# ─────────────────────────────────────────────────────────────────────────────
log("[5/12] Computing symmetrical components")
a_op   = np.exp(1j * 2 * np.pi / 3)

neg_a  = (Ia + a_op**2 * Ib + a_op * Ic) / 3
neg_b  = a_op**2 * neg_a
neg_c  = a_op    * neg_a
neg_mag = [np.abs(neg_a), np.abs(neg_b), np.abs(neg_c)]

pos_a  = (Ia + a_op * Ib + a_op**2 * Ic) / 3
pos_b  = a_op    * pos_a
pos_c  = a_op**2 * pos_a
pos_mag = [np.abs(pos_a), np.abs(pos_b), np.abs(pos_c)]
log("  Symmetrical components done")


# ─────────────────────────────────────────────────────────────────────────────
# 3. Wavelet DWT (db1, level 9)  (original)
# ─────────────────────────────────────────────────────────────────────────────
log("[6/12] Computing wavelet DWT decomposition")
coeffs = pywt.wavedec(Ia, 'db1', level=9)
cD     = coeffs[1:]
cd     = cD[::-1]
log("  DWT done")


# ─────────────────────────────────────────────────────────────────────────────
# 4. STFT  (original)
# ─────────────────────────────────────────────────────────────────────────────
log("[7/12] Computing STFT features")
stft_flat = {
    'a': compute_stft(Ia, fs_raw),
    'b': compute_stft(Ib, fs_raw),
    'c': compute_stft(Ic, fs_raw)
}
log("  STFT done")


# ─────────────────────────────────────────────────────────────────────────────
# 5. EMD  (original)
# ─────────────────────────────────────────────────────────────────────────────
log("[8/12] Computing EMD features")
imf1 = {
    'a': compute_emd(Ia, 'phase a'),
    'b': compute_emd(Ib, 'phase b'),
    'c': compute_emd(Ic, 'phase c')
}
log("  EMD done")


# ─────────────────────────────────────────────────────────────────────────────
# 6. NEW — ITSC features: WPD + 3-D locus  [Paper 1]
# ─────────────────────────────────────────────────────────────────────────────
log("[9/12] Computing ITSC features (WPD + 3D-locus) [Paper 1]")
itsc_feat = compute_itsc_features(
    Ia, Ib, Ic,
    fs          = fs_raw,
    f1          = SUPPLY_FREQ_HZ,
    wavelet_wpd = WPD_WAVELET,
    wpd_level   = WPD_LEVEL
)
log(f"  ITSC features done: {len(itsc_feat)} features")


# ─────────────────────────────────────────────────────────────────────────────
# 7. NEW — BRB / Eccentricity features: DWT → TKEO → Welch PSD  [Paper 2]
# ─────────────────────────────────────────────────────────────────────────────
log("[10/12] Computing BRB/Eccentricity features (DWT-TKEO-PSD) [Paper 2]")
brb_feat = compute_brb_eccentricity_features(
    Ia,
    fs         = fs_raw,
    f1         = SUPPLY_FREQ_HZ,
    slip       = RATED_SLIP,
    n_poles    = N_POLES,
    wavelet_d  = DWT_WAVELET_BRB,
    dwt_level  = DWT_LEVEL_BRB
)
log(f"  BRB/Eccentricity features done: {len(brb_feat)} features")


# ─────────────────────────────────────────────────────────────────────────────
# 8. DCT + per-phase statistics  (original)
# ─────────────────────────────────────────────────────────────────────────────
log("[11/12] Computing DCT and remaining statistics")
dct_sig = {
    'a': dct(Ia, type=2, norm=None),
    'b': dct(Ib, type=2, norm=None),
    'c': dct(Ic, type=2, norm=None)
}

dct_pos        = dct(np.concatenate(pos_mag), type=2, norm=None)
dct_neg        = dct(np.concatenate(neg_mag), type=2, norm=None)
dct_pos_phases = [dct(pos_mag[0], type=2), dct(pos_mag[1], type=2), dct(pos_mag[2], type=2)]
dct_neg_phases = [dct(neg_mag[0], type=2), dct(neg_mag[1], type=2), dct(neg_mag[2], type=2)]

# Per-phase statistics
Rmspha  = rms(Ia);  Rmsphb  = rms(Ib);  Rmsphc  = rms(Ic)
Kpha    = kurt(Ia); Kphb    = kurt(Ib); Kphc    = kurt(Ic)
SKpha   = skw(Ia);  SKphb   = skw(Ib);  SKphc   = skw(Ic)
mIspha  = np.mean(Ia); mIsphb = np.mean(Ib); mIsphc = np.mean(Ic)
SDIspha = np.std(Ia);  SDIsphb = np.std(Ib); SDIsphc = np.std(Ic)
Crestpha = peak2rms(Ia); Crestphb = peak2rms(Ib); Crestphc = peak2rms(Ic)
IMPpha  = impulse_factor(Ia); IMPphb = impulse_factor(Ib); IMPphc = impulse_factor(Ic)

THDpha = thd_ratio(Ia, fs_raw, 3)
THDphb = thd_ratio(Ib, fs_raw, 3)
THDphc = thd_ratio(Ic, fs_raw, 3)
THFpha = thf_from_thd(THDpha)
THFphb = thf_from_thd(THDphb)
THFphc = thf_from_thd(THDphc)

entpha = entropy_hist(Ia); entphb = entropy_hist(Ib); entphc = entropy_hist(Ic)

# Park vector
id_sig = np.sqrt(2/3) * (Ia + Ib*np.cos(-2*np.pi/3) + Ic*np.cos(2*np.pi/3))
iq_sig = np.sqrt(2/3) * (Ia + Ib*np.sin(-2*np.pi/3) + Ic*np.sin(2*np.pi/3))
idmean = np.mean(id_sig); iqmean = np.mean(iq_sig)
idstd  = np.std(id_sig);  iqstd  = np.std(iq_sig)
idkurtosis = kurt(id_sig); iqkurtosis = kurt(iq_sig)
idskewness = skw(id_sig);  iqskewness = skw(iq_sig)
idcrstfac  = peak2rms(id_sig); iqcrstfac  = peak2rms(iq_sig)
idimpfac   = impulse_factor(id_sig); iqimpfac = impulse_factor(iq_sig)
idRMS  = rms(id_sig); iqRMS = rms(iq_sig)


# ─────────────────────────────────────────────────────────────────────────────
# 9. Assemble feature dictionary
# ─────────────────────────────────────────────────────────────────────────────
log("[12/12] Building feature table")
features = {}

# ── Original wavelet DWT detail coefficients ─────────────────────────────
for i in range(9):
    sig = cd[i]
    features[f'Crestcd{i+1}']       = peak2rms(sig)
for i in range(9):
    features[f'Impulsefactorcd{i+1}'] = impulse_factor(cd[i])
for i in range(9):
    features[f'cd{i+1}kurtosis']    = kurt(cd[i])
for i in range(9):
    features[f'meancd{i+1}']        = np.mean(cd[i])
for i in range(9):
    features[f'RMScd{i+1}']         = rms(cd[i])
for i in range(9):
    features[f'STDct{i+1}']         = np.std(cd[i])
for i in range(9):
    features[f'Skewnesscd{i+1}']    = skw(cd[i])

# ── DCT per phase ─────────────────────────────────────────────────────────
features['crstDCTpha'] = peak2rms(dct_sig['a'])
features['crstDCTphb'] = peak2rms(dct_sig['b'])
features['crstDCTphc'] = peak2rms(dct_sig['c'])

# ── EMD ───────────────────────────────────────────────────────────────────
for ph in ['a', 'b', 'c']:
    features[f'emdcrstfac{ph}'] = peak2rms(imf1[ph])
features['emdcrstfacb'] = peak2rms(imf1['b'])
for ph in ['a', 'b', 'c']:
    features[f'emdimpfac{ph}'] = impulse_factor(imf1[ph])
for ph in ['a', 'b', 'c']:
    features[f'emdkurtosis{ph}'] = kurt(imf1[ph])
for ph in ['a', 'b', 'c']:
    features[f'emdmean{ph}'] = np.mean(imf1[ph])
for ph in ['a', 'b', 'c']:
    features[f'emdrms{ph}'] = rms(imf1[ph])
for ph in ['a', 'b', 'c']:
    features[f'emdska{ph}'] = skw(imf1[ph])
for ph in ['a', 'b', 'c']:
    features[f'emdstd{ph}'] = np.std(imf1[ph])

# ── Entropy ───────────────────────────────────────────────────────────────
features['entropypha'] = entpha
features['entropyphb'] = entphb
features['entropyphc'] = entphc

# ── Park vector ───────────────────────────────────────────────────────────
features['Idcrestfac'] = idcrstfac
features['Idimpfac']   = idimpfac
features['Idkurtosis'] = idkurtosis
features['Idmean']     = idmean
features['IdRMS']      = idRMS
features['Idskewness'] = idskewness
features['Iqcrstfac']  = iqcrstfac
features['Iqkurtosis'] = iqkurtosis
features['Iqmean']     = iqmean
features['IqRMS']      = iqRMS
features['Iqskewness'] = iqskewness
features['Iqstd']      = iqstd

# ── DCT impulse / phase features ──────────────────────────────────────────
features['ImpulsefactorDCTpha'] = impulse_factor(dct_sig['a'])
features['ImpulsefactorDCTphb'] = impulse_factor(dct_sig['b'])
features['ImpulsefactorDCTphc'] = impulse_factor(dct_sig['c'])
features['Impulsefactorpha'] = IMPpha
features['Impulsefactorphb'] = IMPphb
features['Impulsefactorphc'] = IMPphc
features['kurtosispha'] = Kpha
features['kurtosisphb'] = Kphb
features['kurtosisphc'] = Kphc
features['kurtosisDCTpha'] = kurt(dct_sig['a'])
features['kurtosisDCTphb'] = kurt(dct_sig['b'])
features['kurtosisDCTphc'] = kurt(dct_sig['c'])
features['meanDCTpha'] = np.mean(dct_sig['a'])
features['meanDCTphb'] = np.mean(dct_sig['b'])
features['meanDCTphc'] = np.mean(dct_sig['c'])
features['meanCurrentpha'] = mIspha
features['meanCurrentphb'] = mIsphb
features['meanCurrentphc'] = mIsphc
features['rmsDCTpha'] = rms(dct_sig['a'])
features['rmsDCTphb'] = rms(dct_sig['b'])
features['rmsDCTphc'] = rms(dct_sig['c'])
features['STDpha'] = SDIspha
features['STDphb'] = SDIsphb
features['STDphc'] = SDIsphc
features['SkewnessDCTpha'] = skw(dct_sig['a'])
features['SkewnessDCTphb'] = skw(dct_sig['b'])
features['SkewnessDCTphc'] = skw(dct_sig['c'])
features['Skewnesspha'] = SKpha
features['Skewnessphb'] = SKphb
features['Skewnessphc'] = SKphc
features['StdDCTpha'] = np.std(dct_sig['a'])
features['StdDCTphb'] = np.std(dct_sig['b'])
features['StdDCTphc'] = np.std(dct_sig['c'])

# ── STFT ──────────────────────────────────────────────────────────────────
for ph in ['a', 'b', 'c']:
    features[f'Stftcrest{ph}']     = peak2rms(stft_flat[ph])
for ph in ['a', 'b', 'c']:
    features[f'Stftimpfactor{ph}'] = impulse_factor(stft_flat[ph])
for ph in ['a', 'b', 'c']:
    features[f'Stftkurtosis{ph}']  = kurt(stft_flat[ph])
features['Stftkurtosisb'] = kurt(stft_flat['b'])
for ph in ['a', 'b', 'c']:
    features[f'Stftmean{ph}']      = np.mean(stft_flat[ph])
for ph in ['a', 'b', 'c']:
    features[f'Stftrms{ph}']       = rms(stft_flat[ph])
for ph in ['a', 'b', 'c']:
    features[f'Stftstd{ph}']       = np.std(stft_flat[ph])
for ph in ['a', 'b', 'c']:
    features[f'Stftskewness{ph}']  = skw(stft_flat[ph])

# ── THD / THF ─────────────────────────────────────────────────────────────
features['THDpha'] = THDpha
features['THDphb'] = THDphb
features['THDphc'] = THDphc
features['THFpha'] = THFpha
features['THFphb'] = THFphb
features['THFphc'] = THFphc

# ── Crest factors ─────────────────────────────────────────────────────────
features['Crestfactorpha'] = Crestpha
features['Crestfactorphb'] = Crestphb
features['Crestfactorphc'] = Crestphc

# ── Positive sequence DCT ─────────────────────────────────────────────────
features['Crestfactorposseq1'] = peak2rms(dct_pos_phases[0])
features['Crestfactorposseq2'] = peak2rms(dct_pos_phases[1])
features['Crestfactorposseq3'] = peak2rms(dct_pos_phases[2])
features['IMPULSEfactorDCTposseq'] = impulse_factor(np.concatenate(dct_pos_phases))

# ── Negative sequence DCT kurtosis ───────────────────────────────────────
features['kurtosisDCTnegseq1'] = kurt(dct_neg_phases[0])
features['kurtosisDCTnegseq2'] = kurt(dct_neg_phases[1])
features['kurtosisDCTnegseq3'] = kurt(dct_neg_phases[2])
features['kurtosisDCTposseq1'] = kurt(dct_pos_phases[0])
features['kurtosisDCTposseq2'] = kurt(dct_pos_phases[1])
features['kurtosisDCTposseq3'] = kurt(dct_pos_phases[2])
features['meanDCTnegseq1'] = np.mean(dct_neg_phases[0])
features['meanDCTnegseq2'] = np.mean(dct_neg_phases[1])
features['meanDCTnegseq3'] = np.mean(dct_neg_phases[2])
features['meanDCTposseq1'] = np.mean(dct_pos_phases[0])
features['meanDCTposseq2'] = np.mean(dct_pos_phases[1])
features['meanDCTposseq3'] = np.mean(dct_pos_phases[2])

# ── Negative sequence features ────────────────────────────────────────────
features['negseqCrestfactor1'] = peak2rms(neg_mag[0])
features['negseqCrestfactor2'] = peak2rms(neg_mag[1])
features['negseqCrestfactor3'] = peak2rms(neg_mag[2])
features['negseqImpulsefactor'] = impulse_factor(np.concatenate(neg_mag))
features['negseqkurtosis1'] = kurt(neg_mag[0])
features['negseqkurtosis2'] = kurt(neg_mag[1])
features['negseqkurtosis3'] = kurt(neg_mag[2])
features['negseqRMS1'] = rms(neg_mag[0])
features['negseqRMS2'] = rms(neg_mag[1])
features['negseqRMS3'] = rms(neg_mag[2])
features['negseqSKEWNESS1'] = skw(neg_mag[0])
features['negseqSKEWNESS2'] = skw(neg_mag[1])
features['negseqSKEWNESS3'] = skw(neg_mag[2])

# ── Positive sequence features ────────────────────────────────────────────
features['posseqCRESTfactor1'] = peak2rms(pos_mag[0])
features['posseqCRESTfactor2'] = peak2rms(pos_mag[1])
features['posseqCRESTfactor3'] = peak2rms(pos_mag[2])
features['posseqIMPULSEfactor'] = impulse_factor(np.concatenate(pos_mag))
features['posseqkurtosis1'] = kurt(pos_mag[0])
features['posseqkurtosis2'] = kurt(pos_mag[1])
features['posseqkurtosis3'] = kurt(pos_mag[2])
features['posseqRMS1'] = rms(pos_mag[0])
features['posseqRMS2'] = rms(pos_mag[1])
features['posseqRMS3'] = rms(pos_mag[2])
features['posseqSTD1'] = np.std(pos_mag[0])
features['posseqSTD2'] = np.std(pos_mag[1])
features['posseqSTD3'] = np.std(pos_mag[2])
features['posseqSKEWNESS1'] = skw(pos_mag[0])
features['posseqSKEWNESS2'] = skw(pos_mag[1])
features['posseqSKEWNESS3'] = skw(pos_mag[2])
features['rmsDCTnegseq1'] = rms(dct_neg_phases[0])
features['rmsDCTnegseq2'] = rms(dct_neg_phases[1])
features['rmsDCTnegseq3'] = rms(dct_neg_phases[2])
features['rmsDCTposseq1'] = rms(dct_pos_phases[0])
features['rmsDCTposseq2'] = rms(dct_pos_phases[1])
features['rmsDCTposseq3'] = rms(dct_pos_phases[2])
features['SKEWNESSDCTnegseq1'] = skw(dct_neg_phases[0])
features['SKEWNESSDCTnegseq2'] = skw(dct_neg_phases[1])
features['SKEWNESSDCTnegseq3'] = skw(dct_neg_phases[2])
features['SKEWNESSDCTposseq1'] = skw(dct_pos_phases[0])
features['SKEWNESSDCTposseq2'] = skw(dct_pos_phases[1])
features['SKEWNESSDCTposseq3'] = skw(dct_pos_phases[2])
features['stdDCTposseq1'] = np.std(dct_pos_phases[0])
features['stdDCTposseq2'] = np.std(dct_pos_phases[1])
features['stdDCTposseq3'] = np.std(dct_pos_phases[2])
features['stdDCTnegseq1'] = np.std(dct_neg_phases[0])
features['stdDCTnegseq2'] = np.std(dct_neg_phases[1])
features['stdDCTnegseq3'] = np.std(dct_neg_phases[2])

# ── NEW: Paper 1 ITSC features ────────────────────────────────────────────
features.update(itsc_feat)

# ── NEW: Paper 2 BRB / Eccentricity features ──────────────────────────────
features.update(brb_feat)


# ─────────────────────────────────────────────────────────────────────────────
# Save to CSV
# ─────────────────────────────────────────────────────────────────────────────

# ── Original ordered labels (preserved exactly for backward compatibility) ──
ordered_labels_original = [
    'Crestcd1','Crestcd2','Crestcd3','Crestcd4','Crestcd5','Crestcd6','Crestcd7','Crestcd8','Crestcd9',
    'crstDCTpha','crstDCTphb','crstDCTphc',
    'emdcrstfaca','emdcrstfacb','emdcrstfacb',
    'emdimpfaca','emdimpfacb','emdimpfacc',
    'emdkurtosisa','emdkurtosisb','emdkurtosisc',
    'emdmeana','emdmeanb','emdmeanc',
    'emdrmsa','emdrmsb','emdrmsc',
    'emdska','emdskb','emdska',
    'emdstda','emdstdb','emdstdc',
    'entropypha','entropyphb','entropyphc',
    'Idcrestfac','Idimpfac','Idkurtosis','Idmean','IdRMS','Idskewness',
    'Impulsefactorcd1','Impulsefactorcd2','Impulsefactorcd3','Impulsefactorcd4','Impulsefactorcd5',
    'Impulsefactorcd6','Impulsefactorcd7','Impulsefactorcd8','Impulsefactorcd9',
    'ImpulsefactorDCTpha','ImpulsefactorDCTphb','ImpulsefactorDCTphc',
    'Impulsefactorpha','Impulsefactorphb','Impulsefactorphc',
    'Iqcrstfac','Iqkurtosis','Iqmean','IqRMS','Iqskewness','Iqstd',
    'cd1kurtosis','cd2kurtosis','cd3kurtosis','cd4kurtosis','cd5kurtosis','cd6kurtosis','cd7kurtosis','cd8kurtosis','cd9kurtosis',
    'kurtosispha','kurtosisphb','kurtosisphc',
    'kurtosisDCTpha','kurtosisDCTphb','kurtosisDCTphc',
    'meancd1','meancd2','meancd3','meancd4','meancd5','meancd6','meancd7','meancd8','meancd9',
    'meanDCTpha','meanDCTphb','meanDCTphc',
    'meanCurrentpha','meanCurrentphb','meanCurrentphc',
    'RMScd1','RMScd2','RMScd3','RMScd4','RMScd5','RMScd6','RMScd7','RMScd8','RMScd9',
    'rmsDCTpha','rmsDCTphb','rmsDCTphc',
    'STDct1','STDct2','STDct3','STDct4','STDct5','STDct6','STDct7','STDct8','STDct9',
    'STDpha','STDphb','STDphc',
    'Skewnesscd1','Skewnesscd2','Skewnesscd3','Skewnesscd4','Skewnesscd5','Skewnesscd6','Skewnesscd7','Skewnesscd8','Skewnesscd9',
    'SkewnessDCTpha','SkewnessDCTphb','SkewnessDCTphc',
    'Skewnesspha','Skewnessphb','Skewnessphc',
    'StdDCTpha','StdDCTphb','StdDCTphc',
    'Stftcresta','Stftcrestb','Stftcrestc',
    'Stftimpfactora','Stftimpfactorb','Stftimpfactorc',
    'Stftkurtosisa','Stftkurtosisb','Stftkurtosisb',
    'Stftmeana','Stftmeanb','Stftmeanc',
    'Stftrmsa','Stftrmsb','Stftrmsc',
    'Stftstda','Stftstdb','Stftstdc',
    'Stftskewnessa','Stftskewnessb','Stftskewnessc',
    'THDpha','THDphb','THDphc',
    'THFpha','THFphb','THFphc',
    'Crestfactorpha','Crestfactorphb','Crestfactorphc',
    'Crestfactorposseq1','Crestfactorposseq2','Crestfactorposseq3',
    'IMPULSEfactorDCTposseq',
    'kurtosisDCTnegseq1','kurtosisDCTnegseq2','kurtosisDCTnegseq3',
    'kurtosisDCTposseq1','kurtosisDCTposseq2','kurtosisDCTposseq3',
    'meanDCTnegseq1','meanDCTnegseq2','meanDCTnegseq3',
    'meanDCTposseq1','meanDCTposseq2','meanDCTposseq3',
    'negseqCrestfactor1','negseqCrestfactor2','negseqCrestfactor3',
    'negseqImpulsefactor',
    'negseqkurtosis1','negseqkurtosis2','negseqkurtosis3',
    'negseqRMS1','negseqRMS2','negseqRMS3',
    'negseqSKEWNESS1','negseqSKEWNESS2','negseqSKEWNESS3',
    'posseqCRESTfactor1','posseqCRESTfactor2','posseqCRESTfactor3',
    'posseqIMPULSEfactor',
    'posseqkurtosis1','posseqkurtosis2','posseqkurtosis3',
    'posseqRMS1','posseqRMS2','posseqRMS3',
    'posseqSTD1','posseqSTD2','posseqSTD3',
    'posseqSKEWNESS1','posseqSKEWNESS2','posseqSKEWNESS3',
    'rmsDCTnegseq1','rmsDCTnegseq2','rmsDCTnegseq3',
    'rmsDCTposseq1','rmsDCTposseq2','rmsDCTposseq3',
    'SKEWNESSDCTnegseq1','SKEWNESSDCTnegseq2','SKEWNESSDCTnegseq3',
    'SKEWNESSDCTposseq1','SKEWNESSDCTposseq2','SKEWNESSDCTposseq3',
    'stdDCTposseq1','stdDCTposseq2','stdDCTposseq3',
    'stdDCTnegseq1','stdDCTnegseq2','stdDCTnegseq3',
]

# ── NEW labels from Paper 1 and Paper 2 (sorted for determinism) ─────────
new_labels_paper1 = sorted([k for k in itsc_feat.keys()])
new_labels_paper2 = sorted([k for k in brb_feat.keys()])

# Final column order: originals first (backward compat), then new
ordered_labels = ordered_labels_original + new_labels_paper1 + new_labels_paper2

log(f"  Feature count — original: {len(ordered_labels_original)}, "
    f"Paper1: {len(new_labels_paper1)}, Paper2: {len(new_labels_paper2)}, "
    f"total: {len(ordered_labels)}")

data_row = [features.get(label, 0.0) for label in ordered_labels]
df       = pd.DataFrame([data_row], columns=ordered_labels)

output_path = os.path.join(data_dir, "mmd.csv")
log(f"  Saving CSV to: {output_path}")
df.to_csv(output_path, index=False)

log(f"Feature extraction complete. Saved to {output_path}")


# ─────────────────────────────────────────────────────────────────────────────
# 10. Save fault classification JSON  (feature → fault mapping)
# ─────────────────────────────────────────────────────────────────────────────
log("[13/12] Writing fault classification JSON")
fault_map = {
    "faults": [
        {
            "name": "Unbalance",
            "name_fa": "نامیزانی",
            "description": "Voltage or load unbalance causing asymmetry in three‑phase currents",
            "features": [
                "negseqRMS1", "negseqRMS2", "negseqRMS3",
                "negseqkurtosis1", "negseqkurtosis2", "negseqkurtosis3",
                "negseqSKEWNESS1", "negseqSKEWNESS2", "negseqSKEWNESS3",
                "negseqImpulsefactor",
                "negseqCrestfactor1", "negseqCrestfactor2", "negseqCrestfactor3",
                "kurtosisDCTnegseq1", "kurtosisDCTnegseq2", "kurtosisDCTnegseq3",
                "meanDCTnegseq1", "meanDCTnegseq2", "meanDCTnegseq3",
                "rmsDCTnegseq1", "rmsDCTnegseq2", "rmsDCTnegseq3",
                "SKEWNESSDCTnegseq1", "SKEWNESSDCTnegseq2", "SKEWNESSDCTnegseq3",
                "stdDCTnegseq1", "stdDCTnegseq2", "stdDCTnegseq3"
            ]
        },
        {
            "name": "Stator Winding Inter‑Turn Short Circuit (ITSC)",
            "name_fa": "اتصال کوتاه سیم‌پیچی استاتور",
            "description": "Turn‑to‑turn short circuit; original wavelet detail coefficients + Paper‑1 WPD/3D‑locus/CUF/neg‑seq features",
            "features": [
                "RMScd1","RMScd2","RMScd3","RMScd4","RMScd5","RMScd6","RMScd7","RMScd8","RMScd9",
                "cd1kurtosis","cd2kurtosis","cd3kurtosis","cd4kurtosis","cd5kurtosis","cd6kurtosis","cd7kurtosis","cd8kurtosis","cd9kurtosis",
                "Skewnesscd1","Skewnesscd2","Skewnesscd3","Skewnesscd4","Skewnesscd5","Skewnesscd6","Skewnesscd7","Skewnesscd8","Skewnesscd9",
                "Impulsefactorcd1","Impulsefactorcd2","Impulsefactorcd3","Impulsefactorcd4","Impulsefactorcd5","Impulsefactorcd6","Impulsefactorcd7","Impulsefactorcd8","Impulsefactorcd9",
                "Crestcd1","Crestcd2","Crestcd3","Crestcd4","Crestcd5","Crestcd6","Crestcd7","Crestcd8","Crestcd9",
                "STDct1","STDct2","STDct3","STDct4","STDct5","STDct6","STDct7","STDct8","STDct9",
                "meancd1","meancd2","meancd3","meancd4","meancd5","meancd6","meancd7","meancd8","meancd9",
                "THDpha","THDphb","THDphc",
                "THFpha","THFphb","THFphc",
                "wpd_a_e_aaa","wpd_a_e_aad","wpd_a_e_ada","wpd_a_e_add",
                "wpd_a_e_daa","wpd_a_e_dad","wpd_a_e_dda","wpd_a_e_ddd",
                "wpd_a_er_aaa","wpd_a_er_aad","wpd_a_er_ada","wpd_a_er_add",
                "wpd_a_er_daa","wpd_a_er_dad","wpd_a_er_dda","wpd_a_er_ddd",
                "wpd_a_total_e","wpd_a_e_entropy","wpd_a_e_max","wpd_a_e_max_idx","wpd_a_e_kurt","wpd_a_e_skew",
                "wpd_b_e_aaa","wpd_b_e_aad","wpd_b_e_ada","wpd_b_e_add",
                "wpd_b_e_daa","wpd_b_e_dad","wpd_b_e_dda","wpd_b_e_ddd",
                "wpd_b_er_aaa","wpd_b_er_aad","wpd_b_er_ada","wpd_b_er_add",
                "wpd_b_er_daa","wpd_b_er_dad","wpd_b_er_dda","wpd_b_er_ddd",
                "wpd_b_total_e","wpd_b_e_entropy","wpd_b_e_max","wpd_b_e_max_idx","wpd_b_e_kurt","wpd_b_e_skew",
                "wpd_c_e_aaa","wpd_c_e_aad","wpd_c_e_ada","wpd_c_e_add",
                "wpd_c_e_daa","wpd_c_e_dad","wpd_c_e_dda","wpd_c_e_ddd",
                "wpd_c_er_aaa","wpd_c_er_aad","wpd_c_er_ada","wpd_c_er_add",
                "wpd_c_er_daa","wpd_c_er_dad","wpd_c_er_dda","wpd_c_er_ddd",
                "wpd_c_total_e","wpd_c_e_entropy","wpd_c_e_max","wpd_c_e_max_idx","wpd_c_e_kurt","wpd_c_e_skew",
                "locus3d_eigval1","locus3d_eigval2","locus3d_eigval3",
                "locus3d_volume","locus3d_shape_ratio","locus3d_planarity","locus3d_sphericity",
                "locus3d_r_mean","locus3d_r_std","locus3d_r_rms","locus3d_r_kurt","locus3d_r_skew",
                "itsc_cuf",
                "neg_seq_rms_ratio",
                "neg_seq_h3","neg_seq_h3_ratio",
                "neg_seq_h5","neg_seq_h5_ratio",
                "neg_seq_h7","neg_seq_h7_ratio"
            ]
        },
        {
            "name": "Broken Rotor Bar (BRB)",
            "name_fa": "شکستگی میله روتور",
            "description": "Broken rotor bars causing sideband modulation; original spectral features + Paper‑2 DWT‑TKEO‑PSD indicators",
            "features": [
                "Stftkurtosisa","Stftkurtosisb","Stftkurtosisc",
                "Stftskewnessa","Stftskewnessb","Stftskewnessc",
                "emdkurtosisa","emdkurtosisb","emdkurtosisc",
                "THDpha","THDphb","THDphc",
                "brb_tkeo_d7_k1","brb_tkeo_d7_k2","brb_tkeo_d7_k3",
                "brb_tkeo_d6_k1","brb_tkeo_d6_k2","brb_tkeo_d6_k3",
                "tkeo_d7_energy","tkeo_d7_rms","tkeo_d7_kurtosis","tkeo_d7_skewness","tkeo_d7_std","tkeo_d7_peak2rms",
                "tkeo_d6_energy","tkeo_d6_rms","tkeo_d6_kurtosis","tkeo_d6_skewness","tkeo_d6_std","tkeo_d6_peak2rms",
                "brb_raw_upper_k1","brb_raw_lower_k1",
                "brb_raw_upper_k2","brb_raw_lower_k2",
                "brb_raw_upper_k3","brb_raw_lower_k3",
                "psd_raw_f1","psd_raw_2f1",
                "estimated_slip","rotor_freq_hz"
            ]
        },
        {
            "name": "Eccentricity (Static / Dynamic)",
            "name_fa": "خروج از مرکز (استاتیک / دینامیک)",
            "description": "Non‑uniform air‑gap due to rotor misalignment; Park vector features, entropy, and Paper‑2 eccentricity peaks",
            "features": [
                "Idcrestfac","Idimpfac","Idkurtosis","Idmean","IdRMS","Idskewness",
                "Iqcrstfac","Iqkurtosis","Iqmean","IqRMS","Iqskewness","Iqstd",
                "entropypha","entropyphb","entropyphc",
                "ecc_static_k1_pos","ecc_static_k1_neg",
                "ecc_static_k2_pos","ecc_static_k2_neg",
                "ecc_dynamic_k1_pos_r","ecc_dynamic_k1_pos_l",
                "ecc_dynamic_k1_neg_r","ecc_dynamic_k1_neg_l",
                "ecc_dynamic_k2_pos_r","ecc_dynamic_k2_pos_l",
                "ecc_dynamic_k2_neg_r","ecc_dynamic_k2_neg_l",
                "psd_raw_fr","rotor_freq_hz"
            ]
        },
        {
            "name": "Bearing Fault",
            "name_fa": "عیب یاتاقان",
            "description": "Localised bearing defects generating impact‑like transients; STFT and EMD impulse/crest/kurtosis/skewness",
            "features": [
                "Stftcresta","Stftcrestb","Stftcrestc",
                "Stftimpfactora","Stftimpfactorb","Stftimpfactorc",
                "Stftkurtosisa","Stftkurtosisb","Stftkurtosisb",
                "Stftskewnessa","Stftskewnessb","Stftskewnessc",
                "emdcrstfaca","emdcrstfacb","emdcrstfacb",
                "emdimpfaca","emdimpfacb","emdimpfacc",
                "emdkurtosisa","emdkurtosisb","emdkurtosisc"
            ]
        },
        {
            "name": "Overload",
            "name_fa": "اضافه بار",
            "description": "Excessive load; positive‑sequence magnitude, per‑phase RMS/crest/kurtosis",
            "features": [
                "posseqRMS1","posseqRMS2","posseqRMS3",
                "posseqkurtosis1","posseqkurtosis2","posseqkurtosis3",
                "posseqSKEWNESS1","posseqSKEWNESS2","posseqSKEWNESS3",
                "posseqCRESTfactor1","posseqCRESTfactor2","posseqCRESTfactor3",
                "posseqIMPULSEfactor",
                "posseqSTD1","posseqSTD2","posseqSTD3",
                "Crestfactorpha","Crestfactorphb","Crestfactorphc",
                "Impulsefactorpha","Impulsefactorphb","Impulsefactorphc",
                "kurtosispha","kurtosisphb","kurtosisphc",
                "meanCurrentpha","meanCurrentphb","meanCurrentphc",
                "Skewnesspha","Skewnessphb","Skewnessphc",
                "STDpha","STDphb","STDphc",
                "kurtosisDCTposseq1","kurtosisDCTposseq2","kurtosisDCTposseq3",
                "meanDCTposseq1","meanDCTposseq2","meanDCTposseq3",
                "rmsDCTposseq1","rmsDCTposseq2","rmsDCTposseq3",
                "SKEWNESSDCTposseq1","SKEWNESSDCTposseq2","SKEWNESSDCTposseq3",
                "stdDCTposseq1","stdDCTposseq2","stdDCTposseq3",
                "Crestfactorposseq1","Crestfactorposseq2","Crestfactorposseq3",
                "IMPULSEfactorDCTposseq"
            ]
        },
        {
            "name": "Supply Harmonics / Grid Pollution",
            "name_fa": "هارمونیک منبع تغذیه",
            "description": "Harmonics from the supply network; THD/THF and DCT‑domain concentration",
            "features": [
                "THDpha","THDphb","THDphc",
                "THFpha","THFphb","THFphc",
                "crstDCTpha","crstDCTphb","crstDCTphc",
                "ImpulsefactorDCTpha","ImpulsefactorDCTphb","ImpulsefactorDCTphc",
                "kurtosisDCTpha","kurtosisDCTphb","kurtosisDCTphc",
                "meanDCTpha","meanDCTphb","meanDCTphc",
                "rmsDCTpha","rmsDCTphb","rmsDCTphc",
                "SkewnessDCTpha","SkewnessDCTphb","SkewnessDCTphc",
                "StdDCTpha","StdDCTphb","StdDCTphc"
            ]
        },
        {
            "name": "Flicker / Transient",
            "name_fa": "فلیکر / گذرا",
            "description": "Slow/fast amplitude modulation; STFT energy variation, EMD crest/std, DCT std",
            "features": [
                "emdcrstfaca","emdcrstfacb","emdcrstfacb",
                "Stftrmsa","Stftrmsb","Stftrmsc",
                "Stftmeana","Stftmeanb","Stftmeanc",
                "Stftstda","Stftstdb","Stftstdc",
                "Stftkurtosisa","Stftkurtosisb","Stftkurtosisb",
                "Stftskewnessa","Stftskewnessb","Stftskewnessc",
                "emdstda","emdstdb","emdstdc",
                "StdDCTpha","StdDCTphb","StdDCTphc",
                "crstDCTpha","crstDCTphb","crstDCTphc"
            ]
        },
        {
            "name": "Unclassified / Other",
            "name_fa": "سایر (طبقه‌بندی نشده)",
            "description": "Features not explicitly assigned to a specific fault in the Excel mapping",
            "features": [
                "emdmeana","emdmeanb","emdmeanc",
                "emdrmsa","emdrmsb","emdrmsc",
                "emdska","emdskb","emdska",
                "psd_raw_max_freq","psd_raw_max_val"
            ]
        }
    ]
}

json_path = os.path.join(data_dir, "fault_classification.json")
with open(json_path, "w", encoding="utf-8") as f:
    json.dump(fault_map, f, indent=2, ensure_ascii=False)
log(f"  Fault classification JSON saved to: {json_path}")