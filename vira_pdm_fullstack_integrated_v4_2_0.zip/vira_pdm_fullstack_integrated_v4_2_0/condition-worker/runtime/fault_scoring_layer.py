"""Production-oriented scoring layer for the supplied MCSA feature extractor.

The feature extraction algorithm remains separate. This module consumes its
feature dictionary/CSV, applies the exact Feature_List2.xlsx classification,
compares every eligible feature against 2x its healthy nominal magnitude, and
creates auditable backend and demo-site payloads.

No Remaining Useful Life (RUL) is estimated here. A percentage of exceeded
features is evidence strength, not a calibrated probability of failure.
"""

from __future__ import annotations

import argparse
import csv
import fnmatch
import json
import math
import statistics
from collections import Counter
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

SCHEMA_VERSION = "2.0"
ENGINE_NAME = "Sina Predict · Excel Feature Evidence"
ENGINE_VERSION = "2.0.0"


# Excel labels and historic aliases -> canonical names emitted/derived from the
# supplied extractor. Canonical keys are never overwritten by aliases.
def _build_aliases() -> dict[str, str]:
    aliases: dict[str, str] = {
        "negIMP": "negseqImpulsefactor",
        "posIMP1": "posseqIMPULSEfactor",
        "maxim": "maxim",
        "fftKurtosis": "fftKurtosis",
        "fftSkewness": "fftSkewness",
        "fftCrest": "fftCrest",
        "fftIMPfac": "fftIMPfac",
        "idkurtosis": "Idkurtosis",
        "iqkurtosis": "Iqkurtosis",
        "idskewness": "Idskewness",
        "iqskewness": "Iqskewness",
        "idcrstfac": "Idcrestfac",
        "iqcrstfac": "Iqcrstfac",
        "idimpfac": "Idimpfac",
        "iqimpfac": "Iqimpfac",
        "idmean": "Idmean",
        "iqmean": "Iqmean",
        "idstd": "Idstd",
        "iqstd": "Iqstd",
        "idRMS": "IdRMS",
        "iqRMS": "IqRMS",
        "entpha": "entropypha",
        "entphb": "entropyphb",
        "entphc": "entropyphc",
        "stftcrsta": "Stftcresta",
        "stftcrstb": "Stftcrestb",
        "stftcrstc": "Stftcrestc",
        "emdstdta": "emdstda",
        "emdstdtb": "emdstdb",
        "emdstdtc": "emdstdc",
    }
    for index in range(1, 4):
        aliases.update(
            {
                f"negRms{index}": f"negseqRMS{index}",
                f"negK{index}": f"negseqkurtosis{index}",
                f"negSK{index}": f"negseqSKEWNESS{index}",
                f"negCrest{index}": f"negseqCrestfactor{index}",
                f"negSDIs{index}": f"negseqSTD{index}",
                f"negmeanIs{index}": f"negseqMean{index}",
                f"posRms{index}": f"posseqRMS{index}",
                f"posKpha{index}": f"posseqkurtosis{index}",
                f"posSK{index}": f"posseqSKEWNESS{index}",
                f"posCrest{index}": f"posseqCRESTfactor{index}",
                f"posSDIs{index}": f"posseqSTD{index}",
                f"posmIs{index}": f"posseqMean{index}",
            }
        )
    for index in range(1, 10):
        aliases.update(
            {
                f"RMSd{index}": f"RMScd{index}",
                f"kd{index}": f"cd{index}kurtosis",
                f"skd{index}": f"Skewnesscd{index}",
                f"IMcd{index}": f"Impulsefactorcd{index}",
                f"Crestd{index}": f"Crestcd{index}",
                f"stdd{index}": f"STDct{index}",
                f"sd{index}": f"STDct{index}",
                f"meand{index}": f"meancd{index}",
                f"m{index}": f"meancd{index}",
            }
        )
    for phase in "abc":
        aliases.update(
            {
                f"Crestph{phase}": f"Crestfactorph{phase}",
                f"IMPph{phase}": f"Impulsefactorph{phase}",
                f"kurtDCTph{phase}": f"kurtosisDCTph{phase}",
                f"skewDCTph{phase}": f"SkewnessDCTph{phase}",
                f"stdDCTph{phase}": f"StdDCTph{phase}",
                f"impfacDCTph{phase}": f"ImpulsefactorDCTph{phase}",
                f"stftrms{phase}": f"Stftrms{phase}",
                f"stftmean{phase}": f"Stftmean{phase}",
                f"stftstd{phase}": f"Stftstd{phase}",
                f"stftkurtosis{phase}": f"Stftkurtosis{phase}",
                f"stftskewness{phase}": f"Stftskewness{phase}",
            }
        )
    return aliases


ALIASES = _build_aliases()


@dataclass(frozen=True)
class FeatureRule:
    name: str
    excel_label: str
    description_fa: str
    direction: str = "magnitude_increase"
    score_enabled: bool = True


@dataclass(frozen=True)
class FaultDefinition:
    code: str
    slug: str
    display_name: str
    display_name_fa: str
    site_section: str
    recommended_action: str
    features: tuple[FeatureRule, ...]


@dataclass
class FeatureEvidence:
    feature_name: str
    excel_label: str
    current_value: float | None
    nominal_abs: float | None
    threshold_abs: float | None
    ratio_to_nominal: float | None
    exceeded: bool | None
    eligible: bool
    status: str
    description_fa: str


@dataclass
class FaultScore:
    fault_code: str
    fault_slug: str
    fault_name: str
    fault_name_fa: str
    severity: str
    evidence_pct: float | None
    coverage_pct: float
    triggered_feature_count: int
    eligible_feature_count: int
    expected_feature_count: int
    present_feature_count: int
    missing_current_count: int
    missing_nominal_count: int
    zero_nominal_count: int
    recommended_action: str
    feature_evidence: list[FeatureEvidence] = field(default_factory=list)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _finite_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def canonicalize_features(features: Mapping[str, Any]) -> dict[str, float]:
    """Keep finite numeric values and copy known aliases to canonical names.

    Duplicate CSV headers may be represented as ``name.1`` by some readers.
    Those duplicate suffixes are ignored if the unsuffixed canonical key exists.
    """
    result: dict[str, float] = {}
    for raw_name, raw_value in features.items():
        name = str(raw_name).strip()
        value = _finite_float(raw_value)
        if value is None:
            continue
        if name.endswith(".1") and name[:-2] in result:
            continue
        result[name] = value

    lower = {name.lower(): name for name in result}
    for alias, canonical in ALIASES.items():
        if canonical in result:
            continue
        source = result.get(alias)
        if source is not None:
            result[canonical] = source
            continue
        source_name = lower.get(alias.lower())
        if source_name is not None:
            result[canonical] = result[source_name]
    return result


def read_json(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json(data: Mapping[str, Any] | Sequence[Any], path: str | Path) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2, allow_nan=False)


def read_feature_rows_from_csv(paths: Sequence[str | Path]) -> list[dict[str, Any]]:
    """Read CSVs while safely handling duplicate headers in the legacy output.

    The first occurrence of a duplicate header wins. This is intentional because
    the original extractor repeats identical columns in three places.
    """
    rows: list[dict[str, Any]] = []
    for path in paths:
        with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.reader(handle)
            try:
                headers = next(reader)
            except StopIteration:
                continue
            first_index: dict[str, int] = {}
            for index, header in enumerate(headers):
                first_index.setdefault(header.strip(), index)
            for values in reader:
                row: dict[str, Any] = {}
                for name, index in first_index.items():
                    row[name] = values[index] if index < len(values) else None
                rows.append(row)
    return rows


def _nearest_rank(values: Sequence[float], percentile: float) -> float:
    ordered = sorted(values)
    if not ordered:
        raise ValueError("Cannot calculate a percentile from no values")
    index = max(0, min(len(ordered) - 1, math.ceil(percentile * len(ordered)) - 1))
    return ordered[index]


def build_nominal_profile(
    healthy_rows: Iterable[Mapping[str, Any]],
    *,
    asset_id: str = "default",
    asset_name: str | None = None,
    operating_regime: str = "default",
    nominal_method: str = "median_abs",
) -> dict[str, Any]:
    """Build a healthy nominal profile for every finite feature.

    Multiple healthy windows are strongly recommended. The requested comparison
    is based on magnitude, therefore ``median_abs`` is the default nominal.
    Additional robust statistics are retained for audit and future tuning.
    """
    if nominal_method not in {"median_abs", "mean_abs", "p95_abs"}:
        raise ValueError("nominal_method must be median_abs, mean_abs, or p95_abs")
    rows = [canonicalize_features(row) for row in healthy_rows]
    if not rows:
        raise ValueError("At least one healthy feature row is required")

    feature_names = sorted({name for row in rows for name in row})
    profile_features: dict[str, Any] = {}
    for name in feature_names:
        signed = [row[name] for row in rows if name in row]
        absolute = [abs(value) for value in signed]
        if not absolute:
            continue
        median_abs = statistics.median(absolute)
        mean_abs = statistics.fmean(absolute)
        p95_abs = _nearest_rank(absolute, 0.95)
        mad_abs = statistics.median(abs(value - median_abs) for value in absolute)
        signed_median = statistics.median(signed)
        nominal_abs = {
            "median_abs": median_abs,
            "mean_abs": mean_abs,
            "p95_abs": p95_abs,
        }[nominal_method]
        profile_features[name] = {
            "nominal_abs": nominal_abs,
            "signed_median": signed_median,
            "median_abs": median_abs,
            "mean_abs": mean_abs,
            "p95_abs": p95_abs,
            "mad_abs": mad_abs,
            "robust_sigma_abs": 1.4826 * mad_abs,
            "minimum": min(signed),
            "maximum": max(signed),
            "sample_count": len(signed),
            "missing_count": len(rows) - len(signed),
        }

    return {
        "schema_version": SCHEMA_VERSION,
        "profile_type": "healthy_nominal",
        "asset_id": asset_id,
        "asset_name": asset_name or asset_id,
        "operating_regime": operating_regime,
        "generated_at": utc_now_iso(),
        "nominal_method": nominal_method,
        "healthy_window_count": len(rows),
        "feature_count": len(profile_features),
        "features": profile_features,
    }


def _flatten_feature_groups(raw_class: Mapping[str, Any]) -> tuple[FeatureRule, ...]:
    rules: list[FeatureRule] = []
    seen: set[str] = set()
    for group in raw_class.get("feature_groups", []):
        for feature_name in group.get("canonical_features", []):
            if feature_name in seen:
                raise ValueError(
                    f"Duplicate feature {feature_name!r} inside fault class {raw_class.get('code')}"
                )
            seen.add(feature_name)
            rules.append(
                FeatureRule(
                    name=feature_name,
                    excel_label=str(group.get("excel_label", "")),
                    description_fa=str(group.get("description_fa", "")),
                    direction=str(group.get("direction", "magnitude_increase")),
                    score_enabled=bool(group.get("score_enabled", True)),
                )
            )
    return tuple(rules)


def validate_config(config: Mapping[str, Any]) -> dict[str, Any]:
    classes = config.get("fault_classes", [])
    if not classes:
        raise ValueError("Config has no fault_classes")
    codes = [item.get("code") for item in classes]
    if len(codes) != len(set(codes)):
        raise ValueError("Fault class codes must be unique")

    assignments = 0
    unique_features: set[str] = set()
    class_counts: dict[str, int] = {}
    for item in classes:
        rules = _flatten_feature_groups(item)
        if not rules:
            raise ValueError(f"Fault class {item.get('code')} has no feature rules")
        assignments += len(rules)
        unique_features.update(rule.name for rule in rules)
        class_counts[str(item["code"])] = len(rules)
        expected = item.get("expected_feature_count")
        if expected is not None and int(expected) != len(rules):
            raise ValueError(
                f"{item['code']} expected_feature_count={expected}, actual={len(rules)}"
            )

    stats = config.get("mapping_statistics", {})
    expected_assignments = stats.get("feature_assignments")
    expected_unique = stats.get("unique_excel_features")
    if expected_assignments is not None and int(expected_assignments) != assignments:
        raise ValueError("mapping_statistics.feature_assignments does not match config")
    if expected_unique is not None and int(expected_unique) != len(unique_features):
        raise ValueError("mapping_statistics.unique_excel_features does not match config")
    return {
        "fault_class_count": len(classes),
        "feature_assignments": assignments,
        "unique_features": len(unique_features),
        "class_counts": class_counts,
    }


class FaultScoringEngine:
    def __init__(self, config: Mapping[str, Any]) -> None:
        validate_config(config)
        self.config = dict(config)
        scoring = config.get("scoring", {})
        self.threshold_multiplier = float(scoring.get("threshold_multiplier", 2.0))
        self.warning_pct = float(scoring.get("warning_evidence_pct", 20.0))
        self.critical_pct = float(scoring.get("critical_evidence_pct", 50.0))
        self.minimum_coverage_pct = float(scoring.get("minimum_class_coverage_pct", 80.0))
        self.zero_nominal_policy = str(scoring.get("zero_nominal_policy", "skip"))
        self.zero_epsilon = float(scoring.get("zero_nominal_epsilon", 1e-12))
        self.top_evidence_limit = int(scoring.get("top_evidence_limit", 5))
        if self.threshold_multiplier <= 0:
            raise ValueError("threshold_multiplier must be positive")
        if not 0 <= self.warning_pct <= self.critical_pct <= 100:
            raise ValueError("Severity thresholds must satisfy 0 <= warning <= critical <= 100")
        if not 0 <= self.minimum_coverage_pct <= 100:
            raise ValueError("minimum_class_coverage_pct must be from 0 to 100")
        if self.zero_nominal_policy not in {"skip", "epsilon"}:
            raise ValueError("zero_nominal_policy must be skip or epsilon")

        self.definitions = tuple(
            FaultDefinition(
                code=str(item["code"]),
                slug=str(item["slug"]),
                display_name=str(item["display_name"]),
                display_name_fa=str(item.get("display_name_fa", "")),
                site_section=str(item.get("site_section", "AI Predictions")),
                recommended_action=str(item.get("recommended_action", "")),
                features=_flatten_feature_groups(item),
            )
            for item in config["fault_classes"]
        )

    @classmethod
    def from_config_file(cls, path: str | Path) -> "FaultScoringEngine":
        return cls(read_json(path))

    @property
    def expected_feature_names(self) -> set[str]:
        return {rule.name for definition in self.definitions for rule in definition.features}

    def mapping_inventory(self, features: Mapping[str, Any]) -> dict[str, Any]:
        canonical = canonicalize_features(features)
        expected = self.expected_feature_names
        present = expected.intersection(canonical)
        class_inventory = []
        for definition in self.definitions:
            names = [rule.name for rule in definition.features]
            present_names = [name for name in names if name in canonical]
            class_inventory.append(
                {
                    "fault_code": definition.code,
                    "expected_feature_count": len(names),
                    "present_feature_count": len(present_names),
                    "raw_presence_pct": round(100 * len(present_names) / len(names), 2),
                    "missing_features": [name for name in names if name not in canonical],
                }
            )
        return {
            "input_feature_count": len(canonical),
            "excel_expected_unique_feature_count": len(expected),
            "excel_present_unique_feature_count": len(present),
            "excel_raw_presence_pct": round(100 * len(present) / len(expected), 2),
            "missing_excel_features": sorted(expected - present),
            "additional_extractor_features": sorted(set(canonical) - expected),
            "classes": class_inventory,
        }

    def _severity(self, evidence_pct: float | None, coverage_pct: float) -> str:
        if evidence_pct is None or coverage_pct < self.minimum_coverage_pct:
            return "INSUFFICIENT_DATA"
        if evidence_pct >= self.critical_pct:
            return "CRITICAL"
        if evidence_pct >= self.warning_pct:
            return "WARNING"
        return "HEALTHY"

    def _nominal_abs(self, profile: Mapping[str, Any], feature_name: str) -> float | None:
        entry = profile.get("features", {}).get(feature_name)
        if entry is None:
            return None
        if isinstance(entry, Mapping):
            for key in ("nominal_abs", "nominal", "median_abs"):
                value = _finite_float(entry.get(key))
                if value is not None:
                    return abs(value)
            return None
        value = _finite_float(entry)
        return abs(value) if value is not None else None

    def _supplemental_context(self, canonical: Mapping[str, float], fault_code: str) -> list[dict[str, Any]]:
        supplemental = self.config.get("supplemental_features", {})
        rows: list[dict[str, Any]] = []
        for group in supplemental.get("groups", []):
            if group.get("fault_code") != fault_code:
                continue
            for name in sorted(canonical):
                if any(fnmatch.fnmatchcase(name, pattern) for pattern in group.get("patterns", [])):
                    rows.append({"feature_name": name, "current_value": canonical[name], "role": group.get("role", "supporting_context")})
        return rows

    def score(
        self,
        features: Mapping[str, Any],
        nominal_profile: Mapping[str, Any],
        *,
        asset_id: str,
        asset_name: str | None = None,
        timestamp: str | None = None,
        operating_regime: str | None = None,
    ) -> dict[str, Any]:
        canonical = canonicalize_features(features)
        timestamp = timestamp or utc_now_iso()
        asset_name = asset_name or asset_id
        scores: list[FaultScore] = []
        supplemental_by_fault: dict[str, list[dict[str, Any]]] = {}

        for definition in self.definitions:
            evidence: list[FeatureEvidence] = []
            present = missing_current = missing_nominal = zero_nominal = 0
            eligible = triggered = 0

            for rule in definition.features:
                current = canonical.get(rule.name)
                nominal = self._nominal_abs(nominal_profile, rule.name)
                if current is None:
                    missing_current += 1
                    evidence.append(FeatureEvidence(rule.name, rule.excel_label, None, nominal, None, None, None, False, "MISSING_CURRENT", rule.description_fa))
                    continue
                present += 1
                if nominal is None:
                    missing_nominal += 1
                    evidence.append(FeatureEvidence(rule.name, rule.excel_label, current, None, None, None, None, False, "MISSING_NOMINAL", rule.description_fa))
                    continue
                if nominal <= self.zero_epsilon and self.zero_nominal_policy == "skip":
                    zero_nominal += 1
                    evidence.append(FeatureEvidence(rule.name, rule.excel_label, current, nominal, None, None, None, False, "ZERO_NOMINAL_SKIPPED", rule.description_fa))
                    continue

                denominator = max(nominal, self.zero_epsilon)
                threshold = self.threshold_multiplier * denominator
                ratio = abs(current) / denominator
                exceeded = bool(rule.score_enabled and abs(current) > threshold)
                if rule.score_enabled:
                    eligible += 1
                    triggered += int(exceeded)
                evidence.append(
                    FeatureEvidence(
                        rule.name,
                        rule.excel_label,
                        current,
                        nominal,
                        threshold,
                        ratio,
                        exceeded,
                        rule.score_enabled,
                        "EXCEEDED" if exceeded else "WITHIN_LIMIT",
                        rule.description_fa,
                    )
                )

            expected = sum(rule.score_enabled for rule in definition.features)
            coverage = 100.0 * eligible / expected if expected else 100.0
            evidence_pct = 100.0 * triggered / eligible if eligible else None
            severity = self._severity(evidence_pct, coverage)
            evidence.sort(
                key=lambda item: (
                    item.exceeded is True,
                    item.ratio_to_nominal if item.ratio_to_nominal is not None else -1.0,
                ),
                reverse=True,
            )
            scores.append(
                FaultScore(
                    fault_code=definition.code,
                    fault_slug=definition.slug,
                    fault_name=definition.display_name,
                    fault_name_fa=definition.display_name_fa,
                    severity=severity,
                    evidence_pct=round(evidence_pct, 2) if evidence_pct is not None else None,
                    coverage_pct=round(coverage, 2),
                    triggered_feature_count=triggered,
                    eligible_feature_count=eligible,
                    expected_feature_count=expected,
                    present_feature_count=present,
                    missing_current_count=missing_current,
                    missing_nominal_count=missing_nominal,
                    zero_nominal_count=zero_nominal,
                    recommended_action=definition.recommended_action,
                    feature_evidence=evidence,
                )
            )
            supplemental_by_fault[definition.code] = self._supplemental_context(canonical, definition.code)

        usable = [score.evidence_pct for score in scores if score.severity != "INSUFFICIENT_DATA" and score.evidence_pct is not None]
        max_evidence = max(usable) if usable else None
        health = round(max(0.0, 100.0 - max_evidence), 2) if max_evidence is not None else None
        critical_count = sum(score.severity == "CRITICAL" for score in scores)
        warning_count = sum(score.severity == "WARNING" for score in scores)
        insufficient_count = sum(score.severity == "INSUFFICIENT_DATA" for score in scores)
        inventory = self.mapping_inventory(canonical)

        return {
            "schema_version": SCHEMA_VERSION,
            "engine": {"name": ENGINE_NAME, "version": ENGINE_VERSION},
            "generated_at": timestamp,
            "asset": {
                "asset_id": asset_id,
                "asset_name": asset_name,
                "operating_regime": operating_regime or nominal_profile.get("operating_regime", "default"),
            },
            "scoring": {
                "comparison": "abs(current_value) > threshold_multiplier * nominal_abs",
                "threshold_multiplier": self.threshold_multiplier,
                "warning_evidence_pct": self.warning_pct,
                "critical_evidence_pct": self.critical_pct,
                "minimum_class_coverage_pct": self.minimum_coverage_pct,
                "zero_nominal_policy": self.zero_nominal_policy,
                "important_note": "Evidence percentage is a feature-vote ratio, not failure probability or RUL.",
            },
            "summary": {
                "plant_health_index": health,
                "active_predictions": critical_count + warning_count,
                "critical_predictions": critical_count,
                "warning_predictions": warning_count,
                "insufficient_data_classes": insufficient_count,
                "excel_feature_presence_pct": inventory["excel_raw_presence_pct"],
            },
            "fault_scores": [
                {
                    **{key: value for key, value in asdict(score).items() if key != "feature_evidence"},
                    "feature_evidence": [asdict(item) for item in score.feature_evidence],
                    "supplemental_context": supplemental_by_fault[score.fault_code],
                }
                for score in scores
            ],
            "mapping_inventory": inventory,
        }

    def to_site_payload(self, report: Mapping[str, Any]) -> dict[str, Any]:
        asset = report["asset"]
        summary = report["summary"]
        generated_at = report["generated_at"]
        fault_scores = list(report.get("fault_scores", []))
        active = [item for item in fault_scores if item["severity"] in {"WARNING", "CRITICAL"}]
        active.sort(key=lambda item: item.get("evidence_pct") or 0.0, reverse=True)

        predictions: list[dict[str, Any]] = []
        alerts: list[dict[str, Any]] = []
        recommendations: list[dict[str, Any]] = []
        for item in active:
            exceeded = [row for row in item.get("feature_evidence", []) if row.get("exceeded") is True]
            top = exceeded[: self.top_evidence_limit]
            explanation = (
                f"{item['triggered_feature_count']} of {item['eligible_feature_count']} eligible Excel-mapped features "
                f"({item['evidence_pct']}%) are above {self.threshold_multiplier:g}× nominal; "
                f"coverage is {item['coverage_pct']}%."
            )
            identifier = f"{asset['asset_id']}:{item['fault_slug']}:{generated_at}"
            predictions.append(
                {
                    "prediction_id": identifier,
                    "asset_id": asset["asset_id"],
                    "asset_name": asset["asset_name"],
                    "fault_code": item["fault_code"],
                    "fault_name": item["fault_name"],
                    "fault_name_fa": item["fault_name_fa"],
                    "severity": item["severity"],
                    "evidence_pct": item["evidence_pct"],
                    "coverage_pct": item["coverage_pct"],
                    "remaining_life_hours": None,
                    "model_name": ENGINE_NAME,
                    "explanation": explanation,
                    "top_evidence": top,
                }
            )
            alerts.append(
                {
                    "alert_id": identifier,
                    "alert_code": item["fault_code"],
                    "asset_id": asset["asset_id"],
                    "asset_name": asset["asset_name"],
                    "severity": "CRITICAL" if item["severity"] == "CRITICAL" else "HIGH",
                    "title": item["fault_name"],
                    "title_fa": item["fault_name_fa"],
                    "message": explanation,
                    "evidence_pct": item["evidence_pct"],
                    "created_at": generated_at,
                    "acknowledged": False,
                }
            )
            recommendations.append(
                {
                    "recommendation_id": identifier,
                    "asset_id": asset["asset_id"],
                    "fault_code": item["fault_code"],
                    "priority": "CRITICAL" if item["severity"] == "CRITICAL" else "HIGH",
                    "recommended_action": item["recommended_action"],
                    "work_order_status": "SUGGESTED",
                }
            )

        analytics = [
            {
                "fault_code": item["fault_code"],
                "fault_name": item["fault_name"],
                "fault_name_fa": item["fault_name_fa"],
                "evidence_pct": item["evidence_pct"],
                "coverage_pct": item["coverage_pct"],
                "severity": item["severity"],
                "triggered_features": item["triggered_feature_count"],
                "eligible_features": item["eligible_feature_count"],
                "expected_features": item["expected_feature_count"],
            }
            for item in sorted(fault_scores, key=lambda row: row.get("evidence_pct") or -1, reverse=True)
        ]
        status = (
            "CRITICAL" if summary["critical_predictions"] else
            "WARNING" if summary["warning_predictions"] else
            "INSUFFICIENT_DATA" if summary["plant_health_index"] is None else
            "HEALTHY"
        )
        return {
            "schema_version": SCHEMA_VERSION,
            "ui_contract": "predictive-operations-v2",
            "generated_at": generated_at,
            "overview": {
                "plant_health": summary["plant_health_index"],
                "critical_alerts": summary["critical_predictions"],
                "active_alerts": summary["active_predictions"],
                "ai_predictions": summary["active_predictions"],
                "excel_feature_presence_pct": summary["excel_feature_presence_pct"],
                "status": status,
            },
            "assets": {
                "total": 1,
                "healthy": int(status == "HEALTHY"),
                "at_risk": int(status == "WARNING"),
                "critical": int(status == "CRITICAL"),
                "items": [
                    {
                        "asset_id": asset["asset_id"],
                        "asset_name": asset["asset_name"],
                        "health": summary["plant_health_index"],
                        "status": status,
                        "operating_regime": asset.get("operating_regime"),
                    }
                ],
            },
            "ai_predictions": {
                "active_models": 1,
                "model_name": ENGINE_NAME,
                "failure_predictions": predictions,
            },
            "alerts": {
                "active": len(alerts),
                "critical": sum(item["severity"] == "CRITICAL" for item in alerts),
                "high": sum(item["severity"] == "HIGH" for item in alerts),
                "alert_stream": alerts,
            },
            "analytics": {
                "plant_health_index": summary["plant_health_index"],
                "fault_class_evidence": analytics,
                "threshold_multiplier": self.threshold_multiplier,
            },
            "maintenance": {"recommended_work_orders": recommendations},
            "diagnostics": {
                "mapping_inventory": report.get("mapping_inventory", {}),
                "insufficient_data_classes": summary["insufficient_data_classes"],
                "rul_available": False,
            },
        }


def score_latest_csv_row(
    features_csv: str | Path,
    nominal_profile_path: str | Path,
    config_path: str | Path,
    *,
    asset_id: str,
    asset_name: str | None = None,
    operating_regime: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    rows = read_feature_rows_from_csv([features_csv])
    if not rows:
        raise ValueError(f"No rows found in {features_csv}")
    engine = FaultScoringEngine.from_config_file(config_path)
    report = engine.score(
        rows[-1],
        read_json(nominal_profile_path),
        asset_id=asset_id,
        asset_name=asset_name,
        operating_regime=operating_regime,
    )
    return report, engine.to_site_payload(report)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="MCSA Excel-mapped fault scoring layer")
    sub = parser.add_subparsers(dest="command", required=True)

    validate = sub.add_parser("validate-config", help="Validate exact Excel mapping counts")
    validate.add_argument("--config", required=True)

    calibrate = sub.add_parser("calibrate", help="Build nominal profile from healthy feature CSVs")
    calibrate.add_argument("--healthy-csv", action="append", required=True)
    calibrate.add_argument("--asset-id", required=True)
    calibrate.add_argument("--asset-name")
    calibrate.add_argument("--operating-regime", default="default")
    calibrate.add_argument("--method", choices=["median_abs", "mean_abs", "p95_abs"], default="median_abs")
    calibrate.add_argument("--output", required=True)

    inspect_cmd = sub.add_parser("inspect", help="Inspect Excel feature coverage in a feature CSV")
    inspect_cmd.add_argument("--features-csv", required=True)
    inspect_cmd.add_argument("--config", required=True)
    inspect_cmd.add_argument("--output")

    score_cmd = sub.add_parser("score", help="Score the latest row of a feature CSV")
    score_cmd.add_argument("--features-csv", required=True)
    score_cmd.add_argument("--nominal-profile", required=True)
    score_cmd.add_argument("--config", required=True)
    score_cmd.add_argument("--asset-id", required=True)
    score_cmd.add_argument("--asset-name")
    score_cmd.add_argument("--operating-regime")
    score_cmd.add_argument("--report-output", required=True)
    score_cmd.add_argument("--site-output", required=True)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if args.command == "validate-config":
        print(json.dumps(validate_config(read_json(args.config)), indent=2))
        return 0
    if args.command == "calibrate":
        profile = build_nominal_profile(
            read_feature_rows_from_csv(args.healthy_csv),
            asset_id=args.asset_id,
            asset_name=args.asset_name,
            operating_regime=args.operating_regime,
            nominal_method=args.method,
        )
        write_json(profile, args.output)
        return 0
    if args.command == "inspect":
        rows = read_feature_rows_from_csv([args.features_csv])
        if not rows:
            raise ValueError(f"No rows found in {args.features_csv}")
        inventory = FaultScoringEngine.from_config_file(args.config).mapping_inventory(rows[-1])
        if args.output:
            write_json(inventory, args.output)
        print(json.dumps(inventory, ensure_ascii=False, indent=2))
        return 0
    if args.command == "score":
        report, site = score_latest_csv_row(
            args.features_csv,
            args.nominal_profile,
            args.config,
            asset_id=args.asset_id,
            asset_name=args.asset_name,
            operating_regime=args.operating_regime,
        )
        write_json(report, args.report_output)
        write_json(site, args.site_output)
        return 0
    raise RuntimeError("Unhandled command")


if __name__ == "__main__":
    raise SystemExit(main())
