#!/usr/bin/env python3
"""Strict preflight audit and optional non-destructive staging for recorded captures.

This module validates the metadata-to-binary contract before any diagnostic
algorithm is executed.  It never edits the user's original files.  When the
metadata duration and binary duration disagree, an explicit policy is required:

* strict: reject the capture;
* trim: copy exactly the metadata-declared sample count to a staging directory;
* use_actual: copy the complete files and update the staged segment end time.

Exact duplicate channels are also detected by SHA-256.  In production mode they
are fatal because independent sensors cannot legitimately have byte-identical
long recordings.  In software-test mode they may be downgraded to warnings so
that execution and database plumbing can still be exercised.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import shutil
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np

CURRENT_CHANNELS = ("CT_A", "CT_B", "CT_C")
VIBRATION_CHANNELS = ("VIB_radial", "VIB_axial")
SUPPORTED_DTYPES = {"float32": "f4", "float64": "f8"}
SUPPORTED_ENDIANS = {"little": "<", "big": ">"}


def utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    os.replace(temp, path)


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def finite_float(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def resolve_metadata_path(archive_dir: Path, metadata_path: Path | None) -> Path:
    if metadata_path:
        result = metadata_path.expanduser().resolve()
        if not result.exists():
            raise FileNotFoundError(result)
        return result
    candidates = [archive_dir / "metadata.json"]
    candidates.extend(sorted(archive_dir.glob("*.json")))
    seen: set[Path] = set()
    for candidate in candidates:
        candidate = candidate.resolve()
        if candidate in seen:
            continue
        seen.add(candidate)
        if candidate.exists():
            return candidate
    raise FileNotFoundError(f"No metadata JSON found in {archive_dir}")


def load_metadata(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError("metadata root must be a JSON object")
    return value


def normalized_fs(metadata: Mapping[str, Any]) -> float:
    monitoring = metadata.get("monitoring_config") or {}
    fs = finite_float(metadata.get("fs", monitoring.get("fs")))
    if fs is None or fs <= 0:
        raise ValueError("metadata must define positive fs or monitoring_config.fs")
    return fs


def normalized_sensors(metadata: Mapping[str, Any]) -> Mapping[str, Any]:
    monitoring = metadata.get("monitoring_config") or {}
    sensors = metadata.get("sensors") or monitoring.get("sensors") or {}
    if not isinstance(sensors, Mapping):
        raise ValueError("metadata sensors must be a JSON object")
    return sensors


def metadata_segments(metadata: Mapping[str, Any]) -> list[dict[str, Any]]:
    segments = metadata.get("segments") or []
    if not isinstance(segments, list) or not segments:
        raise ValueError("metadata must contain at least one explicit segments[] entry")
    result: list[dict[str, Any]] = []
    for index, item in enumerate(segments):
        if not isinstance(item, Mapping):
            raise ValueError(f"segments[{index}] must be an object")
        files = item.get("files")
        if not isinstance(files, Mapping):
            raise ValueError(f"segments[{index}].files must be an object")
        missing = [channel for channel in CURRENT_CHANNELS if not files.get(channel)]
        if missing:
            raise ValueError(f"segments[{index}] is missing required files: {', '.join(missing)}")
        result.append(dict(item))
    return result


def resolve_channel_file(
    reference: str,
    *,
    archive_dir: Path,
    metadata_dir: Path,
    raw_dir: Path,
) -> Path:
    raw_ref = Path(str(reference))
    candidates: list[Path] = []
    if raw_ref.is_absolute():
        candidates.append(raw_ref)
    else:
        candidates.extend(
            [
                metadata_dir / raw_ref,
                archive_dir / raw_ref,
                raw_dir / raw_ref.name,
                archive_dir / "raw" / raw_ref.name,
            ]
        )
    for candidate in candidates:
        candidate = candidate.expanduser().resolve()
        if candidate.exists():
            return candidate
    raise FileNotFoundError(
        f"Could not resolve {reference!r}; checked: "
        + ", ".join(str(c) for c in candidates)
    )


def dtype_from_metadata(metadata: Mapping[str, Any]) -> tuple[str | None, str | None]:
    binary = metadata.get("binary_format") or {}
    if not isinstance(binary, Mapping):
        return None, None
    dtype = str(binary.get("dtype")) if binary.get("dtype") else None
    endian = str(binary.get("endian")) if binary.get("endian") else None
    return dtype, endian


def candidate_score(values: np.ndarray, expected_samples: int | None) -> float:
    if values.size == 0:
        return -1e9
    stride = max(1, values.size // 250_000)
    sample = np.asarray(values[::stride])
    finite = np.isfinite(sample)
    finite_ratio = float(np.mean(finite))
    if finite_ratio < 0.999:
        return -1e6 + finite_ratio
    sample = sample[finite].astype(np.float64, copy=False)
    if sample.size == 0:
        return -1e9
    with np.errstate(over="ignore", invalid="ignore", divide="ignore", under="ignore"):
        p99 = float(np.percentile(np.abs(sample), 99.0))
        std = float(np.std(sample))
    score = 100.0 * finite_ratio
    if 1e-12 < std < 1e6:
        score += 20.0
    if 1e-12 < p99 < 1e6:
        score += 20.0
    # A correctly decoded vibration/current waveform is strongly continuous at
    # the native sampling rate. Reinterpreting adjacent float32 values as one
    # float64 value can still look finite, but it substantially increases the
    # normalized first-difference energy. This term prevents duration metadata
    # errors from incorrectly forcing the detector toward float64.
    if sample.size >= 16 and math.isfinite(std) and std > 1e-15:
        with np.errstate(over="ignore", invalid="ignore", divide="ignore", under="ignore"):
            adjacent = float(np.corrcoef(sample[:-1], sample[1:])[0, 1])
            diff_ratio = float(np.std(np.diff(sample)) / std)
        if math.isfinite(adjacent):
            score += 100.0 * max(0.0, min(1.0, adjacent))
        if math.isfinite(diff_ratio):
            score += 100.0 * math.exp(-5.0 * max(0.0, diff_ratio))
    if expected_samples:
        ratio = values.size / expected_samples
        # Duration is deliberately a weak hint. Metadata can be wrong, while
        # temporal continuity and finite-value plausibility are format evidence.
        score -= 15.0 * abs(math.log(max(ratio, 1e-12)))
    return score


def detect_format(
    path: Path,
    *,
    dtype_request: str,
    endian_request: str,
    expected_samples: int | None,
) -> tuple[str, str, np.dtype]:
    dtypes = list(SUPPORTED_DTYPES) if dtype_request == "auto" else [dtype_request]
    endians = list(SUPPORTED_ENDIANS) if endian_request == "auto" else [endian_request]
    candidates: list[tuple[float, str, str, np.dtype]] = []
    for dtype_name in dtypes:
        for endian_name in endians:
            np_dtype = np.dtype(SUPPORTED_ENDIANS[endian_name] + SUPPORTED_DTYPES[dtype_name])
            if path.stat().st_size % np_dtype.itemsize:
                continue
            values = np.fromfile(path, dtype=np_dtype)
            candidates.append((candidate_score(values, expected_samples), dtype_name, endian_name, np_dtype))
    if not candidates:
        raise ValueError(f"No compatible float32/float64 format for {path}")
    candidates.sort(reverse=True, key=lambda item: item[0])
    _, dtype_name, endian_name, np_dtype = candidates[0]
    return dtype_name, endian_name, np_dtype


def stats(values: np.ndarray, fs: float) -> dict[str, Any]:
    arr = np.asarray(values)
    finite_mask = np.isfinite(arr)
    finite = arr[finite_mask].astype(np.float64, copy=False)
    if finite.size == 0:
        return {
            "samples": int(arr.size),
            "duration_seconds": float(arr.size / fs),
            "finite_pct": 0.0,
        }
    return {
        "samples": int(arr.size),
        "duration_seconds": float(arr.size / fs),
        "finite_pct": float(100.0 * finite_mask.mean()),
        "min": float(np.min(finite)),
        "max": float(np.max(finite)),
        "mean": float(np.mean(finite)),
        "std": float(np.std(finite)),
        "rms": float(np.sqrt(np.mean(finite * finite))),
        "p01": float(np.percentile(finite, 1)),
        "p50": float(np.percentile(finite, 50)),
        "p99": float(np.percentile(finite, 99)),
    }


@dataclass
class ChannelAudit:
    channel: str
    source_path: str
    file_name: str
    size_bytes: int
    sha256: str
    dtype: str
    endian: str
    samples: int
    duration_seconds: float
    finite_pct: float
    raw_stats: dict[str, Any]
    metadata_sensor: dict[str, Any]


@dataclass
class PreflightResult:
    success: bool
    production_eligible: bool
    software_test_eligible: bool
    generated_at: str
    archive_dir: str
    metadata_path: str
    raw_dir: str
    segment_index: int
    asset_id: str
    sample_rate_hz: float
    expected_duration_seconds: float | None
    expected_samples: int | None
    duration_policy: str
    duplicate_policy: str
    channels: list[dict[str, Any]] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    duplicate_groups: list[list[str]] = field(default_factory=list)
    staged_archive_dir: str | None = None
    staged_metadata_path: str | None = None
    staged_raw_dir: str | None = None


def audit_and_stage(
    *,
    archive_dir: Path,
    metadata_path: Path | None,
    raw_dir: Path | None,
    segment_index: int,
    dtype_request: str,
    endian_request: str,
    duration_policy: str,
    duplicate_policy: str,
    staging_dir: Path | None,
    duration_tolerance_samples: int = 1,
) -> PreflightResult:
    archive_dir = archive_dir.expanduser().resolve()
    if not archive_dir.exists():
        raise FileNotFoundError(archive_dir)
    metadata_path = resolve_metadata_path(archive_dir, metadata_path)
    metadata = load_metadata(metadata_path)
    fs = normalized_fs(metadata)
    sensors = normalized_sensors(metadata)
    segments = metadata_segments(metadata)
    if segment_index < 0 or segment_index >= len(segments):
        raise IndexError(f"segment_index={segment_index} outside 0..{len(segments)-1}")
    segment = segments[segment_index]
    files = segment["files"]
    raw_dir = (raw_dir or (archive_dir / "raw")).expanduser().resolve()

    start = finite_float(segment.get("start_ts"))
    end = finite_float(segment.get("end_ts"))
    expected_duration = (end - start) if start is not None and end is not None and end > start else None
    expected_samples = int(round(expected_duration * fs)) if expected_duration else None
    metadata_dtype, metadata_endian = dtype_from_metadata(metadata)
    if dtype_request == "auto" and metadata_dtype in SUPPORTED_DTYPES:
        dtype_request = str(metadata_dtype)
    if endian_request == "auto" and metadata_endian in SUPPORTED_ENDIANS:
        endian_request = str(metadata_endian)

    asset_id = str(metadata.get("asset_id") or metadata.get("motor_id") or metadata.get("id") or "UNKNOWN_ASSET")
    result = PreflightResult(
        success=False,
        production_eligible=False,
        software_test_eligible=False,
        generated_at=utc_iso(),
        archive_dir=str(archive_dir),
        metadata_path=str(metadata_path),
        raw_dir=str(raw_dir),
        segment_index=segment_index,
        asset_id=asset_id,
        sample_rate_hz=fs,
        expected_duration_seconds=expected_duration,
        expected_samples=expected_samples,
        duration_policy=duration_policy,
        duplicate_policy=duplicate_policy,
    )

    channel_records: dict[str, tuple[ChannelAudit, np.dtype, Path]] = {}
    for channel, reference in files.items():
        try:
            source = resolve_channel_file(
                str(reference),
                archive_dir=archive_dir,
                metadata_dir=metadata_path.parent,
                raw_dir=raw_dir,
            )
            dtype_name, endian_name, np_dtype = detect_format(
                source,
                dtype_request=dtype_request,
                endian_request=endian_request,
                expected_samples=expected_samples,
            )
            values = np.fromfile(source, dtype=np_dtype)
            raw_stats = stats(values, fs)
            audit = ChannelAudit(
                channel=str(channel),
                source_path=str(source),
                file_name=source.name,
                size_bytes=source.stat().st_size,
                sha256=sha256_file(source),
                dtype=dtype_name,
                endian=endian_name,
                samples=int(values.size),
                duration_seconds=float(values.size / fs),
                finite_pct=float(raw_stats["finite_pct"]),
                raw_stats=raw_stats,
                metadata_sensor=dict(sensors.get(channel) or {}),
            )
            channel_records[str(channel)] = (audit, np_dtype, source)
            result.channels.append(asdict(audit))
        except Exception as exc:
            result.errors.append(f"{channel}: {type(exc).__name__}: {exc}")

    for required in CURRENT_CHANNELS:
        if required not in channel_records:
            result.errors.append(f"Required channel missing or unreadable: {required}")

    if channel_records:
        sample_counts = {record[0].samples for record in channel_records.values()}
        if len(sample_counts) != 1:
            result.errors.append(
                "Channel sample counts are not synchronized: "
                + ", ".join(f"{name}={rec[0].samples}" for name, rec in sorted(channel_records.items()))
            )
        for name, (audit, _, _) in channel_records.items():
            if audit.finite_pct < 100.0:
                result.errors.append(f"{name} contains non-finite values ({audit.finite_pct:.6f}% finite)")
            if expected_samples is not None and abs(audit.samples - expected_samples) > duration_tolerance_samples:
                message = (
                    f"{name} has {audit.samples} samples ({audit.duration_seconds:.6f}s), "
                    f"but metadata declares {expected_samples} samples ({expected_duration:.6f}s)."
                )
                if duration_policy == "strict":
                    result.errors.append(message)
                else:
                    result.warnings.append(message)

    hashes: dict[str, list[str]] = {}
    for name, (audit, _, _) in channel_records.items():
        hashes.setdefault(audit.sha256, []).append(name)
    duplicate_groups = [sorted(names) for names in hashes.values() if len(names) > 1]
    result.duplicate_groups = duplicate_groups
    for group in duplicate_groups:
        message = "Byte-identical channels detected: " + ", ".join(group)
        if duplicate_policy == "strict":
            result.errors.append(message)
        else:
            result.warnings.append(message)

    if not any(name.startswith("VIB_") for name in channel_records):
        result.warnings.append("No vibration channels were found; vibration diagnosis will be unavailable.")

    # Production eligibility is stricter than software-test eligibility.
    result.production_eligible = not result.errors and not duplicate_groups
    result.software_test_eligible = not any(
        message.startswith("Required channel") or "not synchronized" in message or "non-finite" in message
        for message in result.errors
    )

    if result.errors and not result.software_test_eligible:
        result.success = False
        return result
    if result.errors:
        result.success = False
        return result

    if staging_dir is not None:
        staging_dir = staging_dir.expanduser().resolve()
        if staging_dir.exists():
            shutil.rmtree(staging_dir)
        staged_raw = staging_dir / "raw"
        staged_raw.mkdir(parents=True, exist_ok=True)
        staged_metadata = json.loads(json.dumps(metadata))
        staged_segment = staged_metadata["segments"][segment_index]

        actual_samples = min(rec[0].samples for rec in channel_records.values()) if channel_records else 0
        target_samples = actual_samples
        if expected_samples is not None and duration_policy == "trim":
            if actual_samples < expected_samples:
                result.errors.append(
                    f"Cannot trim to {expected_samples}: shortest channel has only {actual_samples} samples"
                )
                result.success = False
                return result
            target_samples = expected_samples
        elif duration_policy == "use_actual":
            target_samples = actual_samples
            if start is not None:
                staged_segment["end_ts"] = float(start + target_samples / fs)
        elif duration_policy == "strict":
            target_samples = actual_samples

        lineage: dict[str, Any] = {}
        for channel, (audit, np_dtype, source) in channel_records.items():
            destination = staged_raw / source.name
            if target_samples == audit.samples:
                shutil.copy2(source, destination)
            else:
                values = np.fromfile(source, dtype=np_dtype, count=target_samples)
                values.tofile(destination)
            staged_segment["files"][channel] = f"raw/{destination.name}"
            lineage[channel] = {
                "original_path": str(source),
                "original_sha256": audit.sha256,
                "original_samples": audit.samples,
                "staged_path": str(destination),
                "staged_sha256": sha256_file(destination),
                "staged_samples": target_samples,
                "duration_policy": duration_policy,
            }

        staged_metadata.setdefault("binary_format", {})
        unique_formats = {(a.dtype, a.endian) for a, _, _ in channel_records.values()}
        if len(unique_formats) == 1:
            dtype_name, endian_name = next(iter(unique_formats))
            staged_metadata["binary_format"].update({"dtype": dtype_name, "endian": endian_name})
        staged_metadata["preflight_lineage"] = {
            "generated_at": utc_iso(),
            "source_metadata": str(metadata_path),
            "duration_policy": duration_policy,
            "duplicate_policy": duplicate_policy,
            "channels": lineage,
        }
        staged_metadata_path = staging_dir / "metadata.json"
        atomic_json(staged_metadata_path, staged_metadata)
        result.staged_archive_dir = str(staging_dir)
        result.staged_metadata_path = str(staged_metadata_path)
        result.staged_raw_dir = str(staged_raw)

    result.success = True
    return result


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Audit and optionally stage one recorded-data segment")
    p.add_argument("--archive-dir", required=True)
    p.add_argument("--metadata")
    p.add_argument("--raw-dir")
    p.add_argument("--segment-index", type=int, default=0)
    p.add_argument("--dtype", choices=["auto", "float32", "float64"], default="auto")
    p.add_argument("--endian", choices=["auto", "little", "big"], default="auto")
    p.add_argument("--duration-policy", choices=["strict", "trim", "use_actual"], default="strict")
    p.add_argument("--duplicate-policy", choices=["strict", "warn"], default="strict")
    p.add_argument("--staging-dir")
    p.add_argument("--report", required=True)
    return p


def main(argv: Sequence[str] | None = None) -> int:
    args = parser().parse_args(argv)
    result = audit_and_stage(
        archive_dir=Path(args.archive_dir),
        metadata_path=Path(args.metadata) if args.metadata else None,
        raw_dir=Path(args.raw_dir) if args.raw_dir else None,
        segment_index=args.segment_index,
        dtype_request=args.dtype,
        endian_request=args.endian,
        duration_policy=args.duration_policy,
        duplicate_policy=args.duplicate_policy,
        staging_dir=Path(args.staging_dir) if args.staging_dir else None,
    )
    atomic_json(Path(args.report), asdict(result))
    print(json.dumps(asdict(result), ensure_ascii=False, indent=2, allow_nan=False))
    return 0 if result.success else 2


if __name__ == "__main__":
    raise SystemExit(main())
