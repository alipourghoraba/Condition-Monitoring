#!/usr/bin/env python3
"""Three-phase motor input-power and energy calculation.

The acquisition bundle contains three phase-current waveforms but no voltage
waveforms. Therefore this module cannot calculate sample-by-sample active power
p(t) = va(t)ia(t) + vb(t)ib(t) + vc(t)ic(t). Instead it calculates a scientifically
traceable *windowed RMS estimate* using the motor rated RMS voltage and an
explicit measured/nameplate power factor:

    V_phase = V_LL / sqrt(3)                         (line-to-line nameplate voltage)
    S_kVA   = V_phase * (Ia_rms + Ib_rms + Ic_rms) / 1000
    P_kW    = V_phase * PF * (Ia_rms + Ib_rms + Ic_rms) / 1000
    E_kWh   = sum(P_kW_window * window_duration_hours)

For balanced currents this reduces to sqrt(3) * V_LL * I_line_rms * PF / 1000.
The method estimates electrical input consumption. Motor efficiency is not
applied because efficiency is needed for shaft-output power, not input energy.
"""

from __future__ import annotations

import hashlib
import json
import math
import sqlite3
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping

import numpy as np

ENERGY_SCHEMA_VERSION = "1.0"
ENERGY_METHOD = "three_phase_windowed_rms_rated_voltage_pf"


class EnergyConfigurationError(ValueError):
    """Raised when required electrical metadata are unavailable or invalid."""


@dataclass(frozen=True)
class EnergyConfig:
    rated_voltage_v: float
    voltage_basis: str
    power_factor: float
    window_seconds: float

    @property
    def phase_voltage_v(self) -> float:
        if self.voltage_basis == "line_to_line_rms":
            return self.rated_voltage_v / math.sqrt(3.0)
        if self.voltage_basis == "phase_to_neutral_rms":
            return self.rated_voltage_v
        raise EnergyConfigurationError(f"Unsupported voltage_basis: {self.voltage_basis}")


@dataclass(frozen=True)
class EnergyWindow:
    window_index: int
    timestamp: str
    offset_seconds: float
    window_seconds: float
    current_a_rms: float
    current_b_rms: float
    current_c_rms: float
    apparent_kva: float
    active_kw: float
    energy_kwh: float
    cumulative_energy_kwh: float


def _finite_float(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _deep_get(mapping: Mapping[str, Any], *path: str) -> Any:
    current: Any = mapping
    for key in path:
        if not isinstance(current, Mapping):
            return None
        current = current.get(key)
    return current


def _first_finite(metadata: Mapping[str, Any], paths: tuple[tuple[str, ...], ...]) -> float | None:
    for path in paths:
        value = _finite_float(_deep_get(metadata, *path))
        if value is not None:
            return value
    return None


def _first_text(metadata: Mapping[str, Any], paths: tuple[tuple[str, ...], ...]) -> str | None:
    for path in paths:
        value = _deep_get(metadata, *path)
        if value is not None and str(value).strip():
            return str(value).strip()
    return None


def resolve_energy_config(
    metadata: Mapping[str, Any],
    *,
    rated_voltage_override: float | None = None,
    voltage_basis_override: str | None = None,
    power_factor_override: float | None = None,
    window_seconds_override: float | None = None,
) -> EnergyConfig:
    """Resolve energy parameters from CLI overrides or metadata.

    Recommended metadata block::

        "electrical": {
          "rated_voltage_v": 400.0,
          "voltage_basis": "line_to_line_rms",
          "power_factor": 0.86,
          "energy_window_seconds": 1.0
        }

    ``power_factor`` is intentionally required. Assuming PF=1 would convert
    apparent power into a falsely labelled active-energy result.
    """
    rated_voltage = _finite_float(rated_voltage_override)
    if rated_voltage is None:
        rated_voltage = _first_finite(
            metadata,
            (
                ("electrical", "rated_voltage_v"),
                ("electrical", "rated_line_voltage_v"),
                ("monitoring_config", "electrical", "rated_voltage_v"),
                ("monitoring_config", "electrical", "rated_line_voltage_v"),
                ("motor", "rated_voltage_v"),
                ("rated_voltage_v",),
                ("rated_line_voltage_v",),
            ),
        )

    power_factor = _finite_float(power_factor_override)
    if power_factor is None:
        power_factor = _first_finite(
            metadata,
            (
                ("electrical", "power_factor"),
                ("monitoring_config", "electrical", "power_factor"),
                ("motor", "power_factor"),
                ("power_factor",),
            ),
        )

    window_seconds = _finite_float(window_seconds_override)
    if window_seconds is None:
        window_seconds = _first_finite(
            metadata,
            (
                ("electrical", "energy_window_seconds"),
                ("monitoring_config", "electrical", "energy_window_seconds"),
                ("energy_window_seconds",),
            ),
        )
    window_seconds = 1.0 if window_seconds is None else window_seconds

    voltage_basis = voltage_basis_override or _first_text(
        metadata,
        (
            ("electrical", "voltage_basis"),
            ("monitoring_config", "electrical", "voltage_basis"),
            ("motor", "voltage_basis"),
            ("voltage_basis",),
        ),
    )
    voltage_basis = voltage_basis or "line_to_line_rms"

    if rated_voltage is None or rated_voltage <= 0:
        raise EnergyConfigurationError(
            "Energy calculation requires a positive rated_voltage_v, normally the "
            "motor nameplate line-to-line RMS voltage. Add metadata.electrical.rated_voltage_v "
            "or use --rated-voltage-v."
        )
    if power_factor is None or not (0 < power_factor <= 1.0):
        raise EnergyConfigurationError(
            "Active energy calculation requires power_factor in the interval (0, 1]. "
            "Add metadata.electrical.power_factor or use --power-factor. The pipeline "
            "does not silently assume PF=1."
        )
    if window_seconds <= 0:
        raise EnergyConfigurationError("energy_window_seconds must be positive")
    if voltage_basis not in {"line_to_line_rms", "phase_to_neutral_rms"}:
        raise EnergyConfigurationError(
            "voltage_basis must be line_to_line_rms or phase_to_neutral_rms"
        )

    return EnergyConfig(
        rated_voltage_v=float(rated_voltage),
        voltage_basis=voltage_basis,
        power_factor=float(power_factor),
        window_seconds=float(window_seconds),
    )


def _parse_start(value: datetime | str | int | float) -> datetime:
    if isinstance(value, datetime):
        return value.replace(tzinfo=value.tzinfo or timezone.utc).astimezone(timezone.utc)
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(float(value), tz=timezone.utc)
    text = str(value).strip()
    try:
        return datetime.fromtimestamp(float(text), tz=timezone.utc)
    except ValueError:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        return parsed.replace(tzinfo=parsed.tzinfo or timezone.utc).astimezone(timezone.utc)


def _iso_utc(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _load_current(path: Path) -> np.ndarray:
    if not path.exists():
        raise FileNotFoundError(path)
    values = np.loadtxt(path, dtype=np.float64, ndmin=1)
    values = np.asarray(values, dtype=np.float64).reshape(-1)
    if values.size == 0 or not np.all(np.isfinite(values)):
        raise ValueError(f"Current file contains no usable finite samples: {path}")
    return values


def calculate_energy_from_prepared_currents(
    *,
    prepared_dir: str | Path,
    sample_rate_hz: float,
    segment_start: datetime | str | int | float,
    config: EnergyConfig,
    asset_id: str,
    run_id: str,
) -> dict[str, Any]:
    """Calculate per-window three-phase active power and integrated energy."""
    fs = _finite_float(sample_rate_hz)
    if fs is None or fs <= 0:
        raise ValueError("sample_rate_hz must be positive")
    root = Path(prepared_dir)
    ia = _load_current(root / "CT_A.txt")
    ib = _load_current(root / "CT_B.txt")
    ic = _load_current(root / "CT_C.txt")
    lengths = {len(ia), len(ib), len(ic)}
    if len(lengths) != 1:
        raise ValueError(
            f"Current channels are not synchronized: A={len(ia)}, B={len(ib)}, C={len(ic)}"
        )

    samples_per_window = max(1, int(round(fs * config.window_seconds)))
    total_samples = len(ia)
    start_dt = _parse_start(segment_start)
    phase_voltage = config.phase_voltage_v
    windows: list[EnergyWindow] = []
    cumulative = 0.0

    for window_index, start in enumerate(range(0, total_samples, samples_per_window)):
        end = min(total_samples, start + samples_per_window)
        duration_s = (end - start) / fs
        if duration_s <= 0:
            continue
        rms_a = float(np.sqrt(np.mean(np.square(ia[start:end]))))
        rms_b = float(np.sqrt(np.mean(np.square(ib[start:end]))))
        rms_c = float(np.sqrt(np.mean(np.square(ic[start:end]))))
        current_sum = rms_a + rms_b + rms_c
        apparent_kva = phase_voltage * current_sum / 1000.0
        active_kw = apparent_kva * config.power_factor
        energy_kwh = active_kw * duration_s / 3600.0
        cumulative += energy_kwh
        offset_s = end / fs
        timestamp = start_dt + timedelta(seconds=offset_s)
        windows.append(
            EnergyWindow(
                window_index=window_index,
                timestamp=_iso_utc(timestamp),
                offset_seconds=float(offset_s),
                window_seconds=float(duration_s),
                current_a_rms=rms_a,
                current_b_rms=rms_b,
                current_c_rms=rms_c,
                apparent_kva=float(apparent_kva),
                active_kw=float(active_kw),
                energy_kwh=float(energy_kwh),
                cumulative_energy_kwh=float(cumulative),
            )
        )

    if not windows:
        raise ValueError("No energy windows were produced")

    active_values = np.array([item.active_kw for item in windows], dtype=np.float64)
    apparent_values = np.array([item.apparent_kva for item in windows], dtype=np.float64)
    duration_s = total_samples / fs
    time_weighted_average_kw = cumulative * 3600.0 / duration_s if duration_s > 0 else None
    report = {
        "schema_version": ENERGY_SCHEMA_VERSION,
        "available": True,
        "method": ENERGY_METHOD,
        "semantics": (
            "Windowed electrical input-power estimate from three phase-current RMS, "
            "rated RMS voltage, and explicit power factor. It is not sample-level "
            "instantaneous power because voltage waveforms are not acquired."
        ),
        "asset_id": asset_id,
        "capture_id": run_id,
        "segment_start": _iso_utc(start_dt),
        "sample_rate_hz": float(fs),
        "sample_count_per_phase": total_samples,
        "duration_seconds": float(duration_s),
        "configuration": asdict(config),
        "phase_voltage_v": float(phase_voltage),
        "summary": {
            "average_active_kw": float(time_weighted_average_kw),
            "minimum_active_kw": float(np.min(active_values)),
            "maximum_active_kw": float(np.max(active_values)),
            "average_apparent_kva": float(np.average(apparent_values, weights=[w.window_seconds for w in windows])),
            "total_energy_kwh": float(cumulative),
            "window_count": len(windows),
        },
        "series": [asdict(item) for item in windows],
    }
    return report


ENERGY_COLUMNS: dict[str, str] = {
    "asset_id": "TEXT",
    "capture_id": "TEXT",
    "timestamp": "DATETIME",
    "window_index": "INTEGER",
    "window_seconds": "REAL",
    "rated_voltage_v": "REAL",
    "voltage_basis": "TEXT",
    "power_factor": "REAL",
    "current_a_rms": "REAL",
    "current_b_rms": "REAL",
    "current_c_rms": "REAL",
    "apparent_kva": "REAL",
    "energy_kwh": "REAL",
    "cumulative_energy_kwh": "REAL",
    "calculation_method": "TEXT",
    "created_at": "DATETIME",
}


def ensure_energy_schema(connection: sqlite3.Connection) -> bool:
    """Add energy-detail columns to the existing table without deleting data.

    The supplied database originally has only ``id, plant_id, hour, kw``. This
    additive migration preserves those columns and existing rows while enabling
    auditable per-asset energy records.
    """
    table = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='energy_records'"
    ).fetchone()
    migrated = False
    if not table:
        connection.execute(
            """
            CREATE TABLE energy_records (
                id TEXT PRIMARY KEY NOT NULL,
                plant_id TEXT NOT NULL,
                hour TEXT NOT NULL,
                kw REAL NOT NULL,
                asset_id TEXT,
                capture_id TEXT,
                timestamp DATETIME,
                window_index INTEGER,
                window_seconds REAL,
                rated_voltage_v REAL,
                voltage_basis TEXT,
                power_factor REAL,
                current_a_rms REAL,
                current_b_rms REAL,
                current_c_rms REAL,
                apparent_kva REAL,
                energy_kwh REAL,
                cumulative_energy_kwh REAL,
                calculation_method TEXT,
                created_at DATETIME,
                FOREIGN KEY (plant_id) REFERENCES plants (id)
            )
            """
        )
        migrated = True
    else:
        existing = {
            str(row[1]) for row in connection.execute('PRAGMA table_info("energy_records")')
        }
        for name, sql_type in ENERGY_COLUMNS.items():
            if name not in existing:
                connection.execute(f'ALTER TABLE energy_records ADD COLUMN "{name}" {sql_type}')
                migrated = True

    connection.execute(
        "CREATE INDEX IF NOT EXISTS ix_energy_records_plant_hour ON energy_records(plant_id, hour)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS ix_energy_records_asset_timestamp ON energy_records(asset_id, timestamp)"
    )
    connection.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS uq_energy_asset_capture_window "
        "ON energy_records(asset_id, capture_id, window_index)"
    )
    return migrated


def _stable_id(prefix: str, *parts: Any, length: int = 28) -> str:
    raw = "|".join(str(part) for part in parts)
    return f"{prefix}-{hashlib.sha256(raw.encode('utf-8')).hexdigest()[:length]}"


def _hour_bucket(timestamp_text: str) -> str:
    parsed = datetime.fromisoformat(timestamp_text.replace("Z", "+00:00"))
    parsed = parsed.astimezone(timezone.utc).replace(minute=0, second=0, microsecond=0)
    return _iso_utc(parsed)


def persist_energy_report(
    connection: sqlite3.Connection,
    *,
    energy_report: Mapping[str, Any],
    plant_id: str,
    asset_id: str,
    capture_id: str,
) -> dict[str, Any]:
    if not energy_report.get("available"):
        return {"inserted": 0, "ignored": 0, "schema_migrated": False}

    schema_migrated = ensure_energy_schema(connection)
    config = energy_report.get("configuration") or {}
    method = str(energy_report.get("method") or ENERGY_METHOD)
    created_at = datetime.now(timezone.utc).replace(tzinfo=None).isoformat(sep=" ")
    rows: list[tuple[Any, ...]] = []
    for item in energy_report.get("series") or []:
        if not isinstance(item, Mapping):
            continue
        timestamp = str(item["timestamp"])
        index = int(item["window_index"])
        row_id = _stable_id("eng", asset_id, capture_id, index)
        rows.append(
            (
                row_id,
                plant_id,
                _hour_bucket(timestamp),
                float(item["active_kw"]),
                asset_id,
                capture_id,
                timestamp.replace("T", " ").replace("Z", ""),
                index,
                float(item["window_seconds"]),
                float(config["rated_voltage_v"]),
                str(config["voltage_basis"]),
                float(config["power_factor"]),
                float(item["current_a_rms"]),
                float(item["current_b_rms"]),
                float(item["current_c_rms"]),
                float(item["apparent_kva"]),
                float(item["energy_kwh"]),
                float(item["cumulative_energy_kwh"]),
                method,
                created_at,
            )
        )

    before = connection.total_changes
    connection.executemany(
        """
        INSERT OR IGNORE INTO energy_records(
            id, plant_id, hour, kw,
            asset_id, capture_id, timestamp, window_index, window_seconds,
            rated_voltage_v, voltage_basis, power_factor,
            current_a_rms, current_b_rms, current_c_rms,
            apparent_kva, energy_kwh, cumulative_energy_kwh,
            calculation_method, created_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        rows,
    )
    inserted = connection.total_changes - before
    return {
        "inserted": int(inserted),
        "ignored": max(0, len(rows) - int(inserted)),
        "schema_migrated": schema_migrated,
        "record_count": len(rows),
        "summary": energy_report.get("summary") or {},
    }


def write_energy_report(path: str | Path, report: Mapping[str, Any]) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
