#!/usr/bin/env python3
"""Complete rotating-machinery condition-monitoring pipeline.

This is the single production entry point for the supplied MCSA package.
Running this file executes the complete supported path:

    metadata.json + CT_A/B/C .bin (+ optional VIB_*.bin)
        -> binary validation, scaling, and telemetry downsampling
        -> original MCSA extractor
        -> canonical feature adapter
        -> nominal-profile current fault scoring
        -> specialized high-rate vibration diagnosis and trained-model inference
        -> engineering report and UI payload
        -> transactional persistence in the supplied SQLite database

The script never fabricates failure probability, MTBF, MTTR, OEE or model
accuracy. Electrical input energy is calculated by an explicit three-phase RMS
module. Remaining Useful Life is estimated by a deterministic multi-indicator
threshold-crossing engine only when its validation gates pass; otherwise a full
RUL-unavailable record with reason codes is persisted.

The energy schema is extended additively when required. Raw binary files are
preserved by path, hash, format, and statistics in ``raw_sensor_manifest.json``;
the enriched sensor schema also records capture lineage and processing status.
Downsampled UI points are inserted into ``sensor_telemetry``.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import logging
import math
import os
import re
import shutil
import sqlite3
import sys
import traceback
import uuid
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from motor_energy import (
    EnergyConfigurationError,
    calculate_energy_from_prepared_currents,
    persist_energy_report,
    resolve_energy_config,
)
from vibration_diagnostics import persist_vibration_report, run_vibration_diagnostics
from rule_based_rul import load_config as load_rul_config, persist_rule_based_rul
from database_contract import (
    calculate_data_quality_score,
    capture_database_counts,
    derive_health_scores,
    ensure_full_diagnostic_schema,
    persist_health_assessment,
    persist_mcsa_report,
    persist_stage_result,
)

SCRIPT_VERSION = "4.1.0"
LOGGER = logging.getLogger("vira_condition_pipeline")


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------

def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def utc_iso(value: datetime | None = None) -> str:
    dt = value or utc_now()
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def sqlite_datetime(value: datetime) -> str:
    """SQLite-friendly UTC datetime without a timezone suffix."""
    return value.astimezone(timezone.utc).replace(tzinfo=None).isoformat(sep=" ")


def finite_float(value: Any, default: float | None = None) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return number if math.isfinite(number) else default


def clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


def json_safe(value: Any) -> Any:
    """Recursively remove non-finite values and normalize non-JSON objects."""
    if isinstance(value, Mapping):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, datetime):
        return utc_iso(value)
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", encoding="utf-8") as handle:
        json.dump(json_safe(payload), handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    os.replace(temp, path)


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        result = json.load(handle)
    if not isinstance(result, dict):
        raise ValueError(f"Expected JSON object in {path}")
    return result


def read_single_feature_row(path: Path) -> dict[str, float]:
    """Read the canonical one-row feature CSV produced by the adapter."""
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        row = next(reader, None)
    if row is None:
        raise ValueError(f"Canonical feature CSV has no data row: {path}")
    result: dict[str, float] = {}
    for name, raw in row.items():
        value = finite_float(raw)
        if value is not None:
            result[str(name)] = value
    if not result:
        raise ValueError(f"Canonical feature CSV has no finite numeric values: {path}")
    return result


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def stable_id(prefix: str, *parts: Any, length: int = 24) -> str:
    raw = "|".join(str(part) for part in parts)
    token = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:length]
    return f"{prefix}-{token}"


def slug(value: Any, fallback: str) -> str:
    text = str(value or "").strip().upper()
    text = re.sub(r"[^A-Z0-9]+", "-", text).strip("-")
    return text or fallback


def table_columns(connection: sqlite3.Connection, table: str) -> set[str]:
    return {str(row[1]) for row in connection.execute(f'PRAGMA table_info("{table}")')}


def table_exists(connection: sqlite3.Connection, table: str) -> bool:
    row = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
    ).fetchone()
    return row is not None


def configure_logging(log_path: Path, verbose: bool) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    level = logging.DEBUG if verbose else logging.INFO
    LOGGER.setLevel(level)
    LOGGER.handlers.clear()
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    stream = logging.StreamHandler(sys.stdout)
    stream.setLevel(level)
    stream.setFormatter(formatter)
    LOGGER.addHandler(stream)

    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    LOGGER.addHandler(file_handler)


# ---------------------------------------------------------------------------
# Data models used by this orchestrator
# ---------------------------------------------------------------------------

@dataclass
class DatabaseWriteStats:
    plant_upserts: int = 0
    zone_upserts: int = 0
    asset_upserts: int = 0
    sensor_upserts: int = 0
    sensor_outputs_updated: int = 0
    raw_blobs_stored: int = 0
    telemetry_inserted: int = 0
    telemetry_ignored: int = 0
    health_history_inserted: int = 0
    health_history_updated: int = 0
    alerts_inserted: int = 0
    alerts_updated: int = 0
    failure_modes_upserted: int = 0
    mcsa_analyses_upserted: int = 0
    mcsa_features_upserted: int = 0
    mcsa_fault_evidence_upserted: int = 0
    health_assessments_upserted: int = 0
    pipeline_stage_results_upserted: int = 0
    processing_runs_upserted: int = 0
    energy_records_inserted: int = 0
    energy_records_ignored: int = 0
    energy_schema_migrated: bool = False
    vibration_analyses_upserted: int = 0
    vibration_features_upserted: int = 0
    vibration_fault_evidence_upserted: int = 0
    vibration_method_executions_upserted: int = 0
    vibration_model_results_upserted: int = 0
    rul_history_upserted: int = 0
    rul_state_upserted: int = 0
    rul_estimates_upserted: int = 0
    rul_predictions_upserted: int = 0
    asset_rul_updated: int = 0
    predictions_skipped: int = 0
    work_orders_skipped: int = 0
    plant_health_updated: bool = False
    zone_health_updated: bool = False
    warnings: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class AssetContext:
    asset_id: str
    asset_name: str
    asset_type: str
    plant_id: str
    plant_name: str
    zone_id: str
    zone_name: str


# ---------------------------------------------------------------------------
# Pipeline import and validation
# ---------------------------------------------------------------------------

def import_pipeline(module_dir: Path):
    """Import the supplied processing modules from one explicit directory."""
    module_dir = module_dir.resolve()
    if str(module_dir) not in sys.path:
        sys.path.insert(0, str(module_dir))

    required = [
        "mcsa_pipeline_runner_bin.py",
        "mcsa_bin_ingestion.py",
        "mcsa_feature_adapter.py",
        "fault_scoring_layer.py",
        "mcsa_enhanced_agah_algorithms.py",
        "motor_energy.py",
        "vibration_diagnostics.py",
        "vibration_core",
        "rule_based_rul.py",
        "database_contract.py",
    ]
    missing = [name for name in required if not (module_dir / name).exists()]
    if missing:
        raise FileNotFoundError(
            f"Missing required processing files in {module_dir}: {', '.join(missing)}"
        )

    try:
        from mcsa_pipeline_runner_bin import run_bin_pipeline  # type: ignore
    except Exception as exc:
        raise RuntimeError(
            "Could not import the supplied binary MCSA pipeline. Install its "
            "dependencies (numpy, pandas, scipy, PyWavelets, EMD-signal) and "
            "keep this entry file beside the supplied modules."
        ) from exc
    return run_bin_pipeline


def validate_database_schema(connection: sqlite3.Connection) -> None:
    required_columns = {
        "plants": {"id", "name", "timezone", "health_score", "uptime"},
        "zones": {"id", "plant_id", "name", "health", "bounding_box"},
        "assets": {"id", "plant_id", "zone_id", "name", "type", "health", "health_score", "status"},
        "sensors": {"id", "asset_id", "type", "status"},
        "sensor_telemetry": {"id", "sensor_id", "timestamp", "value", "unit"},
        "asset_health_history": {"id", "asset_id", "date", "health"},
        "alerts": {
            "id", "severity", "asset_id", "code", "message", "timestamp",
            "acknowledged", "resolved",
        },
        "failure_modes": {"id", "plant_id", "name", "value"},
        "mcsa_analysis_runs": {"id", "asset_id", "capture_id", "current_health_score", "report_json"},
        "mcsa_feature_values": {"id", "analysis_id", "feature_name", "value"},
        "mcsa_fault_evidence": {"id", "analysis_id", "fault_code", "severity"},
        "health_assessments": {"id", "asset_id", "capture_id", "overall_health_score"},
        "pipeline_stage_results": {"id", "capture_id", "stage_name", "status"},
    }
    problems: list[str] = []
    for table, expected in required_columns.items():
        if not table_exists(connection, table):
            problems.append(f"missing table {table}")
            continue
        actual = table_columns(connection, table)
        missing = sorted(expected - actual)
        if missing:
            problems.append(f"table {table} is missing columns: {', '.join(missing)}")
    if table_exists(connection, "sensors"):
        sensor_cols = table_columns(connection, "sensors")
        if not ({"sample_rate"} <= sensor_cols or {"sample_rate_hz"} <= sensor_cols):
            problems.append("table sensors must contain sample_rate or sample_rate_hz")
    if problems:
        raise RuntimeError("Database schema is incompatible: " + "; ".join(problems))


# ---------------------------------------------------------------------------
# Metadata, data quality, and UI normalization
# ---------------------------------------------------------------------------

def load_original_metadata(metadata_path: Path) -> dict[str, Any]:
    metadata = read_json(metadata_path)
    monitoring = metadata.get("monitoring_config") or {}
    sensors = metadata.get("sensors") or monitoring.get("sensors") or {}
    metadata["_normalized_sensors"] = sensors if isinstance(sensors, dict) else {}
    metadata["_normalized_fs"] = metadata.get("fs", monitoring.get("fs"))
    return metadata


def resolve_segment_start(segment: Mapping[str, Any], fallback: datetime) -> datetime:
    raw = segment.get("start_ts")
    if raw is None:
        return fallback
    if isinstance(raw, (int, float)):
        return datetime.fromtimestamp(float(raw), tz=timezone.utc)
    text = str(raw).strip()
    if not text:
        return fallback
    try:
        return datetime.fromtimestamp(float(text), tz=timezone.utc)
    except ValueError:
        pass
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        return parsed.replace(tzinfo=parsed.tzinfo or timezone.utc).astimezone(timezone.utc)
    except ValueError:
        return fallback


def derive_overall_status(report: Mapping[str, Any]) -> str:
    severities = {str(item.get("severity", "")).upper() for item in report.get("fault_scores", [])}
    if "CRITICAL" in severities:
        return "critical"
    if "WARNING" in severities:
        return "warning"
    summary = report.get("summary") or {}
    if summary.get("plant_health_index") is None:
        return "offline" if severities == {"INSUFFICIENT_DATA"} else "unknown"
    return "healthy"


def build_data_quality(manifest: Mapping[str, Any], report: Mapping[str, Any]) -> dict[str, Any]:
    channels = manifest.get("channels") or {}
    current_counts: dict[str, int] = {}
    finite_channels = True
    for channel in ("CT_A", "CT_B", "CT_C"):
        details = channels.get(channel) or {}
        stats = details.get("scaled_stats") or {}
        count = int(stats.get("samples") or 0)
        current_counts[channel] = count
        finite_channels = finite_channels and count > 0

    counts = list(current_counts.values())
    synchronized = bool(counts) and min(counts) == max(counts) and min(counts) > 0
    inventory = report.get("mapping_inventory") or {}
    summary = report.get("summary") or {}
    insufficient = int(summary.get("insufficient_data_classes") or 0)

    return {
        "required_current_channels_present": finite_channels,
        "current_channel_sample_counts": current_counts,
        "current_channels_equal_length": synchronized,
        "sample_rate_hz": manifest.get("fs"),
        "excel_feature_presence_pct": summary.get("excel_feature_presence_pct"),
        "canonical_feature_count": inventory.get("runtime_feature_count"),
        "missing_excel_features": inventory.get("missing_excel_features", []),
        "insufficient_data_classes": insufficient,
        "diagnosis_usable": finite_channels and synchronized and insufficient < 8,
    }


def validate_current_channel_alignment(manifest: Mapping[str, Any]) -> None:
    channels = manifest.get("channels") or {}
    counts: dict[str, int] = {}
    for channel in ("CT_A", "CT_B", "CT_C"):
        details = channels.get(channel)
        if not isinstance(details, Mapping):
            raise RuntimeError(f"Ingestion manifest has no details for required channel {channel}")
        count = int(((details.get("scaled_stats") or {}).get("samples")) or 0)
        if count <= 0:
            raise RuntimeError(f"Required current channel {channel} has no finite samples")
        counts[channel] = count
    if len(set(counts.values())) != 1:
        raise RuntimeError(
            "CT_A, CT_B and CT_C are not synchronized: "
            + ", ".join(f"{key}={value}" for key, value in counts.items())
        )


def create_raw_sensor_manifest(
    manifest: Mapping[str, Any],
    metadata: Mapping[str, Any],
    run_id: str,
) -> dict[str, Any]:
    channels_out: dict[str, Any] = {}
    segment_files = ((manifest.get("segment") or {}).get("files") or {})
    loaded_channels = manifest.get("channels") or {}

    all_names = sorted(set(segment_files) | set(loaded_channels))
    for channel in all_names:
        details = loaded_channels.get(channel) or {}
        path_value = details.get("file_path")
        file_path = Path(path_value).resolve() if path_value and Path(path_value).exists() else None
        channels_out[channel] = {
            "channel": channel,
            "source_reference": segment_files.get(channel),
            "file_path": str(file_path) if file_path else path_value,
            "file_size_bytes": file_path.stat().st_size if file_path else None,
            "sha256": sha256_file(file_path) if file_path else None,
            "dtype": details.get("dtype"),
            "endian": details.get("endian"),
            "sample_rate_hz": details.get("sample_rate_hz", manifest.get("fs")),
            "scale_mode": details.get("scale_mode", manifest.get("scale_mode")),
            "raw_stats": details.get("raw_stats"),
            "scaled_stats": details.get("scaled_stats"),
            "sensor_metadata": (metadata.get("_normalized_sensors") or {}).get(channel, {}),
        }

    return {
        "schema_version": "1.0",
        "run_id": run_id,
        "generated_at": utc_iso(),
        "asset": manifest.get("asset", {}),
        "segment_index": manifest.get("segment_index"),
        "segment": manifest.get("segment"),
        "channels": channels_out,
        "storage_note": (
            "Raw binary payloads are referenced by immutable path and SHA-256. "
            "Capture metadata is persisted in sensors; the large binary BLOB is "
            "not duplicated into SQLite by this worker."
        ),
    }


def build_ui_payload(
    *,
    site_payload: Mapping[str, Any],
    report: Mapping[str, Any],
    telemetry: Mapping[str, Any],
    manifest: Mapping[str, Any],
    data_quality: Mapping[str, Any],
    energy_report: Mapping[str, Any],
    vibration_report: Mapping[str, Any],
    rul_report: Mapping[str, Any],
    run_id: str,
    output_paths: Mapping[str, str],
) -> dict[str, Any]:
    result = json.loads(json.dumps(json_safe(site_payload)))
    signals = telemetry.get("signals") or {}
    sensor_streams: list[dict[str, Any]] = []
    for channel, signal in signals.items():
        if not isinstance(signal, Mapping):
            continue
        if signal.get("error"):
            sensor_streams.append({"channel": channel, "status": "error", "error": signal["error"]})
            continue
        values = list(signal.get("values") or [])
        times = list(signal.get("time") or [])
        latest = values[-1] if values else None
        sensor_streams.append(
            {
                "sensor_id": None,  # populated after database persistence
                "channel": channel,
                "type": str(channel).split("_")[0].lower(),
                "status": "streaming" if values else "no_data",
                "unit": signal.get("units"),
                "source_sample_rate_hz": signal.get("sample_rate_hz"),
                "display_sample_rate_hz": signal.get("target_rate_hz"),
                "latest_value": latest,
                "statistics": signal.get("stats", {}),
                "series": [
                    {"offset_s": finite_float(t), "value": finite_float(v)}
                    for t, v in zip(times, values)
                ],
            }
        )

    result["sensor_streams"] = sensor_streams
    result["data_quality"] = dict(data_quality)
    result["energy"] = json_safe(energy_report)
    result["vibration"] = json_safe(vibration_report)
    result["rul"] = json_safe(rul_report)
    result["processing_run"] = {
        "run_id": run_id,
        "pipeline_version": SCRIPT_VERSION,
        "generated_at": report.get("generated_at"),
        "segment_index": manifest.get("segment_index"),
        "sample_rate_hz": manifest.get("fs"),
        "scale_mode": manifest.get("scale_mode"),
        "outputs": dict(output_paths),
    }
    result.setdefault("diagnostics", {})["rul_available"] = bool((rul_report.get("summary") or {}).get("asset_rul_available"))
    result["diagnostics"]["rul_semantics"] = (rul_report.get("summary") or {}).get("semantics")
    result["diagnostics"]["probability_available"] = False
    result["diagnostics"]["evidence_semantics"] = (
        "evidence_pct is the ratio of eligible mapped features above the configured "
        "nominal threshold; it is not failure probability or RUL."
    )
    return result


# ---------------------------------------------------------------------------
# SQLite resolution and persistence
# ---------------------------------------------------------------------------

def lookup_id_by_name(connection: sqlite3.Connection, table: str, name: str | None) -> str | None:
    if not name:
        return None
    row = connection.execute(
        f'SELECT id FROM "{table}" WHERE lower(name)=lower(?) LIMIT 1', (str(name),)
    ).fetchone()
    return str(row[0]) if row else None


def resolve_asset_context(
    connection: sqlite3.Connection,
    *,
    asset: Mapping[str, Any],
    metadata: Mapping[str, Any],
    plant_id_override: str | None,
    zone_id_override: str | None,
) -> AssetContext:
    asset_id = str(asset.get("asset_id") or metadata.get("asset_id") or metadata.get("motor_id") or "UNKNOWN_ASSET")
    asset_name = str(asset.get("asset_name") or metadata.get("asset_name") or metadata.get("name") or asset_id)
    asset_type = str(metadata.get("asset_type") or "Motor")

    existing = connection.execute(
        "SELECT plant_id, zone_id, name, type FROM assets WHERE id=?", (asset_id,)
    ).fetchone()
    if existing:
        return AssetContext(
            asset_id=asset_id,
            asset_name=asset_name or str(existing[2]),
            asset_type=asset_type or str(existing[3]),
            plant_id=str(existing[0]),
            plant_name=str(metadata.get("plant") or existing[0]),
            zone_id=str(existing[1]),
            zone_name=str(metadata.get("zone") or existing[1]),
        )

    raw_plant = metadata.get("plant") or (asset.get("plant") if isinstance(asset, Mapping) else None)
    plant_id = plant_id_override
    if not plant_id:
        candidate = str(raw_plant) if raw_plant else None
        if candidate and connection.execute("SELECT 1 FROM plants WHERE id=?", (candidate,)).fetchone():
            plant_id = candidate
        else:
            plant_id = lookup_id_by_name(connection, "plants", candidate)
    if not plant_id:
        rows = connection.execute("SELECT id FROM plants ORDER BY id LIMIT 2").fetchall()
        if len(rows) == 1:
            plant_id = str(rows[0][0])
        else:
            plant_id = slug(raw_plant, "PLANT-DEFAULT")
    plant_name = str(raw_plant or plant_id)

    raw_zone = metadata.get("zone") or (asset.get("zone") if isinstance(asset, Mapping) else None)
    zone_id = zone_id_override
    if not zone_id:
        candidate = str(raw_zone) if raw_zone else None
        if candidate and connection.execute(
            "SELECT 1 FROM zones WHERE id=? AND plant_id=?", (candidate, plant_id)
        ).fetchone():
            zone_id = candidate
        elif candidate:
            row = connection.execute(
                "SELECT id FROM zones WHERE plant_id=? AND lower(name)=lower(?) LIMIT 1",
                (plant_id, candidate),
            ).fetchone()
            zone_id = str(row[0]) if row else None
    if not zone_id:
        rows = connection.execute(
            "SELECT id FROM zones WHERE plant_id=? ORDER BY id LIMIT 2", (plant_id,)
        ).fetchall()
        if len(rows) == 1:
            zone_id = str(rows[0][0])
        else:
            zone_id = slug(raw_zone, f"{plant_id}-ZONE-DEFAULT")
    zone_name = str(raw_zone or zone_id)

    return AssetContext(
        asset_id=asset_id,
        asset_name=asset_name,
        asset_type=asset_type,
        plant_id=str(plant_id),
        plant_name=plant_name,
        zone_id=str(zone_id),
        zone_name=zone_name,
    )


def upsert_plant_zone_asset(
    connection: sqlite3.Connection,
    context: AssetContext,
    *,
    health: float | None,
    status: str,
    timezone_name: str,
    stats: DatabaseWriteStats,
) -> None:
    existing_plant = connection.execute("SELECT 1 FROM plants WHERE id=?", (context.plant_id,)).fetchone()
    if existing_plant:
        connection.execute(
            "UPDATE plants SET name=COALESCE(NULLIF(?, ''), name), timezone=COALESCE(NULLIF(?, ''), timezone) WHERE id=?",
            (context.plant_name, timezone_name, context.plant_id),
        )
    else:
        connection.execute(
            "INSERT INTO plants(id,name,timezone,health_score,uptime) VALUES(?,?,?,?,?)",
            (context.plant_id, context.plant_name, timezone_name, health or 0.0, 0.0),
        )
    stats.plant_upserts += 1

    existing_zone = connection.execute("SELECT 1 FROM zones WHERE id=?", (context.zone_id,)).fetchone()
    if existing_zone:
        connection.execute(
            "UPDATE zones SET plant_id=?, name=COALESCE(NULLIF(?, ''), name) WHERE id=?",
            (context.plant_id, context.zone_name, context.zone_id),
        )
    else:
        connection.execute(
            "INSERT INTO zones(id,plant_id,name,health,bounding_box) VALUES(?,?,?,?,?)",
            (context.zone_id, context.plant_id, context.zone_name, health or 0.0, "{}"),
        )
    stats.zone_upserts += 1

    existing_asset = connection.execute("SELECT 1 FROM assets WHERE id=?", (context.asset_id,)).fetchone()
    normalized_health = clamp(float(health), 0.0, 100.0) if health is not None else 0.0
    if existing_asset:
        # Keep assets.rul unchanged here; the dedicated RUL stage updates or clears it later.
        connection.execute(
            """
            UPDATE assets
               SET plant_id=?, zone_id=?, name=?, type=?, health=?, health_score=?, health_method=?, health_updated_at=?, status=?
             WHERE id=?
            """,
            (
                context.plant_id,
                context.zone_id,
                context.asset_name,
                context.asset_type,
                normalized_health,
                normalized_health,
                "conservative_minimum_of_available_modalities",
                sqlite_datetime(utc_now()),
                status,
                context.asset_id,
            ),
        )
    else:
        connection.execute(
            """
            INSERT INTO assets(
                id,plant_id,zone_id,name,type,health,health_score,health_method,health_updated_at,status,rul,
                manufacturer,model,install_date,last_maintenance,
                component_count,criticality,x,y
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                context.asset_id,
                context.plant_id,
                context.zone_id,
                context.asset_name,
                context.asset_type,
                normalized_health,
                normalized_health,
                "conservative_minimum_of_available_modalities",
                sqlite_datetime(utc_now()),
                status,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
            ),
        )
    stats.asset_upserts += 1


def sensor_identifier(asset_id: str, channel: str) -> str:
    return slug(f"{asset_id}-{channel}", stable_id("SNS", asset_id, channel, length=16))


def sensor_type_name(channel: str, spec: Mapping[str, Any]) -> str:
    sensor_type = str(spec.get("type") or "unknown").strip().lower()
    if sensor_type == "current":
        return f"Motor Current {channel}"
    if sensor_type == "vibration":
        return f"Vibration {channel}"
    return f"{sensor_type.title()} {channel}".strip()


def upsert_sensors(
    connection: sqlite3.Connection,
    *,
    context: AssetContext,
    metadata: Mapping[str, Any],
    telemetry: Mapping[str, Any],
    manifest: Mapping[str, Any],
    run_id: str,
    segment_start: datetime,
    stats: DatabaseWriteStats,
) -> dict[str, str]:
    """Upsert sensors against either the legacy or enriched Vira schema."""
    specs = metadata.get("_normalized_sensors") or {}
    signal_names = set((telemetry.get("signals") or {}).keys())
    signal_names.update((manifest.get("channels") or {}).keys())
    signal_names.update(specs.keys())
    mapping: dict[str, str] = {}
    columns = table_columns(connection, "sensors")
    rich_schema = {
        "name", "channel_index", "sample_rate_hz", "unit",
        "calibration_config", "raw_data_type", "raw_endian",
    }.issubset(columns)

    sorted_channels = sorted(str(name) for name in signal_names)
    used_indices: set[int] = set()
    for fallback_index, channel in enumerate(sorted_channels):
        spec = specs.get(channel) if isinstance(specs, Mapping) else {}
        if not isinstance(spec, Mapping):
            spec = {}
        details = (manifest.get("channels") or {}).get(channel) or {}
        sensor_id = sensor_identifier(context.asset_id, channel)
        mapping[channel] = sensor_id
        protocol = spec.get("protocol") or metadata.get("protocol") or "File/Batch"
        sample_rate_hz = float(details.get("sample_rate_hz") or manifest.get("fs") or 0)
        sample_rate = f"{sample_rate_hz:g} Hz"
        status = "Online"
        source_sensor_kind = str(spec.get("type") or ("current" if channel.startswith("CT_") else "vibration")).lower()
        # The current application schema intentionally has two physical sensor
        # families. Encoder/phase auxiliary streams are stored in the
        # vibration-compatible family while preserving their true source type
        # and engineering unit in calibration/raw metadata.
        sensor_kind = source_sensor_kind if source_sensor_kind in {"current", "vibration"} else ("current" if channel.startswith("CT_") else "vibration")
        unit = str(spec.get("unit") or ("A" if sensor_kind == "current" else "rad" if source_sensor_kind == "encoder" else "g"))
        requested_index = spec.get("channel_index")
        try:
            channel_index = int(requested_index)
        except (TypeError, ValueError):
            channel_index = fallback_index
        while channel_index in used_indices:
            channel_index += 1
        used_indices.add(channel_index)
        existing = connection.execute("SELECT 1 FROM sensors WHERE id=?", (sensor_id,)).fetchone()

        if rich_schema:
            stats_obj = details.get("scaled_stats") or {}
            source_path = details.get("file_path")
            source_name = Path(str(source_path)).name if source_path else str((((manifest.get("segment") or {}).get("files") or {}).get(channel)) or "")
            raw_metadata = {
                "file_path": source_path,
                "scale_mode": details.get("scale_mode", manifest.get("scale_mode")),
                "raw_stats": details.get("raw_stats"),
                "scaled_stats": details.get("scaled_stats"),
                "segment_index": manifest.get("segment_index"),
                "source_sensor_type": source_sensor_kind,
            }
            values = (
                context.asset_id,
                channel,
                sensor_kind,
                channel_index,
                sample_rate_hz,
                unit,
                json.dumps(json_safe(spec), ensure_ascii=False),
                str(details.get("dtype") or "float64"),
                str(details.get("endian") or "little"),
                run_id,
                source_name,
                sqlite_datetime(segment_start),
                int(stats_obj.get("samples") or 0),
                finite_float(stats_obj.get("duration_s")),
                json.dumps(json_safe(raw_metadata), ensure_ascii=False),
                "completed",
                None,
                sqlite_datetime(utc_now()),
                spec.get("battery"),
                spec.get("firmware"),
                status,
                spec.get("installation_date"),
                spec.get("last_calibration"),
                str(protocol),
                spec.get("rssi"),
                sensor_id,
            )
            if existing:
                connection.execute(
                    """
                    UPDATE sensors SET
                        asset_id=?, name=?, type=?, channel_index=?, sample_rate_hz=?, unit=?,
                        calibration_config=?, raw_data_type=?, raw_endian=?, raw_capture_id=?,
                        raw_file_name=?, raw_captured_at=?, raw_sample_count=?, raw_duration_seconds=?,
                        raw_metadata=?, processing_status=?, processing_error=?, last_processed_at=?,
                        battery=?, firmware=?, status=?, installation_date=?, last_calibration=?, protocol=?, rssi=?
                    WHERE id=?
                    """,
                    values,
                )
            else:
                connection.execute(
                    """
                    INSERT INTO sensors(
                        asset_id,name,type,channel_index,sample_rate_hz,unit,calibration_config,
                        raw_data_type,raw_endian,raw_capture_id,raw_file_name,raw_captured_at,
                        raw_sample_count,raw_duration_seconds,raw_metadata,processing_status,
                        processing_error,last_processed_at,battery,firmware,status,installation_date,
                        last_calibration,protocol,rssi,id
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    values,
                )
        else:
            values = (
                context.asset_id,
                sensor_type_name(channel, spec),
                sample_rate,
                spec.get("battery"),
                spec.get("firmware"),
                status,
                spec.get("installation_date"),
                spec.get("last_calibration"),
                str(protocol),
                spec.get("rssi"),
                sensor_id,
            )
            if existing:
                connection.execute(
                    """
                    UPDATE sensors
                       SET asset_id=?, type=?, sample_rate=?, battery=?, firmware=?,
                           status=?, installation_date=?, last_calibration=?, protocol=?, rssi=?
                     WHERE id=?
                    """,
                    values,
                )
            else:
                connection.execute(
                    """
                    INSERT INTO sensors(
                        asset_id,type,sample_rate,battery,firmware,status,
                        installation_date,last_calibration,protocol,rssi,id
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    values,
                )
        stats.sensor_upserts += 1
    return mapping

def update_sensor_processing_outputs(
    connection: sqlite3.Connection,
    *,
    sensor_ids: Mapping[str, str],
    manifest: Mapping[str, Any],
    canonical_features: Mapping[str, Any],
    report: Mapping[str, Any],
    site_payload: Mapping[str, Any],
    store_raw_blob: bool,
    stats: DatabaseWriteStats,
) -> None:
    """Persist the latest run-level outputs on the enriched sensor records.

    MCSA features and diagnosis are three-current-channel results, so they are
    stored on CT_A/CT_B/CT_C sensor records. The compact site payload is stored
    on every sensor participating in the capture. Raw blobs are optional because
    retaining large binary payloads inside SQLite can rapidly increase database
    size; lineage/path/hash are always preserved by the normal pipeline.
    """
    columns = table_columns(connection, "sensors")
    required = {"extracted_features", "diagnosis_report", "site_payload"}
    if not required.issubset(columns):
        stats.warnings.append(
            "Sensor processing JSON was not written because the database uses the legacy sensors schema."
        )
        return

    features_json = json.dumps(json_safe(canonical_features), ensure_ascii=False)
    report_json = json.dumps(json_safe(report), ensure_ascii=False)
    site_json = json.dumps(json_safe(site_payload), ensure_ascii=False)
    channels = manifest.get("channels") or {}

    for channel, sensor_id in sensor_ids.items():
        is_current = str(channel) in {"CT_A", "CT_B", "CT_C"}
        raw_blob = None
        if store_raw_blob and "raw_data" in columns:
            source = (channels.get(str(channel)) or {}).get("file_path")
            if source and Path(str(source)).exists():
                raw_blob = Path(str(source)).read_bytes()
                stats.raw_blobs_stored += 1
        connection.execute(
            """
            UPDATE sensors
               SET extracted_features=?, diagnosis_report=?, site_payload=?,
                   raw_data=CASE WHEN ? IS NULL THEN raw_data ELSE ? END,
                   processing_status='completed', processing_error=NULL,
                   last_processed_at=?
             WHERE id=?
            """,
            (
                features_json if is_current else None,
                report_json if is_current else None,
                site_json,
                raw_blob,
                raw_blob,
                sqlite_datetime(utc_now()),
                sensor_id,
            ),
        )
        stats.sensor_outputs_updated += 1


def insert_telemetry(
    connection: sqlite3.Connection,
    *,
    telemetry: Mapping[str, Any],
    sensor_ids: Mapping[str, str],
    manifest: Mapping[str, Any],
    segment_start: datetime,
    run_id: str,
    stats: DatabaseWriteStats,
) -> list[dict[str, Any]]:
    payload_rows: list[dict[str, Any]] = []
    signals = telemetry.get("signals") or {}
    columns = table_columns(connection, "sensor_telemetry")
    rich_schema = {
        "capture_id", "source_file_name", "point_index", "offset_seconds",
        "source_sample_rate_hz", "target_sample_rate_hz", "raw_samples_per_point",
        "downsample_method",
    }.issubset(columns)
    rich_rows: list[tuple[Any, ...]] = []
    legacy_rows: list[tuple[Any, ...]] = []

    for channel, signal in signals.items():
        if not isinstance(signal, Mapping) or signal.get("error"):
            continue
        sensor_id = sensor_ids.get(str(channel))
        if not sensor_id:
            continue
        offsets = list(signal.get("time") or [])
        values = list(signal.get("values") or [])
        unit = str(signal.get("units") or "unknown")
        source_rate = float(signal.get("sample_rate_hz") or manifest.get("fs") or 0)
        target_rate = float(signal.get("target_rate_hz") or 2.5)
        raw_samples_per_point = max(1, int(round(source_rate / target_rate)))
        details = (manifest.get("channels") or {}).get(str(channel)) or {}
        source_path = details.get("file_path")
        source_name = Path(str(source_path)).name if source_path else str((((manifest.get("segment") or {}).get("files") or {}).get(str(channel))) or str(channel))
        for index, (offset_raw, value_raw) in enumerate(zip(offsets, values)):
            offset = finite_float(offset_raw)
            value = finite_float(value_raw)
            if offset is None or value is None:
                continue
            timestamp = segment_start + timedelta(seconds=offset)
            timestamp_text = sqlite_datetime(timestamp)
            row_id = stable_id("tel", sensor_id, run_id, index, length=28)
            if rich_schema:
                rich_rows.append((
                    row_id, sensor_id, run_id, source_name, index, timestamp_text,
                    offset, value, unit, source_rate, target_rate,
                    raw_samples_per_point, "average",
                ))
            else:
                legacy_rows.append((row_id, sensor_id, timestamp_text, value, unit))
            payload_rows.append(
                {
                    "id": row_id,
                    "sensor_id": sensor_id,
                    "channel": channel,
                    "capture_id": run_id,
                    "point_index": index,
                    "timestamp": utc_iso(timestamp),
                    "offset_seconds": offset,
                    "value": value,
                    "unit": unit,
                }
            )

    before = connection.total_changes
    if rich_schema:
        connection.executemany(
            """
            INSERT OR IGNORE INTO sensor_telemetry(
                id,sensor_id,capture_id,source_file_name,point_index,timestamp,
                offset_seconds,value,unit,source_sample_rate_hz,target_sample_rate_hz,
                raw_samples_per_point,downsample_method
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            rich_rows,
        )
        total = len(rich_rows)
    else:
        connection.executemany(
            "INSERT OR IGNORE INTO sensor_telemetry(id,sensor_id,timestamp,value,unit) VALUES(?,?,?,?,?)",
            legacy_rows,
        )
        total = len(legacy_rows)
    inserted = connection.total_changes - before
    stats.telemetry_inserted += inserted
    stats.telemetry_ignored += max(0, total - inserted)
    return payload_rows

def upsert_health_history(
    connection: sqlite3.Connection,
    *,
    asset_id: str,
    health: float | None,
    generated_at: datetime,
    stats: DatabaseWriteStats,
) -> None:
    if health is None:
        stats.warnings.append("Asset health history was not written because health is unavailable.")
        return
    day = generated_at.date().isoformat()
    row = connection.execute(
        "SELECT id FROM asset_health_history WHERE asset_id=? AND date=? ORDER BY id LIMIT 1",
        (asset_id, day),
    ).fetchone()
    if row:
        connection.execute(
            "UPDATE asset_health_history SET health=? WHERE id=?",
            (clamp(float(health), 0.0, 100.0), row[0]),
        )
        stats.health_history_updated += 1
    else:
        connection.execute(
            "INSERT INTO asset_health_history(id,asset_id,date,health) VALUES(?,?,?,?)",
            (stable_id("hh", asset_id, day), asset_id, day, clamp(float(health), 0.0, 100.0)),
        )
        stats.health_history_inserted += 1


def upsert_alerts(
    connection: sqlite3.Connection,
    *,
    site_payload: Mapping[str, Any],
    asset_id: str,
    stats: DatabaseWriteStats,
) -> list[dict[str, Any]]:
    alerts = ((site_payload.get("alerts") or {}).get("alert_stream") or [])
    persisted: list[dict[str, Any]] = []
    active_codes: set[str] = set()

    for item in alerts:
        if not isinstance(item, Mapping):
            continue
        code = str(item.get("alert_code") or item.get("fault_code") or "MCSA-UNKNOWN")
        active_codes.add(code)
        severity = str(item.get("severity") or "HIGH").lower()
        message = str(item.get("message") or item.get("title") or code)
        generated = str(item.get("created_at") or utc_iso())
        try:
            generated_dt = datetime.fromisoformat(generated.replace("Z", "+00:00"))
        except ValueError:
            generated_dt = utc_now()
        generated_db = sqlite_datetime(generated_dt.replace(tzinfo=generated_dt.tzinfo or timezone.utc))

        existing = connection.execute(
            """
            SELECT id FROM alerts
             WHERE asset_id=? AND code=? AND resolved=0
             ORDER BY timestamp DESC LIMIT 1
            """,
            (asset_id, code),
        ).fetchone()
        if existing:
            alert_id = str(existing[0])
            connection.execute(
                """
                UPDATE alerts
                   SET severity=?, message=?, timestamp=?
                 WHERE id=?
                """,
                (severity, message, generated_db, alert_id),
            )
            stats.alerts_updated += 1
        else:
            alert_id = stable_id("alt", asset_id, code, generated_db, length=24)
            connection.execute(
                """
                INSERT INTO alerts(
                    id,severity,asset_id,code,message,timestamp,
                    acknowledged,acknowledged_by,acknowledged_at,
                    resolved,resolved_at,resolution,root_cause
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    alert_id,
                    severity,
                    asset_id,
                    code,
                    message,
                    generated_db,
                    0,
                    None,
                    None,
                    0,
                    None,
                    None,
                    None,
                ),
            )
            stats.alerts_inserted += 1
        persisted.append({"id": alert_id, "asset_id": asset_id, "code": code, "severity": severity})

    # Auto-resolve only prior MCSA alerts for this asset whose class is now inactive.
    old_rows = connection.execute(
        "SELECT id, code FROM alerts WHERE asset_id=? AND resolved=0 AND code LIKE 'MCSA-%'",
        (asset_id,),
    ).fetchall()
    resolved_at = sqlite_datetime(utc_now())
    for old_id, old_code in old_rows:
        if str(old_code) not in active_codes:
            connection.execute(
                """
                UPDATE alerts
                   SET resolved=1, resolved_at=?, resolution=?
                 WHERE id=?
                """,
                (resolved_at, "Automatically cleared by a later healthy MCSA scoring window.", old_id),
            )
    return persisted


def upsert_failure_modes(
    connection: sqlite3.Connection,
    *,
    report: Mapping[str, Any],
    plant_id: str,
    stats: DatabaseWriteStats,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for item in report.get("fault_scores", []):
        if not isinstance(item, Mapping):
            continue
        code = str(item.get("fault_code") or "UNKNOWN")
        name = str(item.get("fault_name") or code)
        evidence = finite_float(item.get("evidence_pct"), 0.0) or 0.0
        row_id = stable_id("fm", plant_id, code, length=22)
        if connection.execute("SELECT 1 FROM failure_modes WHERE id=?", (row_id,)).fetchone():
            connection.execute(
                "UPDATE failure_modes SET plant_id=?, name=?, value=? WHERE id=?",
                (plant_id, name, evidence, row_id),
            )
        else:
            connection.execute(
                "INSERT INTO failure_modes(id,plant_id,name,value) VALUES(?,?,?,?)",
                (row_id, plant_id, name, evidence),
            )
        stats.failure_modes_upserted += 1
        rows.append({"id": row_id, "plant_id": plant_id, "code": code, "name": name, "value": evidence})
    return rows


def update_aggregate_health(
    connection: sqlite3.Connection,
    *,
    plant_id: str,
    zone_id: str,
    stats: DatabaseWriteStats,
) -> None:
    zone_row = connection.execute(
        "SELECT AVG(health) FROM assets WHERE zone_id=? AND status!='offline'", (zone_id,)
    ).fetchone()
    if zone_row and zone_row[0] is not None:
        connection.execute("UPDATE zones SET health=? WHERE id=?", (float(zone_row[0]), zone_id))
        stats.zone_health_updated = True

    plant_row = connection.execute(
        "SELECT AVG(health) FROM assets WHERE plant_id=? AND status!='offline'", (plant_id,)
    ).fetchone()
    if plant_row and plant_row[0] is not None:
        connection.execute(
            "UPDATE plants SET health_score=? WHERE id=?", (float(plant_row[0]), plant_id)
        )
        stats.plant_health_updated = True


def persist_database(
    *,
    database_path: Path,
    backup_path: Path | None,
    metadata: Mapping[str, Any],
    manifest: Mapping[str, Any],
    telemetry: Mapping[str, Any],
    report: Mapping[str, Any],
    site_payload: Mapping[str, Any],
    energy_report: Mapping[str, Any],
    canonical_features: Mapping[str, Any],
    store_raw_blob: bool,
    run_id: str,
    plant_id_override: str | None,
    zone_id_override: str | None,
    timezone_name: str,
    vibration_report: Mapping[str, Any] | None = None,
    data_quality: Mapping[str, Any] | None = None,
    operating_regime: str = "unknown-regime",
    rul_config: Mapping[str, Any] | None = None,
    rul_baseline: Mapping[str, Any] | None = None,
    execution_mode: str = "production",
    diagnostic_validity: str = "PRODUCTION_CONTRACT",
    source_metadata_path: str = "",
    source_bundle_dir: str = "",
    run_output_dir: str = "",
    segment_index: int = 0,
) -> tuple[DatabaseWriteStats, AssetContext, dict[str, str], dict[str, Any], dict[str, Any]]:
    if not database_path.exists():
        raise FileNotFoundError(f"Database file does not exist: {database_path}")
    if backup_path:
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(database_path, backup_path)
        LOGGER.info("Database backup created: %s", backup_path)

    stats = DatabaseWriteStats()
    vibration_report = dict(vibration_report or {
        "schema_version": "1.0",
        "summary": {"status": "NOT_PROVIDED", "vibration_channel_count": 0},
        "fault_scores": [],
        "channels": [],
    })
    data_quality = dict(data_quality or {})
    connection = sqlite3.connect(database_path, timeout=60.0)
    connection.row_factory = sqlite3.Row
    try:
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=60000")
        ensure_full_diagnostic_schema(connection)
        validate_database_schema(connection)
        connection.execute("BEGIN IMMEDIATE")

        asset = manifest.get("asset") or report.get("asset") or {}
        context = resolve_asset_context(
            connection,
            asset=asset,
            metadata=metadata,
            plant_id_override=plant_id_override,
            zone_id_override=zone_id_override,
        )
        quality_score = calculate_data_quality_score(data_quality)
        health_assessment = derive_health_scores(
            current_report=report,
            vibration_report=vibration_report,
            data_quality_score=quality_score,
            diagnostic_validity=diagnostic_validity,
        )
        health = float(health_assessment["overall_health_score"])
        status = str(health_assessment["status"])
        upsert_plant_zone_asset(
            connection,
            context,
            health=health,
            status=status,
            timezone_name=timezone_name,
            stats=stats,
        )
        segment_start = resolve_segment_start(manifest.get("segment") or {}, utc_now())
        sensor_ids = upsert_sensors(
            connection,
            context=context,
            metadata=metadata,
            telemetry=telemetry,
            manifest=manifest,
            run_id=run_id,
            segment_start=segment_start,
            stats=stats,
        )
        update_sensor_processing_outputs(
            connection,
            sensor_ids=sensor_ids,
            manifest=manifest,
            canonical_features=canonical_features,
            report=report,
            site_payload=site_payload,
            store_raw_blob=store_raw_blob,
            stats=stats,
        )
        telemetry_rows = insert_telemetry(
            connection,
            telemetry=telemetry,
            sensor_ids=sensor_ids,
            manifest=manifest,
            segment_start=segment_start,
            run_id=run_id,
            stats=stats,
        )

        current_channel = ((manifest.get("channels") or {}).get("CT_A") or {})
        current_stats = current_channel.get("scaled_stats") or current_channel.get("raw_stats") or {}
        mcsa_write = persist_mcsa_report(
            connection,
            asset_id=context.asset_id,
            capture_id=run_id,
            timestamp=segment_start,
            sample_rate_hz=float(manifest.get("fs") or 0.0),
            duration_seconds=finite_float(current_stats.get("duration_s") or current_stats.get("duration_seconds")),
            canonical_features=canonical_features,
            report=report,
            diagnostic_validity=diagnostic_validity,
            data_quality_score=quality_score,
        )
        stats.mcsa_analyses_upserted += int(mcsa_write.get("analysis_upserted") or 0)
        stats.mcsa_features_upserted += int(mcsa_write.get("features_upserted") or 0)
        stats.mcsa_fault_evidence_upserted += int(mcsa_write.get("fault_evidence_upserted") or 0)
        persist_stage_result(
            connection,
            capture_id=run_id,
            asset_id=context.asset_id,
            stage_name="mcsa",
            status="COMPLETED",
            row_count=int(mcsa_write.get("features_upserted") or 0),
            message="MCSA analysis and normalized feature/fault evidence persistence completed.",
            details=mcsa_write,
        )
        stats.pipeline_stage_results_upserted += 1

        generated_text = str(report.get("generated_at") or utc_iso())
        try:
            generated_at = datetime.fromisoformat(generated_text.replace("Z", "+00:00"))
        except ValueError:
            generated_at = utc_now()
        generated_at = generated_at.replace(tzinfo=generated_at.tzinfo or timezone.utc)
        upsert_health_history(
            connection,
            asset_id=context.asset_id,
            health=health,
            generated_at=generated_at,
            stats=stats,
        )
        persisted_alerts = upsert_alerts(
            connection,
            site_payload=site_payload,
            asset_id=context.asset_id,
            stats=stats,
        )
        failure_modes = upsert_failure_modes(
            connection,
            report=report,
            plant_id=context.plant_id,
            stats=stats,
        )
        energy_write = persist_energy_report(
            connection,
            energy_report=energy_report,
            plant_id=context.plant_id,
            asset_id=context.asset_id,
            capture_id=run_id,
        )
        stats.energy_records_inserted += int(energy_write.get("inserted") or 0)
        stats.energy_records_ignored += int(energy_write.get("ignored") or 0)
        stats.energy_schema_migrated = bool(energy_write.get("schema_migrated"))
        energy_available = bool(energy_report.get("available"))
        persist_stage_result(
            connection,
            capture_id=run_id,
            asset_id=context.asset_id,
            stage_name="energy",
            status="COMPLETED" if energy_available else "SKIPPED",
            row_count=int(energy_write.get("inserted") or 0),
            message="Energy calculation persisted." if energy_available else str(energy_report.get("reason") or "Energy input requirements were not supplied."),
            details={"write": energy_write, "summary": energy_report.get("summary") or {}},
        )
        stats.pipeline_stage_results_upserted += 1

        vibration_write = persist_vibration_report(
            connection,
            report=vibration_report,
            asset_id=context.asset_id,
            capture_id=run_id,
            sensor_ids=sensor_ids,
            timestamp=segment_start,
            plant_id=context.plant_id,
        )
        stats.vibration_analyses_upserted += int(vibration_write.get("analyses_upserted") or 0)
        stats.vibration_features_upserted += int(vibration_write.get("features_upserted") or 0)
        stats.vibration_fault_evidence_upserted += int(vibration_write.get("fault_evidence_upserted") or 0)
        stats.vibration_method_executions_upserted += int(vibration_write.get("method_executions_upserted") or 0)
        stats.vibration_model_results_upserted += int(vibration_write.get("model_results_upserted") or 0)
        stats.alerts_updated += int(vibration_write.get("alerts_upserted") or 0)
        stats.failure_modes_upserted += int(vibration_write.get("failure_modes_upserted") or 0)
        vibration_summary = vibration_report.get("summary") or {}
        vibration_stage_status = "SKIPPED" if str(vibration_summary.get("status") or "").upper() in {"DISABLED", "NOT_PROVIDED", "NO_VIBRATION_CHANNELS"} else "COMPLETED"
        persist_stage_result(
            connection,
            capture_id=run_id,
            asset_id=context.asset_id,
            stage_name="vibration",
            status=vibration_stage_status,
            row_count=int(vibration_write.get("features_upserted") or 0),
            message="Vibration diagnostics persistence completed." if vibration_stage_status == "COMPLETED" else "Vibration stage was skipped or no valid vibration channels were available.",
            details=vibration_write,
        )
        stats.pipeline_stage_results_upserted += 1

        if rul_config is not None:
            rul_report, rul_write = persist_rule_based_rul(
                connection,
                asset_id=context.asset_id,
                capture_id=run_id,
                timestamp=segment_start,
                operating_regime=operating_regime,
                metadata=metadata,
                canonical_features=canonical_features,
                current_report=report,
                vibration_report=vibration_report,
                energy_report=energy_report,
                data_quality=data_quality,
                config=rul_config,
                baseline=rul_baseline,
            )
            stats.rul_history_upserted += int(rul_write.get("history_upserted") or 0)
            stats.rul_state_upserted += int(rul_write.get("state_upserted") or 0)
            stats.rul_estimates_upserted += int(rul_write.get("estimates_upserted") or 0)
            stats.rul_predictions_upserted += int(rul_write.get("predictions_upserted") or 0)
            stats.asset_rul_updated += int(rul_write.get("asset_rul_updated") or 0)
            persist_stage_result(
                connection,
                capture_id=run_id,
                asset_id=context.asset_id,
                stage_name="rul",
                status="COMPLETED",
                row_count=int(rul_write.get("estimates_upserted") or 0),
                message="Rule-based RUL observations and availability decisions persisted.",
                details=rul_write,
            )
            stats.pipeline_stage_results_upserted += 1
        else:
            rul_report = {
                "schema_version": "1.0",
                "algorithm": "Adaptive Multi-Indicator Threshold-Crossing RUL",
                "algorithm_version": "1.0.0",
                "generated_at": utc_iso(segment_start),
                "asset_id": context.asset_id,
                "capture_id": run_id,
                "summary": {
                    "asset_rul_available": False,
                    "component_count": 0,
                    "available_component_count": 0,
                    "semantics": "RUL processing disabled for this run."
                },
                "components": [],
                "reason": "RUL processing disabled with --skip-rul.",
            }
            persist_stage_result(
                connection,
                capture_id=run_id,
                asset_id=context.asset_id,
                stage_name="rul",
                status="SKIPPED",
                row_count=0,
                message="RUL processing disabled for this run.",
                details={"reason": "--skip-rul"},
            )
            stats.pipeline_stage_results_upserted += 1

        health_write = persist_health_assessment(
            connection,
            asset_id=context.asset_id,
            plant_id=context.plant_id,
            zone_id=context.zone_id,
            capture_id=run_id,
            timestamp=segment_start,
            assessment=health_assessment,
        )
        stats.health_assessments_upserted += int(health_write.get("assessment_upserted") or 0)
        persist_stage_result(
            connection,
            capture_id=run_id,
            asset_id=context.asset_id,
            stage_name="health",
            status="COMPLETED",
            row_count=1,
            message="Explicit current, vibration, and overall health scores persisted.",
            details=health_assessment,
        )
        stats.pipeline_stage_results_upserted += 1

        update_aggregate_health(
            connection,
            plant_id=context.plant_id,
            zone_id=context.zone_id,
            stats=stats,
        )

        # MCSA fault evidence remains diagnostic evidence. Only validated rule-based
        # component RUL estimates are written to the legacy predictions table.
        active_predictions = int((report.get("summary") or {}).get("active_predictions") or 0)
        stats.predictions_skipped = active_predictions
        if active_predictions:
            stats.warnings.append(
                "MCSA fault evidence was retained in JSON/diagnostic tables and was not copied directly "
                "into predictions. Only independent rule-based RUL estimates can populate that table."
            )

        recommendations = ((site_payload.get("maintenance") or {}).get("recommended_work_orders") or [])
        stats.work_orders_skipped = len(recommendations)
        if recommendations:
            stats.warnings.append(
                "Maintenance recommendations were exported to JSON but not auto-created as work orders."
            )

        if table_exists(connection, "processing_runs"):
            processing_id = stable_id("proc", run_id, length=24)
            connection.execute(
                """
                INSERT INTO processing_runs(
                  id,capture_key,asset_id,metadata_path,bundle_dir,segment_index,
                  segment_start,run_id,status,attempts,started_at,finished_at,
                  output_dir,error,summary_json
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(capture_key) DO UPDATE SET
                  asset_id=excluded.asset_id,metadata_path=excluded.metadata_path,
                  bundle_dir=excluded.bundle_dir,segment_index=excluded.segment_index,
                  segment_start=excluded.segment_start,run_id=excluded.run_id,
                  status=excluded.status,attempts=excluded.attempts,
                  started_at=excluded.started_at,finished_at=excluded.finished_at,
                  output_dir=excluded.output_dir,error=excluded.error,
                  summary_json=excluded.summary_json
                """,
                (
                    processing_id, run_id, context.asset_id, source_metadata_path,
                    source_bundle_dir, int(segment_index), sqlite_datetime(segment_start),
                    run_id, "completed", 1, sqlite_datetime(segment_start),
                    sqlite_datetime(utc_now()), run_output_dir, None,
                    json.dumps(json_safe({"health_score": health, "status": status, "execution_mode": execution_mode}), ensure_ascii=False),
                ),
            )
            stats.processing_runs_upserted += 1

        persist_stage_result(
            connection,
            capture_id=run_id,
            asset_id=context.asset_id,
            stage_name="database_persistence",
            status="COMPLETED",
            row_count=(stats.mcsa_features_upserted + stats.vibration_features_upserted + stats.telemetry_inserted + stats.rul_estimates_upserted),
            message="All diagnostic outputs committed in one SQLite transaction.",
            details={"execution_mode": execution_mode, "diagnostic_validity": diagnostic_validity},
        )
        stats.pipeline_stage_results_upserted += 1

        database_counts = capture_database_counts(connection, run_id, context.asset_id)
        connection.commit()
        payload = {
            "plant": {"id": context.plant_id, "name": context.plant_name},
            "zone": {"id": context.zone_id, "name": context.zone_name},
            "asset": {
                "id": context.asset_id,
                "name": context.asset_name,
                "type": context.asset_type,
                "health": health,
                "health_score": health,
                "health_assessment": health_assessment,
                "status": status,
                "rul": (rul_report.get("summary") or {}).get("asset_rul_median_hours"),
            },
            "sensors": [
                {"channel": channel, "sensor_id": sensor_id}
                for channel, sensor_id in sorted(sensor_ids.items())
            ],
            "telemetry": telemetry_rows,
            "alerts": persisted_alerts,
            "failure_modes": failure_modes,
            "mcsa": mcsa_write,
            "health_assessment": health_assessment,
            "energy": {
                "database_write": energy_write,
                "summary": energy_report.get("summary") or {},
                "method": energy_report.get("method"),
            },
            "vibration": {
                "database_write": vibration_write,
                "summary": vibration_report.get("summary") or {},
                "fault_scores": vibration_report.get("fault_scores") or [],
            },
            "rul": {
                "summary": rul_report.get("summary") or {},
                "components": rul_report.get("components") or [],
                "database_writes": rul_report.get("write_stats") or {},
            },
            "predictions": {
                "database_rows_created": stats.rul_predictions_upserted,
                "ui_fault_evidence_available": active_predictions,
                "semantics": "Only validated deterministic RUL estimates populate predictions; diagnostic evidence remains separate.",
            },
            "maintenance_recommendations": recommendations,
            "database_counts": database_counts,
            "execution": {"mode": execution_mode, "diagnostic_validity": diagnostic_validity},
        }
        return stats, context, sensor_ids, payload, rul_report
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


# ---------------------------------------------------------------------------
# Main orchestration
# ---------------------------------------------------------------------------

def run_complete_pipeline(args: argparse.Namespace) -> dict[str, Any]:
    started_at = utc_now()
    run_id = args.run_id or f"run-{started_at.strftime('%Y%m%dT%H%M%SZ')}-{uuid.uuid4().hex[:8]}"
    module_dir = Path(args.module_dir).resolve()
    output_dir = Path(args.output_dir).resolve() / run_id
    prepared_dir = output_dir / "prepared"
    output_dir.mkdir(parents=True, exist_ok=True)
    configure_logging(output_dir / "pipeline.log", args.verbose)

    LOGGER.info("Starting complete condition-monitoring pipeline: %s", run_id)
    LOGGER.info("Output directory: %s", output_dir)

    metadata_path = Path(args.metadata).resolve()
    bundle_dir = Path(args.bundle_dir).resolve()
    database_path = Path(args.database).resolve()
    nominal_profile_path = Path(args.nominal_profile).resolve()
    if not metadata_path.exists():
        raise FileNotFoundError(metadata_path)
    if not bundle_dir.exists():
        raise FileNotFoundError(bundle_dir)
    if not nominal_profile_path.exists():
        raise FileNotFoundError(nominal_profile_path)

    paths = {
        "prepared_dir": str(prepared_dir),
        "canonical_features_csv": str(output_dir / "mmd_fullstack.csv"),
        "feature_audit": str(output_dir / "feature_contract_audit.json"),
        "fault_report": str(output_dir / "fault_score_report.json"),
        "site_payload": str(output_dir / "predictive_operations_payload.json"),
        "telemetry_preview": str(output_dir / "telemetry_preview.json"),
        "energy_report": str(output_dir / "energy_report.json"),
        "vibration_report": str(output_dir / "vibration_diagnostic_report.json"),
        "vibration_features_csv": str(output_dir / "vibration_features.csv"),
        "rul_report": str(output_dir / "rule_based_rul_report.json"),
        "raw_sensor_manifest": str(output_dir / "raw_sensor_manifest.json"),
        "database_payload": str(output_dir / "database_payload.json"),
        "database_write_report": str(output_dir / "database_write_report.json"),
        "ui_payload": str(output_dir / "ui_payload.json"),
        "run_summary": str(output_dir / "run_summary.json"),
        "pipeline_log": str(output_dir / "pipeline.log"),
    }

    run_bin_pipeline = import_pipeline(module_dir)
    extractor_path = Path(args.extractor)
    if not extractor_path.is_absolute():
        extractor_path = module_dir / extractor_path
    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = module_dir / config_path

    LOGGER.info("Stage 1/8: binary ingestion, extraction, adaptation, and scoring")
    core_summary = run_bin_pipeline(
        metadata_path=metadata_path,
        bundle_dir=bundle_dir,
        raw_dir=Path(args.raw_dir).resolve() if args.raw_dir else None,
        prepared_dir=prepared_dir,
        segment_index=args.segment_index,
        dtype=args.dtype,
        endian=args.endian,
        scale_mode=args.scale_mode,
        extractor_path=extractor_path,
        canonical_csv=Path(paths["canonical_features_csv"]),
        audit_output=Path(paths["feature_audit"]),
        config_path=config_path,
        nominal_profile_path=nominal_profile_path,
        report_output=Path(paths["fault_report"]),
        site_output=Path(paths["site_payload"]),
        telemetry_output=Path(paths["telemetry_preview"]),
        operating_regime=args.operating_regime,
        asset_id=args.asset_id,
        asset_name=args.asset_name,
    )

    manifest = read_json(prepared_dir / "ingestion_manifest.json")
    validate_current_channel_alignment(manifest)
    report = read_json(Path(paths["fault_report"]))
    site_payload = read_json(Path(paths["site_payload"]))
    telemetry = read_json(Path(paths["telemetry_preview"]))
    metadata = load_original_metadata(metadata_path)
    canonical_features = read_single_feature_row(Path(paths["canonical_features_csv"]))

    LOGGER.info("Stage 2/8: raw lineage and data-quality outputs")
    raw_manifest = create_raw_sensor_manifest(manifest, metadata, run_id)
    atomic_write_json(Path(paths["raw_sensor_manifest"]), raw_manifest)
    data_quality = build_data_quality(manifest, report)

    LOGGER.info("Stage 3/8: three-phase electrical power and energy")
    if args.skip_energy:
        energy_report = {
            "schema_version": "1.0",
            "available": False,
            "reason": "Energy calculation was disabled with --skip-energy.",
            "series": [],
            "summary": {},
        }
    else:
        energy_config = resolve_energy_config(
            metadata,
            rated_voltage_override=args.rated_voltage_v,
            voltage_basis_override=args.voltage_basis,
            power_factor_override=args.power_factor,
            window_seconds_override=args.energy_window_seconds,
        )
        segment_start_for_energy = resolve_segment_start(manifest.get("segment") or {}, started_at)
        energy_report = calculate_energy_from_prepared_currents(
            prepared_dir=prepared_dir,
            sample_rate_hz=float(manifest["fs"]),
            segment_start=segment_start_for_energy,
            config=energy_config,
            asset_id=str((manifest.get("asset") or {}).get("asset_id") or args.asset_id or "UNKNOWN_ASSET"),
            run_id=run_id,
        )
    atomic_write_json(Path(paths["energy_report"]), energy_report)

    LOGGER.info("Stage 4/8: specialized vibration diagnostics")
    if args.skip_vibration:
        vibration_report = {
            "schema_version": "1.0",
            "engine": "Vira vibration diagnostic core",
            "engine_version": "2.0.0",
            "generated_at": utc_iso(),
            "asset": manifest.get("asset") or {},
            "summary": {
                "status": "DISABLED",
                "health_index": None,
                "vibration_channel_count": 0,
                "active_fault_count": 0,
            },
            "fault_scores": [],
            "channels": [],
            "reason": "Vibration diagnostics were disabled with --skip-vibration.",
        }
        atomic_write_json(Path(paths["vibration_report"]), vibration_report)
        Path(paths["vibration_features_csv"]).write_text("channel\n", encoding="utf-8")
    else:
        vibration_config_path = Path(args.vibration_config)
        if not vibration_config_path.is_absolute():
            vibration_config_path = module_dir / vibration_config_path
        vibration_baseline_path = Path(args.vibration_baseline).resolve() if args.vibration_baseline else None
        vibration_report = run_vibration_diagnostics(
            manifest_path=prepared_dir / "ingestion_manifest.json",
            metadata_path=metadata_path,
            prepared_dir=prepared_dir,
            config_path=vibration_config_path,
            output_report=Path(paths["vibration_report"]),
            output_features_csv=Path(paths["vibration_features_csv"]),
            baseline_path=vibration_baseline_path,
        )

    LOGGER.info("Stage 5/8: deterministic rule-based RUL configuration")
    if args.skip_rul:
        rul_config = None
        rul_baseline = None
    else:
        rul_config_path = Path(args.rul_config)
        if not rul_config_path.is_absolute():
            rul_config_path = module_dir / rul_config_path
        if not rul_config_path.exists():
            raise FileNotFoundError(rul_config_path)
        rul_config = load_rul_config(rul_config_path)
        rul_baseline = read_json(Path(args.rul_baseline).resolve()) if args.rul_baseline else None

    backup_path = None
    if not args.no_database_backup:
        backup_path = output_dir / f"{database_path.name}.before-{run_id}.bak"

    LOGGER.info("Stage 6/8: transactional database persistence")
    stats, context, sensor_ids, database_payload, rul_report = persist_database(
        database_path=database_path,
        backup_path=backup_path,
        metadata=metadata,
        manifest=manifest,
        telemetry=telemetry,
        report=report,
        site_payload=site_payload,
        energy_report=energy_report,
        vibration_report=vibration_report,
        canonical_features=canonical_features,
        store_raw_blob=args.store_raw_blob,
        run_id=run_id,
        plant_id_override=args.plant_id,
        zone_id_override=args.zone_id,
        timezone_name=args.timezone,
        data_quality=data_quality,
        operating_regime=args.operating_regime,
        rul_config=rul_config,
        rul_baseline=rul_baseline,
        execution_mode=args.execution_mode,
        diagnostic_validity=args.diagnostic_validity,
        source_metadata_path=str(metadata_path),
        source_bundle_dir=str(bundle_dir),
        run_output_dir=str(output_dir),
        segment_index=args.segment_index,
    )
    atomic_write_json(Path(paths["database_payload"]), database_payload)
    atomic_write_json(Path(paths["rul_report"]), rul_report)

    # Add persisted sensor IDs to UI streams.
    LOGGER.info("Stage 7/8: final UI payload")
    ui_payload = build_ui_payload(
        site_payload=site_payload,
        report=report,
        telemetry=telemetry,
        manifest=manifest,
        data_quality=data_quality,
        energy_report=energy_report,
        vibration_report=vibration_report,
        rul_report=rul_report,
        run_id=run_id,
        output_paths=paths,
    )
    for stream in ui_payload.get("sensor_streams", []):
        if isinstance(stream, dict):
            stream["sensor_id"] = sensor_ids.get(str(stream.get("channel")))
    ui_payload["health_assessment"] = (database_payload.get("asset") or {}).get("health_assessment")
    ui_payload["mcsa_database"] = database_payload.get("mcsa") or {}
    ui_payload["asset_context"] = {
        "asset_id": context.asset_id,
        "asset_name": context.asset_name,
        "asset_type": context.asset_type,
        "plant_id": context.plant_id,
        "plant_name": context.plant_name,
        "zone_id": context.zone_id,
        "zone_name": context.zone_name,
    }
    atomic_write_json(Path(paths["ui_payload"]), ui_payload)

    database_report = {
        "schema_version": "1.0",
        "run_id": run_id,
        "database_path": str(database_path),
        "backup_path": str(backup_path) if backup_path else None,
        "committed": True,
        "writes": stats.__dict__,
        "unsupported_or_intentionally_skipped": {
            "raw_binary_blob": (
                "Stored only when --store-raw-blob is enabled. Source path, hash, format, capture ID, and statistics are always retained."
            ),
            "predictions_table": (
                "Written only for component estimates that pass the deterministic RUL validity gates. "
                "Legacy confidence stores estimate quality, not failure probability."
            ),
            "ai_models_and_model_performance": "Not produced by this deterministic scoring core.",
            "work_orders": "Recommendations are exported but not auto-committed as operational work orders.",
            "mtbf_mttr_oee": "Not calculated by the current diagnostic window.",
            "energy": (
                "Calculated and persisted as windowed three-phase RMS active-power estimates "
                "when rated voltage and power factor are supplied."
            ),
            "vibration_trained_models": (
                "SVM, DPMM and FSCNN inference is performed only when validated model artifacts "
                "are configured; no untrained classifier output is fabricated."
            ),
            "rule_based_rul": (
                "Damage history is always stored. RUL is published only with a validated failure threshold, "
                "sufficient same-regime history, stable positive trend, acceptable quality and bounded extrapolation."
            ),
        },
    }
    atomic_write_json(Path(paths["database_write_report"]), database_report)

    LOGGER.info("Stage 8/8: final run summary")
    finished_at = utc_now()
    health = finite_float((database_payload.get("asset") or {}).get("health_score"))
    overall_status = str((database_payload.get("asset") or {}).get("status") or derive_overall_status(report))
    final_summary = {
        "success": True,
        "schema_version": "1.0",
        "pipeline_version": SCRIPT_VERSION,
        "run_id": run_id,
        "started_at": utc_iso(started_at),
        "finished_at": utc_iso(finished_at),
        "duration_seconds": round((finished_at - started_at).total_seconds(), 3),
        "asset_id": context.asset_id,
        "asset_name": context.asset_name,
        "plant_id": context.plant_id,
        "zone_id": context.zone_id,
        "segment_index": args.segment_index,
        "health_score": health,
        "health_assessment": (database_payload.get("asset") or {}).get("health_assessment"),
        "status": overall_status,
        "active_predictions_in_ui": int((report.get("summary") or {}).get("active_predictions") or 0),
        "critical_predictions": int((report.get("summary") or {}).get("critical_predictions") or 0),
        "warning_predictions": int((report.get("summary") or {}).get("warning_predictions") or 0),
        "database_writes": stats.__dict__,
        "data_quality": data_quality,
        "energy": energy_report.get("summary") or {},
        "vibration": vibration_report.get("summary") or {},
        "vibration_fault_scores": vibration_report.get("fault_scores") or [],
        "rul": rul_report.get("summary") or {},
        "rul_components": rul_report.get("components") or [],
        "core_summary": core_summary,
        "outputs": paths,
    }
    atomic_write_json(Path(paths["run_summary"]), final_summary)
    LOGGER.info("Pipeline completed successfully: %s", run_id)
    return final_summary


def build_parser() -> argparse.ArgumentParser:
    script_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(
        description="Run the complete binary MCSA diagnostic path and persist database/UI-ready outputs."
    )
    parser.add_argument("--metadata", required=True, help="metadata.json path")
    parser.add_argument("--bundle-dir", required=True, help="directory containing metadata-relative .bin files")
    parser.add_argument("--raw-dir", default=None, help="optional alternate raw-binary directory")
    parser.add_argument("--database", default=str(script_dir / "vira.db"), help="SQLite database path")
    parser.add_argument("--nominal-profile", required=True, help="healthy nominal-profile JSON")
    parser.add_argument("--output-dir", default=str(script_dir / "outputs"), help="parent output directory")
    parser.add_argument("--module-dir", default=str(script_dir), help="directory containing supplied MCSA modules")
    parser.add_argument("--extractor", default="mcsa_enhanced_agah_algorithms.py")
    parser.add_argument("--config", default="fault_scoring_config.json")
    parser.add_argument("--segment-index", type=int, default=0)
    parser.add_argument("--dtype", choices=["auto", "float32", "float64"], default="auto")
    parser.add_argument("--endian", choices=["auto", "little", "big"], default="little")
    parser.add_argument("--scale-mode", choices=["metadata", "none", "raw"], default="metadata")
    parser.add_argument("--operating-regime", default="unknown-regime")
    parser.add_argument("--execution-mode", choices=["software-test", "production"], default="production")
    parser.add_argument("--diagnostic-validity", default="PRODUCTION_CONTRACT")
    parser.add_argument("--asset-id", default=None, help="optional asset ID override")
    parser.add_argument("--asset-name", default=None, help="optional asset name override")
    parser.add_argument("--plant-id", default=None, help="optional database plant ID override")
    parser.add_argument("--zone-id", default=None, help="optional database zone ID override")
    parser.add_argument("--timezone", default="UTC", help="timezone stored for newly created plant rows")
    parser.add_argument("--run-id", default=None, help="optional caller-supplied idempotency/run identifier")
    parser.add_argument("--rated-voltage-v", type=float, default=None, help="motor rated RMS voltage; metadata.electrical.rated_voltage_v is preferred")
    parser.add_argument("--voltage-basis", choices=["line_to_line_rms", "phase_to_neutral_rms"], default=None, help="basis of the supplied rated voltage")
    parser.add_argument("--power-factor", type=float, default=None, help="measured or nameplate power factor in (0,1]")
    parser.add_argument("--energy-window-seconds", type=float, default=None, help="non-overlapping RMS power window; default 1 second")
    parser.add_argument("--skip-energy", action="store_true", help="explicitly disable energy calculation")
    parser.add_argument("--vibration-config", default="vibration_config.json", help="specialized vibration diagnostic configuration; relative paths resolve against --module-dir")
    parser.add_argument("--vibration-baseline", default=None, help="optional validated healthy vibration baseline JSON")
    parser.add_argument("--skip-vibration", action="store_true", help="explicitly disable vibration diagnostics")
    parser.add_argument("--rul-config", default="rul_config.json", help="deterministic RUL component/threshold configuration; relative paths resolve against --module-dir")
    parser.add_argument("--rul-baseline", default=None, help="optional healthy RUL indicator baseline JSON for robust-z indicators")
    parser.add_argument("--skip-rul", action="store_true", help="disable deterministic RUL observation and estimation for this run")
    parser.add_argument("--store-raw-blob", action="store_true", help="also store each source .bin payload in sensors.raw_data; disabled by default to control SQLite growth")
    parser.add_argument("--no-database-backup", action="store_true", help="disable automatic pre-write DB backup")
    parser.add_argument("--verbose", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    # Create an emergency output location before full orchestration begins.
    emergency_root = Path(args.output_dir).resolve()
    emergency_root.mkdir(parents=True, exist_ok=True)
    try:
        result = run_complete_pipeline(args)
        print(json.dumps(json_safe(result), ensure_ascii=False, indent=2, allow_nan=False))
        return 0
    except Exception as exc:
        failed_at = utc_now()
        run_id = args.run_id or f"failed-{failed_at.strftime('%Y%m%dT%H%M%SZ')}"
        failure_dir = emergency_root / run_id
        failure_dir.mkdir(parents=True, exist_ok=True)
        failure = {
            "success": False,
            "pipeline_version": SCRIPT_VERSION,
            "run_id": run_id,
            "failed_at": utc_iso(failed_at),
            "error_type": type(exc).__name__,
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }
        atomic_write_json(failure_dir / "run_error.json", failure)
        print(json.dumps(failure, ensure_ascii=False, indent=2), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
