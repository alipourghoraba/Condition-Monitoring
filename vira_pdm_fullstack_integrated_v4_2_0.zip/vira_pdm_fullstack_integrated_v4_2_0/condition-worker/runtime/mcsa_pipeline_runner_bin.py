#!/usr/bin/env python3
"""End-to-end MCSA runner for production .bin + metadata payloads.

This is the recommended entry point when backend input is metadata.json plus
binary sensor streams rather than CT_A.txt/CT_B.txt/CT_C.txt.

Flow:
  metadata + .bin files
      -> mcsa_bin_ingestion.py writes CT_A/B/C.txt to prepared_dir
      -> original extractor is executed unchanged except in-memory data_dir/fs_raw patch
      -> mcsa_feature_adapter completes the feature contract
      -> fault_scoring_layer optionally scores against a nominal profile
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Mapping, Sequence

from fault_scoring_layer import FaultScoringEngine, read_json, write_json
from mcsa_feature_adapter import (
    canonical_feature_order,
    enrich_runtime_features,
    runtime_adapter_audit,
    write_feature_csv,
)
from mcsa_bin_ingestion import prepare_segment_for_extractor


def _patch_extractor_assignments(source: str, *, data_dir: Path, fs_raw: float | None) -> str:
    """Patch only the legacy extractor assignments, safely on Windows.

    ``re.sub`` treats backslashes in a replacement *string* specially.  Passing
    a Windows path such as ``D:\\...\\vira...\\recorded...`` directly as the
    replacement can therefore turn ``\\v`` and ``\\r`` into control characters.
    A callable replacement returns the text verbatim and preserves the Python
    string literal produced by ``repr``.
    """
    data_pattern = re.compile(r'^data_dir\s*=\s*r?["\'][^"\']*["\']\s*$', re.MULTILINE)
    data_replacement = f"data_dir = {str(data_dir)!r}"
    patched, data_count = data_pattern.subn(lambda _match: data_replacement, source, count=1)
    if data_count != 1:
        raise RuntimeError("Could not find the extractor's single data_dir assignment")

    if fs_raw is not None:
        fs_pattern = re.compile(r'^fs_raw\s*=\s*[-+]?\d+(?:\.\d+)?\s*(?:#.*)?$', re.MULTILINE)
        fs_replacement = (
            f"fs_raw   = {float(fs_raw)!r}      "
            "# patched from metadata by mcsa_pipeline_runner_bin.py"
        )
        patched, fs_count = fs_pattern.subn(lambda _match: fs_replacement, patched, count=1)
        if fs_count != 1:
            raise RuntimeError("Could not find the extractor's single fs_raw assignment")
    return patched


def execute_original_extractor(
    extractor_path: str | Path,
    *,
    data_dir: str | Path,
    fs_raw: float | None = None,
) -> dict[str, Any]:
    extractor = Path(extractor_path).resolve()
    prepared_data_dir = Path(data_dir).resolve()
    if not extractor.exists():
        raise FileNotFoundError(extractor)
    if not prepared_data_dir.exists():
        raise FileNotFoundError(prepared_data_dir)

    source = extractor.read_text(encoding="utf-8")
    source = _patch_extractor_assignments(source, data_dir=prepared_data_dir, fs_raw=fs_raw)
    namespace: dict[str, Any] = {"__name__": "__main__", "__file__": str(extractor), "__package__": None}
    old_cwd = Path.cwd()
    old_path = list(sys.path)
    try:
        os.chdir(extractor.parent)
        sys.path.insert(0, str(extractor.parent))
        exec(compile(source, str(extractor), "exec"), namespace, namespace)
    finally:
        os.chdir(old_cwd)
        sys.path[:] = old_path
    return namespace


def run_bin_pipeline(
    *,
    metadata_path: str | Path,
    bundle_dir: str | Path,
    prepared_dir: str | Path,
    extractor_path: str | Path,
    canonical_csv: str | Path,
    audit_output: str | Path,
    config_path: str | Path,
    raw_dir: str | Path | None = None,
    segment_index: int = 0,
    dtype: str = "auto",
    endian: str = "little",
    scale_mode: str = "metadata",
    nominal_profile_path: str | Path | None = None,
    report_output: str | Path | None = None,
    site_output: str | Path | None = None,
    telemetry_output: str | Path | None = None,
    operating_regime: str | None = None,
    asset_id: str | None = None,
    asset_name: str | None = None,
) -> dict[str, Any]:
    manifest = prepare_segment_for_extractor(
        metadata_path=metadata_path,
        bundle_dir=bundle_dir,
        raw_dir=raw_dir,
        output_dir=prepared_dir,
        segment_index=segment_index,
        dtype=dtype,
        endian=endian,
        scale_mode=scale_mode,
        telemetry_output=telemetry_output,
    )
    fs_raw = float(manifest["fs"])
    asset = manifest.get("asset") or {}
    asset_id = asset_id or asset.get("asset_id") or "UNKNOWN_ASSET"
    asset_name = asset_name or asset.get("asset_name") or asset_id
    operating_regime = operating_regime or "unknown-regime"

    runtime = execute_original_extractor(extractor_path, data_dir=prepared_dir, fs_raw=fs_raw)
    original_features = runtime.get("features")
    if not isinstance(original_features, Mapping):
        raise RuntimeError("Extractor completed without a features dictionary")

    features = enrich_runtime_features(original_features, runtime)
    order = canonical_feature_order(features, runtime)
    write_feature_csv(features, canonical_csv, order=order)

    engine = FaultScoringEngine.from_config_file(config_path)
    audit = runtime_adapter_audit(original_features, features)
    audit["mapping_inventory"] = engine.mapping_inventory(features)
    audit["bin_ingestion"] = manifest
    audit["extractor_path"] = str(Path(extractor_path).resolve())
    audit["prepared_data_dir"] = str(Path(prepared_dir).resolve())
    audit["fs_raw_patched_from_metadata"] = fs_raw
    write_json(audit, audit_output)

    summary: dict[str, Any] = {
        "schema_version": "1.0",
        "status": "ok",
        "asset_id": asset_id,
        "asset_name": asset_name,
        "operating_regime": operating_regime,
        "fs_raw": fs_raw,
        "prepared_dir": str(Path(prepared_dir).resolve()),
        "canonical_csv": str(Path(canonical_csv).resolve()),
        "audit_output": str(Path(audit_output).resolve()),
        "scored": False,
    }

    if nominal_profile_path:
        if not report_output or not site_output:
            raise ValueError("report_output and site_output are required when nominal_profile_path is supplied")
        profile = read_json(nominal_profile_path)
        report = engine.score(
            features,
            profile,
            asset_id=str(asset_id),
            asset_name=str(asset_name),
            operating_regime=operating_regime,
        )
        # Attach raw-ingestion lineage for backend traceability.
        report.setdefault("lineage", {})["bin_ingestion"] = {
            "metadata_path": manifest["metadata_path"],
            "bundle_dir": manifest["bundle_dir"],
            "segment_index": manifest["segment_index"],
            "fs": manifest["fs"],
            "scale_mode": manifest["scale_mode"],
        }
        site_payload = engine.to_site_payload(report)
        write_json(report, report_output)
        write_json(site_payload, site_output)
        summary.update({
            "scored": True,
            "report_output": str(Path(report_output).resolve()),
            "site_output": str(Path(site_output).resolve()),
            "severity": report.get("summary", {}).get("overall_severity"),
            "plant_health": report.get("summary", {}).get("plant_health_index"),
        })

    return summary


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run full MCSA pipeline from metadata + binary sensor files")
    parser.add_argument("--metadata", required=True)
    parser.add_argument("--bundle-dir", required=True)
    parser.add_argument("--raw-dir", default=None)
    parser.add_argument("--prepared-dir", required=True)
    parser.add_argument("--segment-index", type=int, default=0)
    parser.add_argument("--dtype", choices=["auto", "float32", "float64"], default="auto")
    parser.add_argument("--endian", choices=["auto", "little", "big"], default="little")
    parser.add_argument("--scale-mode", choices=["metadata", "none", "raw"], default="metadata")
    parser.add_argument("--extractor", default="mcsa_enhanced_agah_algorithms.py")
    parser.add_argument("--canonical-csv", required=True)
    parser.add_argument("--audit-output", required=True)
    parser.add_argument("--config", default="fault_scoring_config.json")
    parser.add_argument("--nominal-profile", default=None)
    parser.add_argument("--report-output", default=None)
    parser.add_argument("--site-output", default=None)
    parser.add_argument("--telemetry-output", default=None)
    parser.add_argument("--asset-id", default=None)
    parser.add_argument("--asset-name", default=None)
    parser.add_argument("--operating-regime", default=None)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    summary = run_bin_pipeline(
        metadata_path=args.metadata,
        bundle_dir=args.bundle_dir,
        raw_dir=args.raw_dir,
        prepared_dir=args.prepared_dir,
        segment_index=args.segment_index,
        dtype=args.dtype,
        endian=args.endian,
        scale_mode=args.scale_mode,
        extractor_path=args.extractor,
        canonical_csv=args.canonical_csv,
        audit_output=args.audit_output,
        config_path=args.config,
        nominal_profile_path=args.nominal_profile,
        report_output=args.report_output,
        site_output=args.site_output,
        telemetry_output=args.telemetry_output,
        asset_id=args.asset_id,
        asset_name=args.asset_name,
        operating_regime=args.operating_regime,
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
