#!/usr/bin/env python3
"""Binary ingestion layer for the MCSA Fault Scoring v2 package.

This module bridges the production/raw-data format to the original MCSA
extractor contract. Production payloads arrive as:

    metadata.json
    CT_A_<timestamp>.bin
    CT_B_<timestamp>.bin
    CT_C_<timestamp>.bin
    optional VIB_*_<timestamp>.bin

The original extractor expects text files named CT_A.txt, CT_B.txt and CT_C.txt.
This layer reads metadata, resolves the binary files, detects or applies the
binary format, optionally converts sensor voltage to physical units, and writes
those three text files into a prepared segment folder. It can also create a
small downsampled telemetry JSON for dashboard previews.

The MCSA signal-processing formulas are not changed here. This is an input
normalization layer only.
"""

from __future__ import annotations

import argparse
import json
import math
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np

CURRENT_CHANNELS = ("CT_A", "CT_B", "CT_C")
SUPPORTED_DTYPES = {
    "float32": "f4",
    "float64": "f8",
}
SUPPORTED_ENDIANS = {
    "little": "<",
    "big": ">",
}


@dataclass(frozen=True)
class BinaryFormat:
    dtype: str
    endian: str
    numpy_dtype: str
    score: float
    reason: str


@dataclass(frozen=True)
class SignalStats:
    samples: int
    duration_s: float | None
    min: float | None
    max: float | None
    mean: float | None
    std: float | None
    rms: float | None
    p01: float | None
    p50: float | None
    p99: float | None


@dataclass(frozen=True)
class LoadedSignal:
    channel: str
    file_path: str
    dtype: str
    endian: str
    sample_rate_hz: float
    scale_mode: str
    raw_stats: SignalStats
    scaled_stats: SignalStats
    values: np.ndarray


def read_json(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json(data: Mapping[str, Any] | Sequence[Any], path: str | Path) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2, allow_nan=False)


def _finite_float(value: Any, default: float | None = None) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return number if math.isfinite(number) else default


def _stats(values: np.ndarray, sample_rate_hz: float | None = None) -> SignalStats:
    arr = np.asarray(values, dtype=np.float64)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return SignalStats(0, None, None, None, None, None, None, None, None, None)
    duration = float(arr.size / sample_rate_hz) if sample_rate_hz else None
    return SignalStats(
        samples=int(arr.size),
        duration_s=duration,
        min=float(np.min(arr)),
        max=float(np.max(arr)),
        mean=float(np.mean(arr)),
        std=float(np.std(arr)),
        rms=float(np.sqrt(np.mean(arr * arr))),
        p01=float(np.percentile(arr, 1)),
        p50=float(np.percentile(arr, 50)),
        p99=float(np.percentile(arr, 99)),
    )


def normalize_metadata(metadata: Mapping[str, Any]) -> dict[str, Any]:
    """Normalize the two metadata styles used by the current raw bundles.

    Supported input layouts:

    1. Asset-level metadata:
       {"motor_id": ..., "monitoring_config": {"fs": ..., "sensors": {...}}}

    2. Segment-level metadata:
       {"motor_id": ..., "fs": ..., "sensors": {...}, "segments": [...]}
    """
    monitoring = metadata.get("monitoring_config") or {}
    sensors = metadata.get("sensors") or monitoring.get("sensors") or {}
    fs = metadata.get("fs", monitoring.get("fs"))
    fs = _finite_float(fs)
    if fs is None or fs <= 0:
        raise ValueError("metadata must contain a positive sampling frequency as fs or monitoring_config.fs")

    asset_id = (
        metadata.get("asset_id")
        or metadata.get("motor_id")
        or metadata.get("id")
        or "UNKNOWN_ASSET"
    )
    asset_name = metadata.get("asset_name") or metadata.get("name") or str(asset_id)

    return {
        "asset_id": str(asset_id),
        "asset_name": str(asset_name),
        "plant": metadata.get("plant"),
        "line": metadata.get("line"),
        "zone": metadata.get("zone"),
        "asset_type": metadata.get("asset_type"),
        "status": metadata.get("status"),
        "alarm_level": metadata.get("alarm_level"),
        "description": metadata.get("description"),
        "fs": float(fs),
        "sensors": sensors,
        "segments": metadata.get("segments") or [],
    }


def infer_segments_from_files(bundle_dir: str | Path, channels: Sequence[str] = CURRENT_CHANNELS) -> list[dict[str, Any]]:
    """Infer segments when metadata has no explicit `segments` array."""
    root = Path(bundle_dir)
    groups: dict[str, dict[str, str]] = {}
    pattern = re.compile(r"^(?P<channel>.+?)_(?P<ts>\d+)\.bin$", re.IGNORECASE)
    for path in root.rglob("*.bin"):
        match = pattern.match(path.name)
        if not match:
            continue
        channel = match.group("channel")
        ts = match.group("ts")
        if channel in channels or channel.startswith("VIB_"):
            groups.setdefault(ts, {})[channel] = str(path.relative_to(root))
    segments: list[dict[str, Any]] = []
    for ts, files in sorted(groups.items()):
        if all(channel in files for channel in channels):
            start_ts = int(ts)
            segments.append({"start_ts": start_ts, "end_ts": None, "files": files})
    if not segments:
        # Fallback: choose latest matching bin for each requested current channel.
        files: dict[str, str] = {}
        for channel in channels:
            matches = sorted(root.rglob(f"{channel}_*.bin")) or sorted(root.rglob(f"{channel}.bin"))
            if matches:
                files[channel] = str(matches[-1].relative_to(root))
        if all(channel in files for channel in channels):
            segments.append({"start_ts": None, "end_ts": None, "files": files})
    return segments


def select_segment(normalized_metadata: Mapping[str, Any], bundle_dir: str | Path, segment_index: int = 0) -> dict[str, Any]:
    segments = list(normalized_metadata.get("segments") or [])
    if not segments:
        segments = infer_segments_from_files(bundle_dir)
    if not segments:
        raise FileNotFoundError("No usable CT_A/CT_B/CT_C segment found in metadata or bundle directory")
    if segment_index < 0 or segment_index >= len(segments):
        raise IndexError(f"segment_index {segment_index} is outside available segment count {len(segments)}")
    return segments[segment_index]


def resolve_file(reference: str | Path, *, bundle_dir: str | Path, raw_dir: str | Path | None = None) -> Path:
    """Resolve a path from metadata against common production/test layouts."""
    ref = Path(reference)
    candidates: list[Path] = []
    if ref.is_absolute():
        candidates.append(ref)
    bundle = Path(bundle_dir)
    candidates.extend([
        bundle / ref,
        bundle / ref.name,
        bundle / "raw" / ref.name,
    ])
    if raw_dir is not None:
        raw = Path(raw_dir)
        candidates.extend([
            raw / ref,
            raw / ref.name,
        ])
    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()
    raise FileNotFoundError(f"Could not resolve binary file reference {reference!r}. Tried: {[str(c) for c in candidates]}")


def _candidate_array(path: Path, dtype: str, endian: str, max_samples_for_score: int = 250_000) -> np.ndarray | None:
    np_dtype = np.dtype(SUPPORTED_ENDIANS[endian] + SUPPORTED_DTYPES[dtype])
    if path.stat().st_size % np_dtype.itemsize != 0:
        return None
    arr = np.fromfile(path, dtype=np_dtype)
    if arr.size == 0:
        return None
    if arr.size > max_samples_for_score:
        step = max(1, arr.size // max_samples_for_score)
        arr = arr[::step]
    return arr.astype(np.float64, copy=False)


def detect_binary_format(
    path: str | Path,
    *,
    fs: float | None = None,
    expected_duration_s: float | None = None,
    dtype: str = "auto",
    endian: str = "little",
) -> BinaryFormat:
    """Detect binary format, defaulting toward little-endian float32 when plausible.

    The current field bundle has no explicit dtype key in metadata. Production
    should add one eventually. Until then, this function scores float32/float64
    interpretations and prefers stable, finite, physically plausible values.
    """
    path = Path(path)
    dtype_choices = tuple(SUPPORTED_DTYPES) if dtype == "auto" else (dtype,)
    endian_choices = tuple(SUPPORTED_ENDIANS) if endian == "auto" else (endian,)
    candidates: list[BinaryFormat] = []

    for candidate_dtype in dtype_choices:
        if candidate_dtype not in SUPPORTED_DTYPES:
            raise ValueError(f"Unsupported dtype: {candidate_dtype}")
        for candidate_endian in endian_choices:
            if candidate_endian not in SUPPORTED_ENDIANS:
                raise ValueError(f"Unsupported endian: {candidate_endian}")
            arr = _candidate_array(path, candidate_dtype, candidate_endian)
            if arr is None:
                continue
            finite = np.isfinite(arr)
            finite_fraction = float(np.mean(finite)) if arr.size else 0.0
            if finite_fraction < 0.999:
                candidates.append(BinaryFormat(candidate_dtype, candidate_endian, SUPPORTED_ENDIANS[candidate_endian] + SUPPORTED_DTYPES[candidate_dtype], -1e9, "non-finite values"))
                continue
            clean = arr[finite]
            std = float(np.std(clean))
            max_abs = float(np.max(np.abs(clean)))
            median_abs = float(np.median(np.abs(clean)))
            mean_abs = abs(float(np.mean(clean)))
            samples = path.stat().st_size // np.dtype(SUPPORTED_ENDIANS[candidate_endian] + SUPPORTED_DTYPES[candidate_dtype]).itemsize

            score = 0.0
            reason_parts: list[str] = []
            score += 100.0 * finite_fraction
            reason_parts.append("finite")
            if 1e-7 < std < 1e5:
                score += 25.0
                reason_parts.append("non-flat")
            if 1e-4 <= median_abs <= 1e3 and max_abs <= 1e6:
                score += 25.0
                reason_parts.append("plausible-amplitude")
            if std > 0 and mean_abs / std < 0.25:
                score += 10.0
                reason_parts.append("near-zero-mean")
            if expected_duration_s and fs:
                expected_samples = max(1.0, fs * expected_duration_s)
                ratio = samples / expected_samples
                # Do not reject mismatches, but prefer formats closer to the
                # segment duration when metadata and file length agree.
                if 0.8 <= ratio <= 1.2:
                    score += 50.0
                    reason_parts.append("matches-segment-duration")
                elif 0.25 <= ratio <= 4.0:
                    score += 10.0
                    reason_parts.append("reasonable-duration")
            if dtype == "auto" and candidate_dtype == "float32":
                # Sensor streams are commonly serialized as float32; this also
                # matches the current uploaded bundle better than packed-pair
                # float64 interpretation.
                score += 35.0
                reason_parts.append("float32-preference")
            if endian == "auto" and candidate_endian == "little":
                score += 5.0
                reason_parts.append("little-endian-preference")
            candidates.append(BinaryFormat(candidate_dtype, candidate_endian, SUPPORTED_ENDIANS[candidate_endian] + SUPPORTED_DTYPES[candidate_dtype], score, ", ".join(reason_parts)))

    if not candidates:
        raise ValueError(f"No valid binary format found for {path}")
    best = max(candidates, key=lambda item: item.score)
    if best.score < 0:
        raise ValueError(f"Could not detect a valid finite binary format for {path}")
    return best


def load_binary_values(path: str | Path, *, dtype: str = "auto", endian: str = "little", fs: float | None = None, expected_duration_s: float | None = None) -> tuple[np.ndarray, BinaryFormat]:
    fmt = detect_binary_format(path, fs=fs, expected_duration_s=expected_duration_s, dtype=dtype, endian=endian)
    arr = np.fromfile(Path(path), dtype=np.dtype(fmt.numpy_dtype)).astype(np.float64, copy=False)
    return arr, fmt


def scale_signal(values: np.ndarray, sensor_spec: Mapping[str, Any], *, scale_mode: str) -> np.ndarray:
    """Convert sensor samples to physical units when requested.

    `scale_mode='none'` leaves values as stored in the binary file.
    `scale_mode='metadata'` applies the metadata calibration formula:

    Current channel:
        primary_current_A = raw_value / divider_gain / r_shunt * ct_ratio

    Vibration channel:
        acceleration_g = raw_value / divider_gain * 1000 / sensitivity_mV_g

    This assumes `raw_value` is voltage at the acquisition input after the
    divider. If production binaries already contain engineering units, use
    `scale_mode='none'` and store that decision in the ingestion manifest.
    """
    if scale_mode in {"none", "raw"}:
        return np.asarray(values, dtype=np.float64)
    if scale_mode != "metadata":
        raise ValueError("scale_mode must be 'metadata' or 'none'")

    sensor_type = str(sensor_spec.get("type", "")).lower()
    divider_gain = _finite_float(sensor_spec.get("divider_gain"), 1.0) or 1.0
    divider_gain = divider_gain if abs(divider_gain) > 1e-12 else 1.0

    if sensor_type == "current":
        ct_ratio = _finite_float(sensor_spec.get("ct_ratio"), 1.0) or 1.0
        r_shunt = _finite_float(sensor_spec.get("r_shunt"), 1.0) or 1.0
        if abs(r_shunt) < 1e-12:
            r_shunt = 1.0
        return np.asarray(values, dtype=np.float64) / divider_gain / r_shunt * ct_ratio

    if sensor_type == "vibration":
        sensitivity = _finite_float(sensor_spec.get("sensitivity_mV_g"), None)
        if sensitivity is None or abs(sensitivity) < 1e-12:
            return np.asarray(values, dtype=np.float64)
        return np.asarray(values, dtype=np.float64) / divider_gain * 1000.0 / sensitivity

    return np.asarray(values, dtype=np.float64)


def load_channel(
    *,
    channel: str,
    file_path: str | Path,
    sensor_spec: Mapping[str, Any],
    sample_rate_hz: float,
    expected_duration_s: float | None,
    dtype: str,
    endian: str,
    scale_mode: str,
) -> LoadedSignal:
    raw, fmt = load_binary_values(file_path, dtype=dtype, endian=endian, fs=sample_rate_hz, expected_duration_s=expected_duration_s)
    scaled = scale_signal(raw, sensor_spec, scale_mode=scale_mode)
    return LoadedSignal(
        channel=channel,
        file_path=str(Path(file_path).resolve()),
        dtype=fmt.dtype,
        endian=fmt.endian,
        sample_rate_hz=sample_rate_hz,
        scale_mode=scale_mode,
        raw_stats=_stats(raw, sample_rate_hz),
        scaled_stats=_stats(scaled, sample_rate_hz),
        values=scaled,
    )


def downsample(values: np.ndarray, original_rate: float, target_rate: float, method: str = "average") -> tuple[list[float], list[float]]:
    if target_rate <= 0:
        raise ValueError("target_rate must be positive")
    decimation = max(1, int(round(original_rate / target_rate)))
    values = np.asarray(values, dtype=np.float64)
    if method == "decimate":
        y = values[::decimation]
    elif method == "average":
        blocks = len(values) // decimation
        if blocks <= 0:
            y = values
        else:
            y = values[: blocks * decimation].reshape(blocks, decimation).mean(axis=1)
    else:
        raise ValueError("method must be 'average' or 'decimate'")
    dt = decimation / original_rate
    t = [float(i * dt) for i in range(len(y))]
    return t, [float(v) for v in y]


def prepare_segment_for_extractor(
    *,
    metadata_path: str | Path,
    bundle_dir: str | Path,
    output_dir: str | Path,
    segment_index: int = 0,
    raw_dir: str | Path | None = None,
    dtype: str = "auto",
    endian: str = "little",
    scale_mode: str = "metadata",
    channels: Sequence[str] = CURRENT_CHANNELS,
    include_telemetry_channels: bool = True,
    telemetry_output: str | Path | None = None,
    telemetry_target_rate: float = 2.5,
) -> dict[str, Any]:
    """Prepare CT_A.txt/CT_B.txt/CT_C.txt from a .bin + metadata bundle."""
    metadata_path = Path(metadata_path)
    metadata = read_json(metadata_path)
    normalized = normalize_metadata(metadata)
    segment = select_segment(normalized, bundle_dir, segment_index=segment_index)
    segment_files = dict(segment.get("files") or {})
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)

    start_ts = _finite_float(segment.get("start_ts"), None)
    end_ts = _finite_float(segment.get("end_ts"), None)
    expected_duration = None
    if start_ts is not None and end_ts is not None and end_ts > start_ts:
        expected_duration = float(end_ts - start_ts)

    sensors = dict(normalized["sensors"])
    loaded: dict[str, LoadedSignal] = {}
    telemetry: dict[str, Any] = {}

    # Load current channels required by the MCSA extractor.
    for channel in channels:
        if channel not in segment_files:
            raise KeyError(f"Segment does not contain required channel {channel!r}")
        sensor_spec = sensors.get(channel) or {}
        bin_path = resolve_file(segment_files[channel], bundle_dir=bundle_dir, raw_dir=raw_dir)
        loaded[channel] = load_channel(
            channel=channel,
            file_path=bin_path,
            sensor_spec=sensor_spec,
            sample_rate_hz=float(normalized["fs"]),
            expected_duration_s=expected_duration,
            dtype=dtype,
            endian=endian,
            scale_mode=scale_mode,
        )
        np.savetxt(output / f"{channel}.txt", loaded[channel].values, fmt="%.12g")

    # Optionally load non-current channels for telemetry preview only.
    if include_telemetry_channels:
        for channel, ref in segment_files.items():
            if channel in loaded:
                signal_obj = loaded[channel]
            else:
                sensor_spec = sensors.get(channel) or {}
                try:
                    bin_path = resolve_file(ref, bundle_dir=bundle_dir, raw_dir=raw_dir)
                    signal_obj = load_channel(
                        channel=channel,
                        file_path=bin_path,
                        sensor_spec=sensor_spec,
                        sample_rate_hz=float(normalized["fs"]),
                        expected_duration_s=expected_duration,
                        dtype=dtype,
                        endian=endian,
                        scale_mode=scale_mode,
                    )
                except Exception as exc:  # keep current extraction robust
                    telemetry[channel] = {"error": str(exc)}
                    continue
                loaded[channel] = signal_obj
                # Preserve high-rate physical-unit data for specialized vibration
                # and encoder analysis. NPY avoids lossy text conversion and is
                # memory-map friendly for long captures.
                np.save(output / f"{channel}.npy", signal_obj.values, allow_pickle=False)
            t, y = downsample(signal_obj.values, float(normalized["fs"]), telemetry_target_rate)
            telemetry[channel] = {
                "time": t,
                "values": y,
                "sample_rate_hz": float(normalized["fs"]),
                "target_rate_hz": telemetry_target_rate,
                "units": "A" if str((sensors.get(channel) or {}).get("type", "")).lower() == "current" else "g" if str((sensors.get(channel) or {}).get("type", "")).lower() == "vibration" else "unknown",
                "stats": asdict(signal_obj.scaled_stats),
            }

    manifest = {
        "schema_version": "1.0",
        "stage": "bin_ingestion_to_mcsa_text_contract",
        "metadata_path": str(metadata_path.resolve()),
        "bundle_dir": str(Path(bundle_dir).resolve()),
        "raw_dir": str(Path(raw_dir).resolve()) if raw_dir else None,
        "output_dir": str(output.resolve()),
        "asset": {k: normalized.get(k) for k in ["asset_id", "asset_name", "plant", "line", "zone", "asset_type", "status", "alarm_level", "description"]},
        "fs": float(normalized["fs"]),
        "segment_index": segment_index,
        "segment": segment,
        "expected_duration_s_from_metadata": expected_duration,
        "scale_mode": scale_mode,
        "dtype_request": dtype,
        "endian_request": endian,
        "mcsa_extractor_contract_outputs": {channel: str((output / f"{channel}.txt").resolve()) for channel in channels},
        "channels": {
            channel: {
                "file_path": signal_obj.file_path,
                "dtype": signal_obj.dtype,
                "endian": signal_obj.endian,
                "sample_rate_hz": signal_obj.sample_rate_hz,
                "scale_mode": signal_obj.scale_mode,
                "raw_stats": asdict(signal_obj.raw_stats),
                "scaled_stats": asdict(signal_obj.scaled_stats),
                "prepared_signal_path": str(
                    (output / (f"{channel}.txt" if channel in channels else f"{channel}.npy")).resolve()
                ),
            }
            for channel, signal_obj in loaded.items()
        },
    }
    write_json(manifest, output / "ingestion_manifest.json")
    if telemetry_output:
        write_json({"schema_version": "1.0", "asset": manifest["asset"], "segment": segment, "signals": telemetry}, telemetry_output)
    return manifest


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Convert metadata + .bin sensor bundle into CT_A/B/C text files for the MCSA extractor")
    parser.add_argument("--metadata", required=True, help="Path to metadata.json")
    parser.add_argument("--bundle-dir", required=True, help="Folder containing metadata-relative binary files")
    parser.add_argument("--raw-dir", default=None, help="Optional raw/ folder override")
    parser.add_argument("--output-dir", required=True, help="Prepared segment folder where CT_A.txt/CT_B.txt/CT_C.txt will be written")
    parser.add_argument("--segment-index", type=int, default=0)
    parser.add_argument("--dtype", choices=["auto", "float32", "float64"], default="auto")
    parser.add_argument("--endian", choices=["auto", "little", "big"], default="little")
    parser.add_argument("--scale-mode", choices=["metadata", "none", "raw"], default="metadata")
    parser.add_argument("--telemetry-output", default=None, help="Optional downsampled JSON output for dashboard previews")
    parser.add_argument("--telemetry-target-rate", type=float, default=2.5)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    manifest = prepare_segment_for_extractor(
        metadata_path=args.metadata,
        bundle_dir=args.bundle_dir,
        raw_dir=args.raw_dir,
        output_dir=args.output_dir,
        segment_index=args.segment_index,
        dtype=args.dtype,
        endian=args.endian,
        scale_mode=args.scale_mode,
        telemetry_output=args.telemetry_output,
        telemetry_target_rate=args.telemetry_target_rate,
    )
    print(json.dumps({
        "status": "ok",
        "asset": manifest["asset"],
        "fs": manifest["fs"],
        "output_dir": manifest["output_dir"],
        "channels": {name: {"samples": info["scaled_stats"]["samples"], "duration_s": info["scaled_stats"]["duration_s"], "dtype": info["dtype"]} for name, info in manifest["channels"].items()},
    }, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
