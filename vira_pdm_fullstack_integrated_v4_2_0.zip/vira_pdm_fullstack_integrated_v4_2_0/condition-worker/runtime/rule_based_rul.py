#!/usr/bin/env python3
"""Deterministic multi-indicator Remaining Useful Life estimator.

The algorithm is intentionally rule based.  It never trains a neural network and
never converts diagnostic evidence directly into a failure probability.  It:

1. resolves configured current, vibration, energy and metadata indicators;
2. converts each indicator to a normalized damage score using explicit warning
   and validated failure thresholds;
3. fuses component indicators with a weighted power mean;
4. applies median filtering, EWMA smoothing, persistence and hysteresis;
5. estimates a robust Theil-Sen degradation slope;
6. compares linear and accelerating threshold-crossing models;
7. generates conservative/median/optimistic RUL bounds only when every
   validity gate passes;
8. stores observations, state, full estimates, prediction summaries and the
   asset-level limiting-component RUL transactionally.

A configured threshold whose ``threshold_kind`` is not ``validated_failure``
can still produce a time-to-maintenance-threshold advisory, but it is not
published as genuine RUL unless ``allow_proxy_rul`` is explicitly enabled.
"""

from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import math
import sqlite3
import statistics
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np

SCHEMA_VERSION = "1.0"
ALGORITHM_NAME = "Adaptive Multi-Indicator Threshold-Crossing RUL"
ALGORITHM_VERSION = "1.0.0"
EPS = 1e-12


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------

def _finite(value: Any, default: float | None = None) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return number if math.isfinite(number) else default


def _clip(value: float, minimum: float = 0.0, maximum: float = 1.0) -> float:
    return max(minimum, min(maximum, float(value)))


def _stable_id(prefix: str, *parts: Any, length: int = 24) -> str:
    raw = "|".join(str(part) for part in parts)
    return f"{prefix}-{hashlib.sha256(raw.encode('utf-8')).hexdigest()[:length]}"


def _json_safe(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, np.ndarray):
        return [_json_safe(v) for v in value.tolist()]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        number = float(value)
        return number if math.isfinite(number) else None
    if isinstance(value, datetime):
        return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    if isinstance(value, Path):
        return str(value)
    return value


def _dumps(value: Any) -> str:
    return json.dumps(_json_safe(value), ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def _parse_timestamp(value: Any, fallback: datetime | None = None) -> datetime:
    if isinstance(value, datetime):
        dt = value
    elif isinstance(value, (int, float)):
        dt = datetime.fromtimestamp(float(value), tz=timezone.utc)
    elif value is not None and str(value).strip():
        text = str(value).strip()
        try:
            dt = datetime.fromtimestamp(float(text), tz=timezone.utc)
        except ValueError:
            dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
    else:
        dt = fallback or datetime.now(timezone.utc)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _sqlite_time(value: datetime) -> str:
    return value.astimezone(timezone.utc).replace(tzinfo=None).isoformat(sep=" ")


def read_json(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object in {path}")
    return value


def write_json(path: str | Path, value: Any) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    temporary.write_text(json.dumps(_json_safe(value), ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(output)


def table_exists(connection: sqlite3.Connection, table: str) -> bool:
    return connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
    ).fetchone() is not None


def table_columns(connection: sqlite3.Connection, table: str) -> set[str]:
    return {str(row[1]) for row in connection.execute(f'PRAGMA table_info("{table}")')}


# ---------------------------------------------------------------------------
# Configuration validation
# ---------------------------------------------------------------------------

REQUIRED_COMPONENT_KEYS = {
    "code", "display_name", "threshold_kind", "threshold_reliability",
    "recommended_action", "indicators",
}


def validate_config(config: Mapping[str, Any]) -> None:
    if str(config.get("schema_version")) != SCHEMA_VERSION:
        raise ValueError(f"Unsupported RUL config schema_version={config.get('schema_version')!r}")
    gates = config.get("gates") or {}
    if int(gates.get("minimum_history_windows", 0)) < 3:
        raise ValueError("gates.minimum_history_windows must be at least 3")
    if not 0 <= float(gates.get("minimum_monotonicity_ratio", 0.0)) <= 1:
        raise ValueError("minimum_monotonicity_ratio must be in [0,1]")
    if float(gates.get("maximum_forecast_multiple", 0.0)) <= 0:
        raise ValueError("maximum_forecast_multiple must be positive")
    components = config.get("components")
    if not isinstance(components, list) or not components:
        raise ValueError("RUL config must contain a non-empty components list")
    codes: set[str] = set()
    for component in components:
        if not isinstance(component, Mapping):
            raise ValueError("Every component definition must be an object")
        missing = REQUIRED_COMPONENT_KEYS - set(component)
        if missing:
            raise ValueError(f"Component is missing required keys: {sorted(missing)}")
        code = str(component["code"])
        if code in codes:
            raise ValueError(f"Duplicate component code: {code}")
        codes.add(code)
        reliability = float(component["threshold_reliability"])
        if not 0 <= reliability <= 1:
            raise ValueError(f"threshold_reliability for {code} must be in [0,1]")
        indicators = component.get("indicators")
        if not isinstance(indicators, list) or not indicators:
            raise ValueError(f"Component {code} must contain indicators")
        total_weight = 0.0
        for indicator in indicators:
            if not isinstance(indicator, Mapping):
                raise ValueError(f"Invalid indicator in component {code}")
            for key in ("name", "source_pattern", "weight", "direction", "warning", "failure"):
                if key not in indicator:
                    raise ValueError(f"Indicator in {code} is missing {key}")
            warning = float(indicator["warning"])
            failure = float(indicator["failure"])
            direction = str(indicator["direction"])
            if direction == "increase" and not failure > warning:
                raise ValueError(f"Increasing indicator {indicator['name']} requires failure > warning")
            if direction == "decrease" and not failure < warning:
                raise ValueError(f"Decreasing indicator {indicator['name']} requires failure < warning")
            if direction not in {"increase", "decrease", "absolute_deviation"}:
                raise ValueError(f"Unsupported direction {direction!r}")
            weight = float(indicator["weight"])
            if weight <= 0:
                raise ValueError("Indicator weights must be positive")
            total_weight += weight
        if total_weight <= 0:
            raise ValueError(f"Component {code} has no positive weight")


def load_config(path: str | Path) -> dict[str, Any]:
    config = read_json(path)
    validate_config(config)
    return config


# ---------------------------------------------------------------------------
# Source catalog and indicator evaluation
# ---------------------------------------------------------------------------

def _add_catalog(catalog: dict[str, float], key: str, value: Any) -> None:
    number = _finite(value)
    if number is not None:
        catalog[str(key)] = number


def build_source_catalog(
    *,
    canonical_features: Mapping[str, Any],
    current_report: Mapping[str, Any],
    vibration_report: Mapping[str, Any],
    energy_report: Mapping[str, Any],
    metadata: Mapping[str, Any],
) -> dict[str, float]:
    """Flatten all deterministic diagnostic outputs into a stable key space."""
    catalog: dict[str, float] = {}

    for name, value in canonical_features.items():
        _add_catalog(catalog, f"current.feature.{name}", value)

    for fault in current_report.get("fault_scores") or []:
        if not isinstance(fault, Mapping):
            continue
        code = str(fault.get("fault_code") or fault.get("code") or "UNKNOWN")
        evidence = _finite(fault.get("evidence_pct"))
        if evidence is not None:
            _add_catalog(catalog, f"current.fault.{code}.evidence_score", evidence / 100.0)
        coverage = _finite(fault.get("coverage_pct"))
        if coverage is not None:
            _add_catalog(catalog, f"current.fault.{code}.coverage", coverage / 100.0)

    aggregate_vibration_features: dict[str, list[float]] = {}
    for channel in vibration_report.get("channels") or []:
        if not isinstance(channel, Mapping):
            continue
        channel_name = str(channel.get("channel") or "UNKNOWN")
        for feature_name, value in (channel.get("flat_features") or {}).items():
            number = _finite(value)
            if number is None:
                continue
            _add_catalog(catalog, f"vibration.channel.{channel_name}.feature.{feature_name}", number)
            aggregate_vibration_features.setdefault(str(feature_name), []).append(number)
    for feature_name, values in aggregate_vibration_features.items():
        _add_catalog(catalog, f"vibration.feature_max.{feature_name}", max(values))
        _add_catalog(catalog, f"vibration.feature_mean.{feature_name}", statistics.fmean(values))

    for fault in vibration_report.get("fault_scores") or []:
        if not isinstance(fault, Mapping):
            continue
        code = str(fault.get("fault_code") or "VIB-UNKNOWN")
        _add_catalog(catalog, f"vibration.fault.{code}.evidence_score", fault.get("evidence_score"))

    for key, value in (energy_report.get("summary") or {}).items():
        _add_catalog(catalog, f"energy.summary.{key}", value)

    mechanical = metadata.get("mechanical") or metadata.get("machinery") or {}
    electrical = metadata.get("electrical") or {}
    operating = metadata.get("operating_condition") or metadata.get("operation") or {}
    for prefix, source in (("metadata.mechanical", mechanical), ("metadata.electrical", electrical), ("metadata.operating", operating)):
        if isinstance(source, Mapping):
            for key, value in source.items():
                _add_catalog(catalog, f"{prefix}.{key}", value)
    for key in ("speed_rpm", "load_pct", "torque_nm", "temperature_c"):
        _add_catalog(catalog, f"metadata.{key}", metadata.get(key))
    return catalog


def _aggregate(values: Sequence[float], method: str) -> float:
    if not values:
        raise ValueError("Cannot aggregate an empty sequence")
    method = method.lower()
    if method == "max":
        return max(values)
    if method == "min":
        return min(values)
    if method == "mean":
        return statistics.fmean(values)
    if method == "median":
        return statistics.median(values)
    if method == "rms":
        return math.sqrt(statistics.fmean(v * v for v in values))
    if method == "max_abs":
        return max(values, key=abs)
    raise ValueError(f"Unsupported aggregation method: {method}")


def _baseline_entry(baseline: Mapping[str, Any] | None, component: str, indicator: str) -> Mapping[str, Any] | None:
    if not baseline:
        return None
    components = baseline.get("components") or {}
    component_entry = components.get(component) if isinstance(components, Mapping) else None
    if not isinstance(component_entry, Mapping):
        return None
    indicators = component_entry.get("indicators") or {}
    value = indicators.get(indicator) if isinstance(indicators, Mapping) else None
    return value if isinstance(value, Mapping) else None


def evaluate_indicator(
    rule: Mapping[str, Any],
    *,
    component_code: str,
    catalog: Mapping[str, float],
    baseline: Mapping[str, Any] | None,
) -> dict[str, Any]:
    pattern = str(rule["source_pattern"])
    matches = [(name, value) for name, value in catalog.items() if fnmatch.fnmatchcase(name, pattern)]
    if not matches:
        return {
            "name": str(rule["name"]),
            "available": False,
            "reason": "source_pattern_not_found",
            "source_pattern": pattern,
            "weight": float(rule["weight"]),
        }
    values = [float(value) for _, value in matches]
    aggregate = _aggregate(values, str(rule.get("aggregation", "max")))
    baseline_row = _baseline_entry(baseline, component_code, str(rule["name"]))

    warning = float(rule["warning"])
    failure = float(rule["failure"])
    direction = str(rule["direction"])
    normalization = str(rule.get("normalization", "absolute"))
    normalized_value = aggregate
    threshold_source = str(rule.get("threshold_source") or "configuration")

    if normalization == "robust_z":
        if not baseline_row:
            return {
                "name": str(rule["name"]),
                "available": False,
                "reason": "healthy_baseline_missing",
                "source_pattern": pattern,
                "weight": float(rule["weight"]),
                "matched_sources": [name for name, _ in matches],
            }
        median = _finite(baseline_row.get("median"))
        mad = _finite(baseline_row.get("mad"))
        if median is None or mad is None:
            return {
                "name": str(rule["name"]),
                "available": False,
                "reason": "healthy_baseline_invalid",
                "source_pattern": pattern,
                "weight": float(rule["weight"]),
            }
        sigma = max(1.4826 * abs(mad), EPS)
        if direction == "increase":
            normalized_value = (aggregate - median) / sigma
        elif direction == "decrease":
            normalized_value = (median - aggregate) / sigma
        else:
            normalized_value = abs(aggregate - median) / sigma
        threshold_source = str(baseline_row.get("version") or baseline.get("profile_version") or "healthy_baseline")
        direction = "increase"  # robust-z is already oriented toward deterioration

    if direction == "increase":
        damage = _clip((normalized_value - warning) / max(failure - warning, EPS))
    elif direction == "decrease":
        damage = _clip((warning - normalized_value) / max(warning - failure, EPS))
    else:
        damage = _clip((abs(normalized_value) - abs(warning)) / max(abs(failure) - abs(warning), EPS))

    return {
        "name": str(rule["name"]),
        "available": True,
        "source_pattern": pattern,
        "matched_sources": [name for name, _ in matches],
        "aggregation": str(rule.get("aggregation", "max")),
        "raw_value": aggregate,
        "normalized_value": normalized_value,
        "normalization": normalization,
        "direction": str(rule["direction"]),
        "warning_threshold": warning,
        "failure_threshold": failure,
        "damage_score": damage,
        "weight": float(rule["weight"]),
        "threshold_source": threshold_source,
    }


def component_damage(
    component: Mapping[str, Any],
    *,
    catalog: Mapping[str, float],
    baseline: Mapping[str, Any] | None,
    power: float,
) -> dict[str, Any]:
    code = str(component["code"])
    evaluated = [
        evaluate_indicator(rule, component_code=code, catalog=catalog, baseline=baseline)
        for rule in component["indicators"]
    ]
    available = [row for row in evaluated if row.get("available")]
    expected = len(evaluated)
    coverage = 100.0 * len(available) / expected if expected else 0.0
    if not available:
        return {
            "component": code,
            "display_name": component["display_name"],
            "damage_index_raw": None,
            "feature_coverage_pct": coverage,
            "valid_feature_count": 0,
            "expected_feature_count": expected,
            "indicator_results": evaluated,
            "threshold_kind": component["threshold_kind"],
            "threshold_reliability": float(component["threshold_reliability"]),
            "recommended_action": component["recommended_action"],
        }
    numerator = sum(float(row["weight"]) * float(row["damage_score"]) ** power for row in available)
    denominator = sum(float(row["weight"]) for row in available)
    damage = (numerator / max(denominator, EPS)) ** (1.0 / power)
    return {
        "component": code,
        "display_name": component["display_name"],
        "damage_index_raw": _clip(damage),
        "feature_coverage_pct": coverage,
        "valid_feature_count": len(available),
        "expected_feature_count": expected,
        "indicator_results": evaluated,
        "threshold_kind": component["threshold_kind"],
        "threshold_reliability": float(component["threshold_reliability"]),
        "recommended_action": component["recommended_action"],
    }


# ---------------------------------------------------------------------------
# Database schema
# ---------------------------------------------------------------------------

def _add_column(connection: sqlite3.Connection, table: str, definition: str) -> bool:
    name = definition.split()[0].strip('"')
    if name in table_columns(connection, table):
        return False
    connection.execute(f'ALTER TABLE "{table}" ADD COLUMN {definition}')
    return True


def ensure_rul_schema(connection: sqlite3.Connection) -> dict[str, Any]:
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS rul_indicator_history (
            id TEXT PRIMARY KEY NOT NULL,
            asset_id TEXT NOT NULL REFERENCES assets(id),
            component TEXT NOT NULL,
            capture_id TEXT NOT NULL,
            episode_id TEXT NOT NULL,
            timestamp DATETIME NOT NULL,
            operating_regime TEXT NOT NULL,
            damage_index_raw REAL,
            damage_index_filtered REAL,
            damage_index_smoothed REAL,
            state TEXT NOT NULL,
            feature_coverage_pct REAL NOT NULL,
            valid_feature_count INTEGER NOT NULL,
            expected_feature_count INTEGER NOT NULL,
            data_quality_score REAL NOT NULL,
            threshold_kind TEXT NOT NULL,
            threshold_reliability REAL NOT NULL,
            indicator_values_json JSON NOT NULL,
            reason_codes_json JSON NOT NULL,
            algorithm_version TEXT NOT NULL,
            created_at DATETIME NOT NULL,
            UNIQUE(asset_id, component, capture_id)
        )
        """
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS ix_rul_history_asset_component_time ON rul_indicator_history(asset_id,component,timestamp)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS ix_rul_history_episode_regime ON rul_indicator_history(asset_id,component,episode_id,operating_regime,timestamp)"
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS rul_component_state (
            asset_id TEXT NOT NULL REFERENCES assets(id),
            component TEXT NOT NULL,
            episode_id TEXT NOT NULL,
            current_state TEXT NOT NULL,
            worsen_count INTEGER NOT NULL DEFAULT 0,
            recover_count INTEGER NOT NULL DEFAULT 0,
            last_damage REAL,
            last_capture_id TEXT,
            last_timestamp DATETIME,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY(asset_id, component)
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS rul_estimates (
            id TEXT PRIMARY KEY NOT NULL,
            asset_id TEXT NOT NULL REFERENCES assets(id),
            component TEXT NOT NULL,
            capture_id TEXT NOT NULL,
            episode_id TEXT NOT NULL,
            timestamp DATETIME NOT NULL,
            operating_regime TEXT NOT NULL,
            status TEXT NOT NULL,
            state TEXT NOT NULL,
            rul_available INTEGER NOT NULL,
            damage_index REAL,
            degradation_rate_per_hour REAL,
            trend_model TEXT,
            rul_low_hours REAL,
            rul_median_hours REAL,
            rul_high_hours REAL,
            time_to_warning_hours REAL,
            time_to_critical_hours REAL,
            time_to_failure_advisory_hours REAL,
            estimate_quality REAL NOT NULL,
            data_quality_score REAL NOT NULL,
            feature_coverage_pct REAL NOT NULL,
            monotonicity_ratio REAL,
            fit_error REAL,
            history_window_count INTEGER NOT NULL,
            observed_history_hours REAL,
            threshold_kind TEXT NOT NULL,
            threshold_reliability REAL NOT NULL,
            healthy_profile_version TEXT,
            threshold_config_version TEXT NOT NULL,
            algorithm_name TEXT NOT NULL,
            algorithm_version TEXT NOT NULL,
            reason_codes_json JSON NOT NULL,
            indicator_details_json JSON NOT NULL,
            trend_diagnostics_json JSON NOT NULL,
            created_at DATETIME NOT NULL,
            UNIQUE(asset_id, component, capture_id)
        )
        """
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS ix_rul_estimates_asset_time ON rul_estimates(asset_id,timestamp)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS ix_rul_estimates_component_status ON rul_estimates(component,status)"
    )

    changed_columns: list[str] = []
    if table_exists(connection, "predictions"):
        additions = [
            "capture_id TEXT",
            "prediction_type TEXT",
            "rul_low_hours REAL",
            "rul_high_hours REAL",
            "estimate_quality REAL",
            "status TEXT",
            "algorithm_version TEXT",
            "diagnostics_json JSON",
        ]
        for definition in additions:
            if _add_column(connection, "predictions", definition):
                changed_columns.append(definition.split()[0])
        connection.execute(
            "CREATE INDEX IF NOT EXISTS ix_predictions_asset_component_type ON predictions(asset_id,component,prediction_type)"
        )
    return {
        "rul_tables_ready": True,
        "prediction_columns_added": changed_columns,
    }


# ---------------------------------------------------------------------------
# Temporal filtering, state machine and trend estimation
# ---------------------------------------------------------------------------

STATE_ORDER = {
    "INSUFFICIENT_DATA": -1,
    "HEALTHY": 0,
    "WATCH": 1,
    "WARNING": 2,
    "CRITICAL": 3,
    "FAILURE_LIMIT": 4,
}


def classify_damage(damage: float | None, state_thresholds: Mapping[str, Any]) -> str:
    if damage is None:
        return "INSUFFICIENT_DATA"
    if damage >= 1.0:
        return "FAILURE_LIMIT"
    if damage >= float(state_thresholds.get("critical", 0.65)):
        return "CRITICAL"
    if damage >= float(state_thresholds.get("warning", 0.35)):
        return "WARNING"
    if damage >= float(state_thresholds.get("watch", 0.15)):
        return "WATCH"
    return "HEALTHY"


def update_state_machine(
    connection: sqlite3.Connection,
    *,
    asset_id: str,
    component: str,
    episode_id: str,
    candidate_state: str,
    damage: float | None,
    capture_id: str,
    timestamp: datetime,
    persistence: Mapping[str, Any],
) -> tuple[str, dict[str, int]]:
    row = connection.execute(
        "SELECT episode_id,current_state,worsen_count,recover_count FROM rul_component_state WHERE asset_id=? AND component=?",
        (asset_id, component),
    ).fetchone()
    if row is None or str(row[0]) != episode_id:
        current = "HEALTHY" if candidate_state != "INSUFFICIENT_DATA" else "INSUFFICIENT_DATA"
        worsen_count = recover_count = 0
    else:
        current = str(row[1])
        worsen_count = int(row[2])
        recover_count = int(row[3])

    current_order = STATE_ORDER.get(current, -1)
    candidate_order = STATE_ORDER.get(candidate_state, -1)
    if candidate_state == "FAILURE_LIMIT":
        current = "FAILURE_LIMIT"
        worsen_count = recover_count = 0
    elif candidate_order > current_order:
        worsen_count += 1
        recover_count = 0
        required = int(persistence.get("worsen_windows", 3))
        if worsen_count >= required:
            current = candidate_state
            worsen_count = 0
    elif candidate_order < current_order and candidate_state != "INSUFFICIENT_DATA":
        recover_count += 1
        worsen_count = 0
        required = int(persistence.get("recover_windows", 5))
        if recover_count >= required:
            current = candidate_state
            recover_count = 0
    elif candidate_state == current:
        worsen_count = recover_count = 0

    now = _sqlite_time(datetime.now(timezone.utc))
    connection.execute(
        """
        INSERT INTO rul_component_state(asset_id,component,episode_id,current_state,worsen_count,recover_count,last_damage,last_capture_id,last_timestamp,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(asset_id,component) DO UPDATE SET
          episode_id=excluded.episode_id,current_state=excluded.current_state,
          worsen_count=excluded.worsen_count,recover_count=excluded.recover_count,
          last_damage=excluded.last_damage,last_capture_id=excluded.last_capture_id,
          last_timestamp=excluded.last_timestamp,updated_at=excluded.updated_at
        """,
        (asset_id, component, episode_id, current, worsen_count, recover_count, damage, capture_id, _sqlite_time(timestamp), now),
    )
    return current, {"worsen_count": worsen_count, "recover_count": recover_count}


def _median_filtered(current: float | None, previous_raw: Sequence[float], radius: int) -> float | None:
    if current is None:
        return None
    history_count = max(0, 2 * radius)
    values = (list(previous_raw[-history_count:]) if history_count else []) + [current]
    return float(statistics.median(values))


def _ewma(current: float | None, previous_smoothed: float | None, alpha: float) -> float | None:
    if current is None:
        return previous_smoothed
    if previous_smoothed is None:
        return current
    return float(alpha * current + (1.0 - alpha) * previous_smoothed)


def _pairwise_slopes(times: np.ndarray, values: np.ndarray, max_pairs: int = 20000) -> np.ndarray:
    n = len(values)
    if n < 2:
        return np.empty(0, dtype=float)
    pairs: list[float] = []
    total_pairs = n * (n - 1) // 2
    stride = max(1, int(math.ceil(total_pairs / max_pairs)))
    count = 0
    for i in range(n - 1):
        for j in range(i + 1, n):
            count += 1
            if count % stride:
                continue
            dt = times[j] - times[i]
            if dt > EPS:
                slope = (values[j] - values[i]) / dt
                if math.isfinite(float(slope)):
                    pairs.append(float(slope))
    return np.asarray(pairs, dtype=float)


def _theil_sen_fit(times: np.ndarray, values: np.ndarray) -> dict[str, Any]:
    slopes = _pairwise_slopes(times, values)
    if slopes.size == 0:
        return {"slope": None, "intercept": None, "slopes": slopes, "predicted": np.full_like(values, np.nan)}
    slope = float(np.median(slopes))
    intercept = float(np.median(values - slope * times))
    predicted = intercept + slope * times
    return {"slope": slope, "intercept": intercept, "slopes": slopes, "predicted": predicted}


def _heldout_score(times: np.ndarray, values: np.ndarray, model: str, holdout_fraction: float, violation_penalty: float) -> dict[str, Any]:
    n = len(values)
    holdout = max(1, int(round(n * holdout_fraction)))
    train_n = max(2, n - holdout)
    t_train = times[:train_n]
    y_train = values[:train_n]
    if model == "accelerating":
        transformed = -np.log(np.clip(1.0 - y_train, 1e-6, 1.0))
        fit = _theil_sen_fit(t_train, transformed)
        if fit["slope"] is None:
            return {"valid": False, "score": math.inf}
        prediction_transformed = fit["intercept"] + fit["slope"] * times[train_n:]
        predicted = 1.0 - np.exp(-prediction_transformed)
    else:
        fit = _theil_sen_fit(t_train, y_train)
        if fit["slope"] is None:
            return {"valid": False, "score": math.inf}
        predicted = fit["intercept"] + fit["slope"] * times[train_n:]
    actual = values[train_n:]
    mae = float(np.median(np.abs(actual - predicted))) if actual.size else 0.0
    violations = int(np.sum(np.diff(predicted) < -1e-6)) if predicted.size > 1 else 0
    score = mae + violation_penalty * violations
    return {"valid": True, "score": score, "mae": mae, "violations": violations}


def estimate_trend(
    rows: Sequence[sqlite3.Row | Sequence[Any]],
    *,
    gates: Mapping[str, Any],
    trend_cfg: Mapping[str, Any],
) -> dict[str, Any]:
    if not rows:
        return {"available": False, "reason": "no_history"}
    timestamps = [_parse_timestamp(row[0]) for row in rows]
    damages = np.asarray([float(row[1]) for row in rows], dtype=float)
    origin = timestamps[0]
    times = np.asarray([(ts - origin).total_seconds() / 3600.0 for ts in timestamps], dtype=float)
    observed_hours = float(times[-1] - times[0]) if len(times) > 1 else 0.0
    diffs = np.diff(damages)
    monotonicity = float(np.mean(diffs >= -float(trend_cfg.get("monotonicity_tolerance", 0.01)))) if diffs.size else 0.0

    linear_fit = _theil_sen_fit(times, damages)
    transformed = -np.log(np.clip(1.0 - damages, 1e-6, 1.0))
    accelerating_fit = _theil_sen_fit(times, transformed)
    holdout = float(trend_cfg.get("holdout_fraction", 0.2))
    penalty = float(trend_cfg.get("monotonicity_violation_penalty", 0.05))
    linear_score = _heldout_score(times, damages, "linear", holdout, penalty)
    accelerating_score = _heldout_score(times, damages, "accelerating", holdout, penalty)
    selected = "linear" if linear_score.get("score", math.inf) <= accelerating_score.get("score", math.inf) else "accelerating"
    fit = linear_fit if selected == "linear" else accelerating_fit
    slope = fit.get("slope")
    raw_slopes = fit.get("slopes")
    slopes = np.asarray(raw_slopes if raw_slopes is not None else [], dtype=float)
    positive = slopes[slopes > float(gates.get("minimum_positive_slope_per_hour", 1e-8))]
    fit_error = float(linear_score.get("mae", 0.0) if selected == "linear" else accelerating_score.get("mae", 0.0))

    return {
        "available": slope is not None,
        "timestamps": timestamps,
        "times_hours": times,
        "damage_values": damages,
        "observed_history_hours": observed_hours,
        "monotonicity_ratio": monotonicity,
        "model": selected,
        "slope": slope,
        "intercept": fit.get("intercept"),
        "positive_slope_count": int(positive.size),
        "slope_quantiles": {
            "q10": float(np.quantile(positive, 0.10)) if positive.size else None,
            "q50": float(np.quantile(positive, 0.50)) if positive.size else None,
            "q90": float(np.quantile(positive, 0.90)) if positive.size else None,
        },
        "fit_error": fit_error,
        "candidate_scores": {"linear": linear_score, "accelerating": accelerating_score},
    }


def _time_to_level(current_damage: float, level: float, model: str, slope: float | None) -> float | None:
    if slope is None or slope <= EPS:
        return None
    if current_damage >= level:
        return 0.0
    if model == "accelerating":
        current_y = -math.log(max(1.0 - min(current_damage, 0.999999), 1e-6))
        target_y = -math.log(max(1.0 - min(level, 0.999999), 1e-6))
        return max(0.0, (target_y - current_y) / slope)
    return max(0.0, (level - current_damage) / slope)


def _rul_bounds(current_damage: float, model: str, quantiles: Mapping[str, Any], terminal_damage: float) -> tuple[float | None, float | None, float | None]:
    q10 = _finite(quantiles.get("q10"))
    q50 = _finite(quantiles.get("q50"))
    q90 = _finite(quantiles.get("q90"))
    low = _time_to_level(current_damage, terminal_damage, model, q90)
    median = _time_to_level(current_damage, terminal_damage, model, q50)
    high = _time_to_level(current_damage, terminal_damage, model, q10)
    return low, median, high


# ---------------------------------------------------------------------------
# Quality and persistence
# ---------------------------------------------------------------------------

def resolve_episode_id(metadata: Mapping[str, Any], asset_id: str, component: str | None = None) -> str:
    rul_meta = metadata.get("rul") or metadata.get("prognostics") or {}
    if isinstance(rul_meta, Mapping):
        component_map = rul_meta.get("component_episode_ids") or {}
        if component and isinstance(component_map, Mapping) and component_map.get(component):
            return str(component_map[component])
        if rul_meta.get("episode_id"):
            return str(rul_meta["episode_id"])
    if metadata.get("component_episode_id"):
        return str(metadata["component_episode_id"])
    maintenance = metadata.get("last_maintenance") or metadata.get("maintenance_reset_at") or "initial"
    return _stable_id("episode", asset_id, component or "asset", maintenance, length=20)


def data_quality_score(data_quality: Mapping[str, Any], vibration_report: Mapping[str, Any]) -> float:
    terms: list[float] = []
    terms.append(1.0 if data_quality.get("required_current_channels_present") else 0.0)
    terms.append(1.0 if data_quality.get("current_channels_equal_length") else 0.0)
    excel_presence = _finite(data_quality.get("excel_feature_presence_pct"))
    if excel_presence is not None:
        terms.append(_clip(excel_presence / 100.0))
    vibration_status = str((vibration_report.get("summary") or {}).get("status") or "").upper()
    vibration_channels = int((vibration_report.get("summary") or {}).get("vibration_channel_count") or 0)
    if vibration_status not in {"DISABLED", "NO_VIBRATION_CHANNELS", "NOT_PROVIDED"}:
        terms.append(1.0 if vibration_channels > 0 else 0.0)
    return statistics.fmean(terms) if terms else 0.0


def _quality_score(
    *,
    data_quality: float,
    coverage_pct: float,
    trend: Mapping[str, Any],
    threshold_reliability: float,
    history_count: int,
    minimum_history: int,
) -> float:
    coverage = _clip(coverage_pct / 100.0)
    monotonicity = _clip(_finite(trend.get("monotonicity_ratio"), 0.0) or 0.0)
    fit_error = max(0.0, _finite(trend.get("fit_error"), 1.0) or 1.0)
    fit_quality = 1.0 / (1.0 + 10.0 * fit_error)
    trend_quality = 0.65 * monotonicity + 0.35 * fit_quality
    history_quality = _clip(history_count / max(minimum_history, 1))
    terms = [data_quality, coverage, trend_quality, threshold_reliability, history_quality]
    # Geometric mean strongly penalizes one weak prerequisite.
    product = 1.0
    for term in terms:
        product *= max(_clip(term), 1e-6)
    return float(product ** (1.0 / len(terms)))


def _risk_from_state(state: str) -> str:
    return {
        "HEALTHY": "low",
        "WATCH": "medium",
        "WARNING": "high",
        "CRITICAL": "critical",
        "FAILURE_LIMIT": "critical",
        "INSUFFICIENT_DATA": "low",
    }.get(state, "low")


def _persist_prediction(
    connection: sqlite3.Connection,
    *,
    estimate: Mapping[str, Any],
    asset_id: str,
    capture_id: str,
    timestamp: datetime,
    recommended_action: str,
) -> bool:
    if not estimate.get("rul_available"):
        return False
    component = str(estimate["component"])
    prediction_id = _stable_id("pred-rul", asset_id, component, length=22)
    reason = (
        f"Rule-based {estimate.get('trend_model')} threshold-crossing estimate; "
        f"damage={float(estimate.get('damage_index') or 0.0):.4f}, "
        f"slope={float(estimate.get('degradation_rate_per_hour') or 0.0):.6g}/h."
    )
    feature_importance = {
        row.get("name"): {
            "weight": row.get("weight"),
            "damage_score": row.get("damage_score"),
            "value": row.get("raw_value"),
        }
        for row in estimate.get("indicator_results") or []
        if row.get("available")
    }
    decision_path = list(estimate.get("reason_codes") or [])
    connection.execute(
        """
        INSERT INTO predictions(
          id,asset_id,component,rul,rul_units,confidence,risk,reason,
          recommended_action,model_version,timestamp,acknowledged,
          acknowledged_note,feature_importance,shap_values,decision_path,
          similar_cases,capture_id,prediction_type,rul_low_hours,rul_high_hours,
          estimate_quality,status,algorithm_version,diagnostics_json
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(id) DO UPDATE SET
          rul=excluded.rul,confidence=excluded.confidence,risk=excluded.risk,
          reason=excluded.reason,recommended_action=excluded.recommended_action,
          model_version=excluded.model_version,timestamp=excluded.timestamp,
          feature_importance=excluded.feature_importance,decision_path=excluded.decision_path,
          capture_id=excluded.capture_id,prediction_type=excluded.prediction_type,
          rul_low_hours=excluded.rul_low_hours,rul_high_hours=excluded.rul_high_hours,
          estimate_quality=excluded.estimate_quality,status=excluded.status,
          algorithm_version=excluded.algorithm_version,diagnostics_json=excluded.diagnostics_json
        """,
        (
            prediction_id, asset_id, component, float(estimate["rul_median_hours"]), "hours",
            float(estimate["estimate_quality"]), _risk_from_state(str(estimate["state"])), reason,
            recommended_action, ALGORITHM_VERSION, _sqlite_time(timestamp), 0, None,
            _dumps(feature_importance), _dumps({}), _dumps(decision_path), _dumps([]),
            capture_id, "rule_based_rul", estimate.get("rul_low_hours"), estimate.get("rul_high_hours"),
            estimate.get("estimate_quality"), estimate.get("status"), ALGORITHM_VERSION,
            _dumps(estimate.get("trend_diagnostics") or {}),
        ),
    )
    return True


def persist_rule_based_rul(
    connection: sqlite3.Connection,
    *,
    asset_id: str,
    capture_id: str,
    timestamp: datetime,
    operating_regime: str,
    metadata: Mapping[str, Any],
    canonical_features: Mapping[str, Any],
    current_report: Mapping[str, Any],
    vibration_report: Mapping[str, Any],
    energy_report: Mapping[str, Any],
    data_quality: Mapping[str, Any],
    config: Mapping[str, Any],
    baseline: Mapping[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, int]]:
    """Calculate and persist one deterministic RUL update inside an open transaction."""
    validate_config(config)
    ensure_rul_schema(connection)
    timestamp = _parse_timestamp(timestamp)
    timestamp_db = _sqlite_time(timestamp)
    asset_episode_id = resolve_episode_id(metadata, asset_id)
    catalog = build_source_catalog(
        canonical_features=canonical_features,
        current_report=current_report,
        vibration_report=vibration_report,
        energy_report=energy_report,
        metadata=metadata,
    )
    fusion_power = float((config.get("damage_fusion") or {}).get("power", 4.0))
    smoothing = config.get("smoothing") or {}
    state_thresholds = config.get("state_thresholds") or {}
    persistence = config.get("persistence") or {}
    gates = config.get("gates") or {}
    trend_cfg = config.get("trend") or {}
    minimum_history = int(gates.get("minimum_history_windows", 30))
    minimum_span = float(gates.get("minimum_history_hours", 0.25))
    minimum_coverage = float(gates.get("minimum_feature_coverage_pct", 80.0))
    minimum_monotonicity = float(gates.get("minimum_monotonicity_ratio", 0.65))
    minimum_quality = float(gates.get("minimum_estimate_quality", 0.40))
    maximum_forecast_multiple = float(gates.get("maximum_forecast_multiple", 5.0))
    terminal_damage = float(trend_cfg.get("terminal_damage", 0.99))
    allow_proxy_rul = bool(config.get("allow_proxy_rul", False))
    quality_data = data_quality_score(data_quality, vibration_report)
    profile_version = str((baseline or {}).get("profile_version") or "none")
    config_version = str(config.get("config_version") or ALGORITHM_VERSION)

    write_stats = {
        "history_upserted": 0,
        "state_upserted": 0,
        "estimates_upserted": 0,
        "predictions_upserted": 0,
        "asset_rul_updated": 0,
    }
    component_results: list[dict[str, Any]] = []

    for component_cfg in config["components"]:
        damage = component_damage(component_cfg, catalog=catalog, baseline=baseline, power=fusion_power)
        component = str(damage["component"])
        episode_id = resolve_episode_id(metadata, asset_id, component)
        existing_capture_row = connection.execute(
            "SELECT state FROM rul_indicator_history WHERE asset_id=? AND component=? AND capture_id=?",
            (asset_id, component, capture_id),
        ).fetchone()
        previous_rows = connection.execute(
            """
            SELECT damage_index_raw,damage_index_smoothed FROM rul_indicator_history
             WHERE asset_id=? AND component=? AND episode_id=? AND operating_regime=?
               AND capture_id<>?
             ORDER BY timestamp DESC LIMIT ?
            """,
            (asset_id, component, episode_id, operating_regime, capture_id,
             max(5, int(smoothing.get("median_radius", 2)) * 2 + 2)),
        ).fetchall()
        previous_raw = [float(row[0]) for row in reversed(previous_rows) if row[0] is not None]
        previous_smoothed = float(previous_rows[0][1]) if previous_rows and previous_rows[0][1] is not None else None
        filtered = _median_filtered(damage["damage_index_raw"], previous_raw, int(smoothing.get("median_radius", 2)))
        smoothed = _ewma(filtered, previous_smoothed, float(smoothing.get("ewma_alpha", 0.2)))
        candidate_state = classify_damage(smoothed, state_thresholds)
        if existing_capture_row is not None:
            state = str(existing_capture_row[0])
            state_row = connection.execute(
                "SELECT worsen_count,recover_count FROM rul_component_state WHERE asset_id=? AND component=?",
                (asset_id, component),
            ).fetchone()
            persistence_counts = {
                "worsen_count": int(state_row[0]) if state_row else 0,
                "recover_count": int(state_row[1]) if state_row else 0,
            }
        else:
            state, persistence_counts = update_state_machine(
                connection,
                asset_id=asset_id,
                component=component,
                episode_id=episode_id,
                candidate_state=candidate_state,
                damage=smoothed,
                capture_id=capture_id,
                timestamp=timestamp,
                persistence=persistence,
            )
            write_stats["state_upserted"] += 1

        initial_reasons: list[str] = []
        if damage["feature_coverage_pct"] < minimum_coverage:
            initial_reasons.append("INSUFFICIENT_FEATURE_COVERAGE")
        if damage["damage_index_raw"] is None:
            initial_reasons.append("NO_VALID_COMPONENT_INDICATORS")

        history_id = _stable_id("rulh", asset_id, component, capture_id, length=26)
        connection.execute(
            """
            INSERT INTO rul_indicator_history(
              id,asset_id,component,capture_id,episode_id,timestamp,operating_regime,
              damage_index_raw,damage_index_filtered,damage_index_smoothed,state,
              feature_coverage_pct,valid_feature_count,expected_feature_count,
              data_quality_score,threshold_kind,threshold_reliability,
              indicator_values_json,reason_codes_json,algorithm_version,created_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(asset_id,component,capture_id) DO UPDATE SET
              episode_id=excluded.episode_id,timestamp=excluded.timestamp,
              operating_regime=excluded.operating_regime,damage_index_raw=excluded.damage_index_raw,
              damage_index_filtered=excluded.damage_index_filtered,
              damage_index_smoothed=excluded.damage_index_smoothed,state=excluded.state,
              feature_coverage_pct=excluded.feature_coverage_pct,
              valid_feature_count=excluded.valid_feature_count,
              expected_feature_count=excluded.expected_feature_count,
              data_quality_score=excluded.data_quality_score,
              threshold_kind=excluded.threshold_kind,
              threshold_reliability=excluded.threshold_reliability,
              indicator_values_json=excluded.indicator_values_json,
              reason_codes_json=excluded.reason_codes_json,
              algorithm_version=excluded.algorithm_version
            """,
            (
                history_id, asset_id, component, capture_id, episode_id, timestamp_db,
                operating_regime, damage["damage_index_raw"], filtered, smoothed, state,
                damage["feature_coverage_pct"], damage["valid_feature_count"],
                damage["expected_feature_count"], quality_data, damage["threshold_kind"],
                damage["threshold_reliability"], _dumps(damage["indicator_results"]),
                _dumps(initial_reasons), ALGORITHM_VERSION,
                _sqlite_time(datetime.now(timezone.utc)),
            ),
        )
        write_stats["history_upserted"] += 1

        history_rows = connection.execute(
            """
            SELECT timestamp,damage_index_smoothed FROM rul_indicator_history
             WHERE asset_id=? AND component=? AND episode_id=? AND operating_regime=?
               AND damage_index_smoothed IS NOT NULL
             ORDER BY timestamp ASC
            """,
            (asset_id, component, episode_id, operating_regime),
        ).fetchall()
        trend = estimate_trend(history_rows, gates=gates, trend_cfg=trend_cfg)
        history_count = len(history_rows)
        reasons = list(initial_reasons)
        threshold_kind = str(damage["threshold_kind"])
        if threshold_kind != "validated_failure" and not allow_proxy_rul:
            reasons.append("FAILURE_THRESHOLD_NOT_VALIDATED")
        if history_count < minimum_history:
            reasons.append("INSUFFICIENT_HISTORY_WINDOWS")
        observed_hours = _finite(trend.get("observed_history_hours"), 0.0) or 0.0
        if observed_hours < minimum_span:
            reasons.append("INSUFFICIENT_HISTORY_DURATION")
        slope = _finite(trend.get("slope"))
        if slope is None or slope <= float(gates.get("minimum_positive_slope_per_hour", 1e-8)):
            reasons.append("NO_POSITIVE_DEGRADATION_TREND")
        monotonicity = _finite(trend.get("monotonicity_ratio"), 0.0) or 0.0
        if monotonicity < minimum_monotonicity:
            reasons.append("UNSTABLE_OR_NON_MONOTONIC_TREND")

        current_damage = _finite(smoothed)
        trend_model = str(trend.get("model") or "none")
        quantiles = trend.get("slope_quantiles") or {}
        rul_low = rul_median = rul_high = None
        advisory = None
        time_warning = time_critical = None
        if current_damage is not None and trend.get("available"):
            rul_low, rul_median, rul_high = _rul_bounds(current_damage, trend_model, quantiles, terminal_damage)
            advisory = rul_median
            q50 = _finite(quantiles.get("q50"))
            time_warning = _time_to_level(current_damage, float(state_thresholds.get("warning", 0.35)), trend_model, q50)
            time_critical = _time_to_level(current_damage, float(state_thresholds.get("critical", 0.65)), trend_model, q50)

        quality = _quality_score(
            data_quality=quality_data,
            coverage_pct=float(damage["feature_coverage_pct"]),
            trend=trend,
            threshold_reliability=float(damage["threshold_reliability"]),
            history_count=history_count,
            minimum_history=minimum_history,
        )
        if quality < minimum_quality:
            reasons.append("ESTIMATE_QUALITY_BELOW_MINIMUM")
        if rul_median is not None and observed_hours > 0 and rul_median > maximum_forecast_multiple * observed_hours:
            reasons.append("EXTRAPOLATION_TOO_FAR")

        if state == "FAILURE_LIMIT":
            rul_low = rul_median = rul_high = 0.0
            reasons = [reason for reason in reasons if reason not in {"NO_POSITIVE_DEGRADATION_TREND", "INSUFFICIENT_HISTORY_DURATION", "INSUFFICIENT_HISTORY_WINDOWS"}]

        blocking = {
            "INSUFFICIENT_FEATURE_COVERAGE", "NO_VALID_COMPONENT_INDICATORS",
            "FAILURE_THRESHOLD_NOT_VALIDATED", "INSUFFICIENT_HISTORY_WINDOWS",
            "INSUFFICIENT_HISTORY_DURATION", "NO_POSITIVE_DEGRADATION_TREND",
            "UNSTABLE_OR_NON_MONOTONIC_TREND", "ESTIMATE_QUALITY_BELOW_MINIMUM",
            "EXTRAPOLATION_TOO_FAR",
        }
        rul_available = state == "FAILURE_LIMIT" or not any(reason in blocking for reason in reasons)
        status = "AVAILABLE" if rul_available else "UNAVAILABLE"
        if state == "FAILURE_LIMIT":
            status = "FAILURE_LIMIT_REACHED"

        estimate = {
            "component": component,
            "display_name": damage["display_name"],
            "capture_id": capture_id,
            "episode_id": episode_id,
            "timestamp": timestamp,
            "operating_regime": operating_regime,
            "status": status,
            "state": state,
            "candidate_state": candidate_state,
            "rul_available": bool(rul_available),
            "damage_index_raw": damage["damage_index_raw"],
            "damage_index_filtered": filtered,
            "damage_index": smoothed,
            "degradation_rate_per_hour": slope,
            "trend_model": trend_model if trend.get("available") else None,
            "rul_low_hours": rul_low if rul_available else None,
            "rul_median_hours": rul_median if rul_available else None,
            "rul_high_hours": rul_high if rul_available else None,
            "time_to_warning_hours": time_warning,
            "time_to_critical_hours": time_critical,
            "time_to_failure_advisory_hours": advisory,
            "estimate_quality": quality,
            "data_quality_score": quality_data,
            "feature_coverage_pct": damage["feature_coverage_pct"],
            "valid_feature_count": damage["valid_feature_count"],
            "expected_feature_count": damage["expected_feature_count"],
            "monotonicity_ratio": monotonicity,
            "fit_error": trend.get("fit_error"),
            "history_window_count": history_count,
            "observed_history_hours": observed_hours,
            "threshold_kind": threshold_kind,
            "threshold_reliability": damage["threshold_reliability"],
            "healthy_profile_version": profile_version,
            "threshold_config_version": config_version,
            "algorithm_name": ALGORITHM_NAME,
            "algorithm_version": ALGORITHM_VERSION,
            "reason_codes": sorted(set(reasons)),
            "indicator_results": damage["indicator_results"],
            "trend_diagnostics": {
                "model": trend_model,
                "slope_quantiles": trend.get("slope_quantiles"),
                "candidate_scores": trend.get("candidate_scores"),
                "persistence": persistence_counts,
                "maximum_forecast_multiple": maximum_forecast_multiple,
                "terminal_damage": terminal_damage,
            },
            "recommended_action": damage["recommended_action"],
        }

        estimate_id = _stable_id("rule-rul", asset_id, component, capture_id, length=25)
        connection.execute(
            """
            INSERT INTO rul_estimates(
              id,asset_id,component,capture_id,episode_id,timestamp,operating_regime,
              status,state,rul_available,damage_index,degradation_rate_per_hour,
              trend_model,rul_low_hours,rul_median_hours,rul_high_hours,
              time_to_warning_hours,time_to_critical_hours,time_to_failure_advisory_hours,
              estimate_quality,data_quality_score,feature_coverage_pct,monotonicity_ratio,
              fit_error,history_window_count,observed_history_hours,threshold_kind,
              threshold_reliability,healthy_profile_version,threshold_config_version,
              algorithm_name,algorithm_version,reason_codes_json,indicator_details_json,
              trend_diagnostics_json,created_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(asset_id,component,capture_id) DO UPDATE SET
              episode_id=excluded.episode_id,timestamp=excluded.timestamp,
              operating_regime=excluded.operating_regime,status=excluded.status,
              state=excluded.state,rul_available=excluded.rul_available,
              damage_index=excluded.damage_index,
              degradation_rate_per_hour=excluded.degradation_rate_per_hour,
              trend_model=excluded.trend_model,rul_low_hours=excluded.rul_low_hours,
              rul_median_hours=excluded.rul_median_hours,rul_high_hours=excluded.rul_high_hours,
              time_to_warning_hours=excluded.time_to_warning_hours,
              time_to_critical_hours=excluded.time_to_critical_hours,
              time_to_failure_advisory_hours=excluded.time_to_failure_advisory_hours,
              estimate_quality=excluded.estimate_quality,
              data_quality_score=excluded.data_quality_score,
              feature_coverage_pct=excluded.feature_coverage_pct,
              monotonicity_ratio=excluded.monotonicity_ratio,fit_error=excluded.fit_error,
              history_window_count=excluded.history_window_count,
              observed_history_hours=excluded.observed_history_hours,
              threshold_kind=excluded.threshold_kind,
              threshold_reliability=excluded.threshold_reliability,
              healthy_profile_version=excluded.healthy_profile_version,
              threshold_config_version=excluded.threshold_config_version,
              algorithm_name=excluded.algorithm_name,algorithm_version=excluded.algorithm_version,
              reason_codes_json=excluded.reason_codes_json,
              indicator_details_json=excluded.indicator_details_json,
              trend_diagnostics_json=excluded.trend_diagnostics_json
            """,
            (
                estimate_id, asset_id, component, capture_id, episode_id, timestamp_db,
                operating_regime, status, state, int(rul_available), smoothed, slope,
                estimate.get("trend_model"), estimate.get("rul_low_hours"),
                estimate.get("rul_median_hours"), estimate.get("rul_high_hours"),
                time_warning, time_critical, advisory, quality, quality_data,
                damage["feature_coverage_pct"], monotonicity, trend.get("fit_error"),
                history_count, observed_hours, threshold_kind,
                damage["threshold_reliability"], profile_version, config_version,
                ALGORITHM_NAME, ALGORITHM_VERSION, _dumps(estimate["reason_codes"]),
                _dumps(damage["indicator_results"]), _dumps(estimate["trend_diagnostics"]),
                _sqlite_time(datetime.now(timezone.utc)),
            ),
        )
        write_stats["estimates_upserted"] += 1
        if _persist_prediction(
            connection,
            estimate=estimate,
            asset_id=asset_id,
            capture_id=capture_id,
            timestamp=timestamp,
            recommended_action=str(damage["recommended_action"]),
        ):
            write_stats["predictions_upserted"] += 1
        else:
            # Remove stale legacy summaries when the newest component estimate
            # fails the RUL validity gates. Full unavailable history remains in
            # rul_estimates with explicit reason codes.
            connection.execute(
                "DELETE FROM predictions WHERE id=?",
                (_stable_id("pred-rul", asset_id, component, length=22),),
            )
        component_results.append(estimate)

    available = [row for row in component_results if row.get("rul_available") and row.get("rul_median_hours") is not None]
    limiting = min(available, key=lambda row: float(row["rul_median_hours"])) if available else None
    if limiting:
        connection.execute("UPDATE assets SET rul=? WHERE id=?", (max(0, int(round(float(limiting["rul_median_hours"])))), asset_id))
    else:
        # Clear stale values rather than presenting an old estimate after the
        # current validity gates fail.
        connection.execute("UPDATE assets SET rul=NULL WHERE id=?", (asset_id,))
    write_stats["asset_rul_updated"] += 1

    report = {
        "schema_version": SCHEMA_VERSION,
        "algorithm": ALGORITHM_NAME,
        "algorithm_version": ALGORITHM_VERSION,
        "generated_at": timestamp,
        "asset_id": asset_id,
        "capture_id": capture_id,
        "episode_id": asset_episode_id,
        "episode_ids": {row["component"]: row["episode_id"] for row in component_results},
        "operating_regime": operating_regime,
        "summary": {
            "component_count": len(component_results),
            "available_component_count": len(available),
            "asset_rul_available": limiting is not None,
            "asset_rul_low_hours": limiting.get("rul_low_hours") if limiting else None,
            "asset_rul_median_hours": limiting.get("rul_median_hours") if limiting else None,
            "asset_rul_high_hours": limiting.get("rul_high_hours") if limiting else None,
            "limiting_component": limiting.get("component") if limiting else None,
            "estimate_quality": limiting.get("estimate_quality") if limiting else None,
            "semantics": "Deterministic time to validated component failure threshold; estimate_quality is not failure probability.",
        },
        "components": component_results,
        "write_stats": write_stats,
    }
    return report, write_stats


# ---------------------------------------------------------------------------
# Standalone CLI for schema validation / inspection
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Validate the deterministic rule-based RUL configuration or migrate its database schema.")
    sub = parser.add_subparsers(dest="command", required=True)
    validate = sub.add_parser("validate-config")
    validate.add_argument("--config", required=True)
    migrate = sub.add_parser("migrate-db")
    migrate.add_argument("--database", required=True)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "validate-config":
        config = load_config(args.config)
        print(json.dumps({"valid": True, "component_count": len(config["components"]), "algorithm_version": ALGORITHM_VERSION}, indent=2))
        return 0
    connection = sqlite3.connect(Path(args.database).resolve())
    try:
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("BEGIN IMMEDIATE")
        result = ensure_rul_schema(connection)
        connection.commit()
        print(json.dumps(result, indent=2))
        return 0
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


if __name__ == "__main__":
    raise SystemExit(main())
