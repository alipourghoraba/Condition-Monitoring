"""Compatibility adapter for the supplied MCSA extractor.

The original algorithm computes several Excel-required values but does not put
all of them in the exported CSV, and its ordered header list contains three
copy/paste duplicates. This adapter does not change signal-processing formulas;
it only completes and normalizes the output contract after extraction.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path
from typing import Any, Mapping, MutableMapping, Sequence

import numpy as np


EXCEL_RUNTIME_ADDITIONS = (
    "maxim", "fftKurtosis", "fftSkewness", "fftCrest", "fftIMPfac",
    "Idstd", "Iqimpfac",
    "negseqSTD1", "negseqSTD2", "negseqSTD3",
    "negseqMean1", "negseqMean2", "negseqMean3",
    "posseqMean1", "posseqMean2", "posseqMean3",
    "Rmspha", "Rmsphb", "Rmsphc",
)

LEGACY_HEADER_OMISSIONS = ("Stftkurtosisc", "emdcrstfacc")
LEGACY_DUPLICATE_HEADERS = ("emdcrstfacb", "emdska", "Stftkurtosisb")


def _finite(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _put(target: MutableMapping[str, float], name: str, value: Any) -> None:
    number = _finite(value)
    if number is not None:
        target[name] = number


def enrich_runtime_features(
    extracted_features: Mapping[str, Any], runtime: Mapping[str, Any]
) -> dict[str, float]:
    """Return a complete canonical feature dictionary from extractor globals.

    The supplied script leaves the following values in local/global variables:
    FFT descriptors, Id standard deviation, Iq impulse factor, direct sequence
    means/stds, and per-phase RMS. We expose those existing calculations using
    the canonical names required by Feature_List2.xlsx.
    """
    result: dict[str, float] = {}
    for name, value in extracted_features.items():
        _put(result, str(name), value)

    direct = {
        "maxim": "maxim",
        "fftKurtosis": "fftkurtosis",
        "fftSkewness": "fftskewness",
        "fftCrest": "crestfft",
        "fftIMPfac": "fftIMPfac",
        "Idstd": "idstd",
        "Iqimpfac": "iqimpfac",
        "Rmspha": "Rmspha",
        "Rmsphb": "Rmsphb",
        "Rmsphc": "Rmsphc",
    }
    for canonical, source in direct.items():
        if source in runtime:
            _put(result, canonical, runtime[source])

    neg_mag = runtime.get("neg_mag")
    if isinstance(neg_mag, (list, tuple)) and len(neg_mag) >= 3:
        for index in range(3):
            array = np.asarray(neg_mag[index])
            _put(result, f"negseqSTD{index + 1}", np.std(array))
            _put(result, f"negseqMean{index + 1}", np.mean(array))

    pos_mag = runtime.get("pos_mag")
    if isinstance(pos_mag, (list, tuple)) and len(pos_mag) >= 3:
        for index in range(3):
            array = np.asarray(pos_mag[index])
            _put(result, f"posseqMean{index + 1}", np.mean(array))

    return result


def canonical_feature_order(
    features: Mapping[str, Any], runtime: Mapping[str, Any] | None = None
) -> list[str]:
    """Build a stable, unique output order preserving the original contract."""
    runtime = runtime or {}
    original = list(runtime.get("ordered_labels_original", []))
    paper1 = list(runtime.get("new_labels_paper1", []))
    paper2 = list(runtime.get("new_labels_paper2", []))

    order: list[str] = []
    seen: set[str] = set()
    for name in original + list(EXCEL_RUNTIME_ADDITIONS) + list(LEGACY_HEADER_OMISSIONS) + paper1 + paper2:
        if name in features and name not in seen:
            seen.add(name)
            order.append(name)
    for name in sorted(features):
        if name not in seen:
            seen.add(name)
            order.append(name)
    return order


def write_feature_csv(
    features: Mapping[str, Any],
    path: str | Path,
    *,
    order: Sequence[str] | None = None,
) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    names = list(order or sorted(features))
    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(names)
        writer.writerow([features.get(name, "") for name in names])


def runtime_adapter_audit(
    original_features: Mapping[str, Any], enriched_features: Mapping[str, Any]
) -> dict[str, Any]:
    before = set(original_features)
    after = set(enriched_features)
    return {
        "original_feature_dict_count": len(before),
        "canonical_feature_count": len(after),
        "added_by_adapter": sorted(after - before),
        "legacy_header_omissions_recovered": [name for name in LEGACY_HEADER_OMISSIONS if name in after],
        "legacy_duplicate_headers_removed": list(LEGACY_DUPLICATE_HEADERS),
        "signal_processing_changed": False,
        "note": "Only the output contract is completed; feature formulas are unchanged.",
    }


def write_json(data: Mapping[str, Any], path: str | Path) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
