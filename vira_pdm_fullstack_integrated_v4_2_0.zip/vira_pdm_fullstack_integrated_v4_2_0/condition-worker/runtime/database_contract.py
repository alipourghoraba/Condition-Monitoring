"""Normalized database contract for MCSA, health, and pipeline-stage persistence.

This module is deliberately independent from the signal-processing algorithms. It
creates additive SQLite tables, stores every deterministic diagnostic output in a
queryable form, and keeps the legacy dashboard columns synchronized.
"""
from __future__ import annotations

import hashlib
import json
import math
import sqlite3
from datetime import datetime, timezone
from typing import Any, Mapping

SCHEMA_VERSION = "1.0"
CONTRACT_VERSION = "4.1.0"


def _stable_id(prefix: str, *parts: Any, length: int = 28) -> str:
    text = "|".join(str(p) for p in parts)
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()[: max(8, length - len(prefix) - 1)]
    return f"{prefix}-{digest}"


def _finite(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return min(high, max(low, float(value)))


def _dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, allow_nan=False, default=str)


def _sqlite_time(value: datetime | str | None = None) -> str:
    if value is None:
        value = datetime.now(timezone.utc)
    if isinstance(value, str):
        return value.replace("Z", "+00:00")
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).replace(tzinfo=None).isoformat(sep=" ")


def table_exists(connection: sqlite3.Connection, table: str) -> bool:
    return connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
    ).fetchone() is not None


def columns(connection: sqlite3.Connection, table: str) -> set[str]:
    return {str(row[1]) for row in connection.execute(f'PRAGMA table_info("{table}")')}


def _add_column(connection: sqlite3.Connection, table: str, definition: str) -> bool:
    name = definition.split()[0].strip('"')
    if name in columns(connection, table):
        return False
    connection.execute(f'ALTER TABLE "{table}" ADD COLUMN {definition}')
    return True


def ensure_full_diagnostic_schema(connection: sqlite3.Connection) -> dict[str, Any]:
    """Create additive normalized tables and explicit health-score columns."""
    changed: list[str] = []

    if table_exists(connection, "assets"):
        for definition in (
            "health_score REAL",
            "health_method TEXT",
            "health_updated_at DATETIME",
            "health_details_json JSON",
        ):
            if _add_column(connection, "assets", definition):
                changed.append(f"assets.{definition.split()[0]}")
        connection.execute(
            "UPDATE assets SET health_score=COALESCE(health_score, health, 0)"
        )

    if table_exists(connection, "zones"):
        if _add_column(connection, "zones", "health_score REAL"):
            changed.append("zones.health_score")
        connection.execute("UPDATE zones SET health_score=COALESCE(health_score, health, 0)")

    if table_exists(connection, "asset_health_history"):
        additions = (
            "capture_id TEXT",
            "timestamp DATETIME",
            "current_health_score REAL",
            "vibration_health_score REAL",
            "overall_health_score REAL",
            "status TEXT",
            "details_json JSON",
        )
        for definition in additions:
            if _add_column(connection, "asset_health_history", definition):
                changed.append(f"asset_health_history.{definition.split()[0]}")

    connection.executescript(
        """
        CREATE TABLE IF NOT EXISTS mcsa_analysis_runs (
            id TEXT PRIMARY KEY NOT NULL,
            asset_id TEXT NOT NULL REFERENCES assets(id),
            capture_id TEXT NOT NULL,
            timestamp DATETIME NOT NULL,
            sample_rate_hz REAL NOT NULL,
            duration_seconds REAL,
            status TEXT NOT NULL,
            current_health_score REAL,
            maximum_evidence_pct REAL,
            feature_count INTEGER NOT NULL,
            fault_class_count INTEGER NOT NULL,
            active_fault_count INTEGER NOT NULL,
            diagnostic_validity TEXT NOT NULL,
            data_quality_score REAL,
            report_json JSON NOT NULL,
            created_at DATETIME NOT NULL,
            UNIQUE(asset_id, capture_id)
        );

        CREATE TABLE IF NOT EXISTS mcsa_feature_values (
            id TEXT PRIMARY KEY NOT NULL,
            analysis_id TEXT NOT NULL REFERENCES mcsa_analysis_runs(id) ON DELETE CASCADE,
            feature_name TEXT NOT NULL,
            value REAL NOT NULL,
            unit TEXT,
            category TEXT NOT NULL DEFAULT 'mcsa',
            source_method TEXT NOT NULL DEFAULT 'MCSA',
            created_at DATETIME NOT NULL,
            UNIQUE(analysis_id, feature_name)
        );

        CREATE TABLE IF NOT EXISTS mcsa_fault_evidence (
            id TEXT PRIMARY KEY NOT NULL,
            analysis_id TEXT NOT NULL REFERENCES mcsa_analysis_runs(id) ON DELETE CASCADE,
            fault_code TEXT NOT NULL,
            fault_name TEXT NOT NULL,
            severity TEXT NOT NULL,
            evidence_pct REAL,
            coverage_pct REAL,
            triggered_feature_count INTEGER,
            eligible_feature_count INTEGER,
            expected_feature_count INTEGER,
            present_feature_count INTEGER,
            recommended_action TEXT,
            details_json JSON NOT NULL,
            created_at DATETIME NOT NULL,
            UNIQUE(analysis_id, fault_code)
        );

        CREATE TABLE IF NOT EXISTS health_assessments (
            id TEXT PRIMARY KEY NOT NULL,
            asset_id TEXT NOT NULL REFERENCES assets(id),
            capture_id TEXT NOT NULL,
            timestamp DATETIME NOT NULL,
            current_health_score REAL,
            vibration_health_score REAL,
            overall_health_score REAL NOT NULL,
            status TEXT NOT NULL,
            health_method TEXT NOT NULL,
            data_quality_score REAL,
            diagnostic_validity TEXT NOT NULL,
            details_json JSON NOT NULL,
            created_at DATETIME NOT NULL,
            UNIQUE(asset_id, capture_id)
        );

        CREATE TABLE IF NOT EXISTS pipeline_stage_results (
            id TEXT PRIMARY KEY NOT NULL,
            capture_id TEXT NOT NULL,
            asset_id TEXT,
            stage_name TEXT NOT NULL,
            status TEXT NOT NULL,
            row_count INTEGER,
            message TEXT,
            details_json JSON NOT NULL,
            created_at DATETIME NOT NULL,
            UNIQUE(capture_id, stage_name)
        );

        CREATE INDEX IF NOT EXISTS ix_mcsa_analysis_asset_time
            ON mcsa_analysis_runs(asset_id, timestamp);
        CREATE INDEX IF NOT EXISTS ix_mcsa_analysis_capture
            ON mcsa_analysis_runs(capture_id);
        CREATE INDEX IF NOT EXISTS ix_mcsa_features_analysis
            ON mcsa_feature_values(analysis_id);
        CREATE INDEX IF NOT EXISTS ix_mcsa_fault_analysis
            ON mcsa_fault_evidence(analysis_id);
        CREATE INDEX IF NOT EXISTS ix_mcsa_fault_code
            ON mcsa_fault_evidence(fault_code, severity);
        CREATE INDEX IF NOT EXISTS ix_health_assessment_asset_time
            ON health_assessments(asset_id, timestamp);
        CREATE INDEX IF NOT EXISTS ix_health_assessment_capture
            ON health_assessments(capture_id);
        CREATE INDEX IF NOT EXISTS ix_pipeline_stage_capture
            ON pipeline_stage_results(capture_id, stage_name);
        """
    )

    return {
        "schema_version": SCHEMA_VERSION,
        "contract_version": CONTRACT_VERSION,
        "changed_columns": changed,
        "mcsa_schema_ready": True,
        "health_schema_ready": True,
        "pipeline_stage_schema_ready": True,
    }




def calculate_data_quality_score(data_quality: Mapping[str, Any]) -> float:
    """Deterministic 0..1 quality score from capture-contract checks."""
    present = 1.0 if data_quality.get("required_current_channels_present") else 0.0
    synchronized = 1.0 if data_quality.get("current_channels_equal_length") else 0.0
    feature_presence = _finite(data_quality.get("excel_feature_presence_pct"))
    feature_score = _clamp(feature_presence or 0.0) / 100.0
    usable = 1.0 if data_quality.get("diagnosis_usable") else 0.0
    return round(0.30 * present + 0.25 * synchronized + 0.30 * feature_score + 0.15 * usable, 6)

def _feature_category(name: str) -> str:
    lower = name.lower()
    if lower.startswith(("stft", "fft")):
        return "frequency"
    if lower.startswith(("emd", "imf")):
        return "emd"
    if "wave" in lower or lower.startswith(("cd", "rmscd")):
        return "wavelet"
    if "negseq" in lower or "posseq" in lower:
        return "sequence_components"
    if lower.startswith(("id", "iq")):
        return "dq_components"
    if any(token in lower for token in ("rms", "kurt", "skew", "crest", "impulse", "std", "mean")):
        return "statistical"
    return "mcsa"


def _report_status(report: Mapping[str, Any]) -> str:
    severities = {str(row.get("severity") or "").upper() for row in report.get("fault_scores") or [] if isinstance(row, Mapping)}
    if "CRITICAL" in severities:
        return "CRITICAL"
    if "WARNING" in severities:
        return "WARNING"
    if severities and severities <= {"INSUFFICIENT_DATA"}:
        return "INSUFFICIENT_DATA"
    return "HEALTHY"


def persist_mcsa_report(
    connection: sqlite3.Connection,
    *,
    asset_id: str,
    capture_id: str,
    timestamp: datetime,
    sample_rate_hz: float,
    duration_seconds: float | None,
    canonical_features: Mapping[str, Any],
    report: Mapping[str, Any],
    diagnostic_validity: str,
    data_quality_score: float | None,
) -> dict[str, Any]:
    ensure_full_diagnostic_schema(connection)
    created = _sqlite_time()
    analysis_id = _stable_id("mcsa", asset_id, capture_id, length=28)
    summary = report.get("summary") or {}
    current_health = _finite(summary.get("plant_health_index"))
    fault_rows = [row for row in report.get("fault_scores") or [] if isinstance(row, Mapping)]
    evidences = [_finite(row.get("evidence_pct")) for row in fault_rows]
    maximum_evidence = max((value for value in evidences if value is not None), default=None)
    active = sum(str(row.get("severity") or "").upper() in {"WARNING", "CRITICAL"} for row in fault_rows)
    finite_features = {
        str(name): float(value)
        for name, value in canonical_features.items()
        if _finite(value) is not None
    }
    connection.execute(
        """
        INSERT INTO mcsa_analysis_runs(
          id,asset_id,capture_id,timestamp,sample_rate_hz,duration_seconds,status,
          current_health_score,maximum_evidence_pct,feature_count,fault_class_count,
          active_fault_count,diagnostic_validity,data_quality_score,report_json,created_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(asset_id,capture_id) DO UPDATE SET
          timestamp=excluded.timestamp,sample_rate_hz=excluded.sample_rate_hz,
          duration_seconds=excluded.duration_seconds,status=excluded.status,
          current_health_score=excluded.current_health_score,
          maximum_evidence_pct=excluded.maximum_evidence_pct,
          feature_count=excluded.feature_count,fault_class_count=excluded.fault_class_count,
          active_fault_count=excluded.active_fault_count,
          diagnostic_validity=excluded.diagnostic_validity,
          data_quality_score=excluded.data_quality_score,report_json=excluded.report_json
        """,
        (
            analysis_id, asset_id, capture_id, _sqlite_time(timestamp), float(sample_rate_hz),
            duration_seconds, _report_status(report), current_health, maximum_evidence,
            len(finite_features), len(fault_rows), active, diagnostic_validity,
            data_quality_score, _dumps(report), created,
        ),
    )

    feature_count = 0
    for name, value in finite_features.items():
        row_id = _stable_id("mcf", analysis_id, name, length=28)
        connection.execute(
            """
            INSERT INTO mcsa_feature_values(
              id,analysis_id,feature_name,value,unit,category,source_method,created_at
            ) VALUES(?,?,?,?,?,?,?,?)
            ON CONFLICT(analysis_id,feature_name) DO UPDATE SET
              value=excluded.value,category=excluded.category,source_method=excluded.source_method
            """,
            (row_id, analysis_id, name, value, None, _feature_category(name), "MCSA", created),
        )
        feature_count += 1

    fault_count = 0
    for index, item in enumerate(fault_rows):
        code = str(item.get("fault_code") or f"MCSA-UNKNOWN-{index}")
        row_id = _stable_id("mce", analysis_id, code, length=28)
        connection.execute(
            """
            INSERT INTO mcsa_fault_evidence(
              id,analysis_id,fault_code,fault_name,severity,evidence_pct,coverage_pct,
              triggered_feature_count,eligible_feature_count,expected_feature_count,
              present_feature_count,recommended_action,details_json,created_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(analysis_id,fault_code) DO UPDATE SET
              fault_name=excluded.fault_name,severity=excluded.severity,
              evidence_pct=excluded.evidence_pct,coverage_pct=excluded.coverage_pct,
              triggered_feature_count=excluded.triggered_feature_count,
              eligible_feature_count=excluded.eligible_feature_count,
              expected_feature_count=excluded.expected_feature_count,
              present_feature_count=excluded.present_feature_count,
              recommended_action=excluded.recommended_action,details_json=excluded.details_json
            """,
            (
                row_id, analysis_id, code, str(item.get("fault_name") or code),
                str(item.get("severity") or "UNKNOWN").upper(), _finite(item.get("evidence_pct")),
                _finite(item.get("coverage_pct")), item.get("triggered_feature_count"),
                item.get("eligible_feature_count"), item.get("expected_feature_count"),
                item.get("present_feature_count"), item.get("recommended_action"),
                _dumps(item), created,
            ),
        )
        fault_count += 1

    return {
        "analysis_id": analysis_id,
        "analysis_upserted": 1,
        "features_upserted": feature_count,
        "fault_evidence_upserted": fault_count,
        "current_health_score": current_health,
        "status": _report_status(report),
    }


def derive_health_scores(
    *,
    current_report: Mapping[str, Any],
    vibration_report: Mapping[str, Any],
    data_quality_score: float | None,
    diagnostic_validity: str,
) -> dict[str, Any]:
    current = _finite((current_report.get("summary") or {}).get("plant_health_index"))
    vibration = _finite((vibration_report.get("summary") or {}).get("health_index"))

    if current is None:
        values = [_finite(row.get("evidence_pct")) for row in current_report.get("fault_scores") or [] if isinstance(row, Mapping)]
        valid = [value for value in values if value is not None]
        current = 100.0 - max(valid) if valid else None

    if vibration is None:
        values = [_finite(row.get("evidence_score")) for row in vibration_report.get("fault_scores") or [] if isinstance(row, Mapping)]
        valid = [value for value in values if value is not None]
        vibration = 100.0 * (1.0 - max(valid)) if valid else None

    if current is not None:
        current = _clamp(current)
    if vibration is not None:
        vibration = _clamp(vibration)

    available = [value for value in (current, vibration) if value is not None]
    overall = min(available) if available else 0.0
    method = "conservative_minimum_of_available_modalities"
    status = "healthy" if overall >= 80 else "warning" if overall >= 50 else "critical"
    if not available:
        status = "unknown"
        method = "unavailable_default_zero"

    return {
        "current_health_score": current,
        "vibration_health_score": vibration,
        "overall_health_score": _clamp(overall),
        "status": status,
        "health_method": method,
        "data_quality_score": data_quality_score,
        "diagnostic_validity": diagnostic_validity,
        "semantics": "0=worst, 100=best. Overall score is the conservative minimum of available modality scores.",
    }


def persist_health_assessment(
    connection: sqlite3.Connection,
    *,
    asset_id: str,
    plant_id: str,
    zone_id: str,
    capture_id: str,
    timestamp: datetime,
    assessment: Mapping[str, Any],
) -> dict[str, Any]:
    ensure_full_diagnostic_schema(connection)
    overall = _clamp(float(assessment.get("overall_health_score") or 0.0))
    current = _finite(assessment.get("current_health_score"))
    vibration = _finite(assessment.get("vibration_health_score"))
    status = str(assessment.get("status") or "unknown")
    method = str(assessment.get("health_method") or "unknown")
    created = _sqlite_time()
    row_id = _stable_id("health", asset_id, capture_id, length=28)
    connection.execute(
        """
        INSERT INTO health_assessments(
          id,asset_id,capture_id,timestamp,current_health_score,vibration_health_score,
          overall_health_score,status,health_method,data_quality_score,
          diagnostic_validity,details_json,created_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(asset_id,capture_id) DO UPDATE SET
          timestamp=excluded.timestamp,current_health_score=excluded.current_health_score,
          vibration_health_score=excluded.vibration_health_score,
          overall_health_score=excluded.overall_health_score,status=excluded.status,
          health_method=excluded.health_method,data_quality_score=excluded.data_quality_score,
          diagnostic_validity=excluded.diagnostic_validity,details_json=excluded.details_json
        """,
        (
            row_id, asset_id, capture_id, _sqlite_time(timestamp), current, vibration,
            overall, status, method, _finite(assessment.get("data_quality_score")),
            str(assessment.get("diagnostic_validity") or "UNKNOWN"), _dumps(assessment), created,
        ),
    )

    asset_cols = columns(connection, "assets")
    assignments = ["health=?", "status=?"]
    params: list[Any] = [overall, status]
    if "health_score" in asset_cols:
        assignments.append("health_score=?")
        params.append(overall)
    if "health_method" in asset_cols:
        assignments.append("health_method=?")
        params.append(method)
    if "health_updated_at" in asset_cols:
        assignments.append("health_updated_at=?")
        params.append(_sqlite_time(timestamp))
    if "health_details_json" in asset_cols:
        assignments.append("health_details_json=?")
        params.append(_dumps(assessment))
    params.append(asset_id)
    connection.execute(f"UPDATE assets SET {', '.join(assignments)} WHERE id=?", params)

    zone_cols = columns(connection, "zones")
    zone_score = connection.execute(
        "SELECT AVG(COALESCE(health_score,health)) FROM assets WHERE zone_id=? AND status!='offline'",
        (zone_id,),
    ).fetchone()[0]
    if zone_score is not None:
        if "health_score" in zone_cols:
            connection.execute("UPDATE zones SET health=?,health_score=? WHERE id=?", (zone_score, zone_score, zone_id))
        else:
            connection.execute("UPDATE zones SET health=? WHERE id=?", (zone_score, zone_id))

    plant_score = connection.execute(
        "SELECT AVG(COALESCE(health_score,health)) FROM assets WHERE plant_id=? AND status!='offline'",
        (plant_id,),
    ).fetchone()[0]
    if plant_score is not None:
        connection.execute("UPDATE plants SET health_score=? WHERE id=?", (plant_score, plant_id))

    history_cols = columns(connection, "asset_health_history")
    day = _sqlite_time(timestamp)[:10]
    history_id = _stable_id("hh", asset_id, day, length=24)
    existing = connection.execute(
        "SELECT id FROM asset_health_history WHERE asset_id=? AND date=? ORDER BY id LIMIT 1",
        (asset_id, day),
    ).fetchone()
    if existing:
        assignments = ["health=?"]
        params = [overall]
        optional_values = {
            "capture_id": capture_id,
            "timestamp": _sqlite_time(timestamp),
            "current_health_score": current,
            "vibration_health_score": vibration,
            "overall_health_score": overall,
            "status": status,
            "details_json": _dumps(assessment),
        }
        for key, value in optional_values.items():
            if key in history_cols:
                assignments.append(f"{key}=?")
                params.append(value)
        params.append(existing[0])
        connection.execute(f"UPDATE asset_health_history SET {', '.join(assignments)} WHERE id=?", params)
    else:
        values = {"id": history_id, "asset_id": asset_id, "date": day, "health": overall}
        optional_values = {
            "capture_id": capture_id,
            "timestamp": _sqlite_time(timestamp),
            "current_health_score": current,
            "vibration_health_score": vibration,
            "overall_health_score": overall,
            "status": status,
            "details_json": _dumps(assessment),
        }
        values.update({key: value for key, value in optional_values.items() if key in history_cols})
        keys = list(values)
        connection.execute(
            f"INSERT INTO asset_health_history({','.join(keys)}) VALUES({','.join('?' for _ in keys)})",
            tuple(values[key] for key in keys),
        )

    return {"assessment_upserted": 1, "overall_health_score": overall, "status": status}


def persist_stage_result(
    connection: sqlite3.Connection,
    *,
    capture_id: str,
    asset_id: str | None,
    stage_name: str,
    status: str,
    row_count: int | None = None,
    message: str | None = None,
    details: Mapping[str, Any] | None = None,
) -> None:
    ensure_full_diagnostic_schema(connection)
    row_id = _stable_id("stage", capture_id, stage_name, length=28)
    connection.execute(
        """
        INSERT INTO pipeline_stage_results(
          id,capture_id,asset_id,stage_name,status,row_count,message,details_json,created_at
        ) VALUES(?,?,?,?,?,?,?,?,?)
        ON CONFLICT(capture_id,stage_name) DO UPDATE SET
          asset_id=excluded.asset_id,status=excluded.status,row_count=excluded.row_count,
          message=excluded.message,details_json=excluded.details_json,created_at=excluded.created_at
        """,
        (
            row_id, capture_id, asset_id, stage_name, status, row_count, message,
            _dumps(details or {}), _sqlite_time(),
        ),
    )


def capture_database_counts(connection: sqlite3.Connection, capture_id: str, asset_id: str) -> dict[str, Any]:
    """Return a capture-scoped database completeness snapshot."""
    tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}

    def scalar(sql: str, params: tuple[Any, ...] = ()) -> int:
        row = connection.execute(sql, params).fetchone()
        return int(row[0] or 0) if row else 0

    result: dict[str, Any] = {
        "asset_count": scalar("SELECT COUNT(*) FROM assets WHERE id=?", (asset_id,)),
        "sensor_count": scalar("SELECT COUNT(*) FROM sensors WHERE asset_id=?", (asset_id,)),
        "current_sensor_count": scalar("SELECT COUNT(*) FROM sensors WHERE asset_id=? AND lower(type)='current'", (asset_id,)),
        "vibration_sensor_count": scalar("SELECT COUNT(*) FROM sensors WHERE asset_id=? AND lower(type)='vibration'", (asset_id,)),
        "current_sensors_with_features": scalar("SELECT COUNT(*) FROM sensors WHERE asset_id=? AND lower(type)='current' AND extracted_features IS NOT NULL AND length(trim(extracted_features))>2", (asset_id,)),
        "current_sensors_with_diagnosis": scalar("SELECT COUNT(*) FROM sensors WHERE asset_id=? AND lower(type)='current' AND diagnosis_report IS NOT NULL AND length(trim(diagnosis_report))>2", (asset_id,)),
        "telemetry_count": scalar("SELECT COUNT(*) FROM sensor_telemetry WHERE capture_id=?", (capture_id,)) if "sensor_telemetry" in tables else 0,
        "mcsa_analysis_count": scalar("SELECT COUNT(*) FROM mcsa_analysis_runs WHERE capture_id=?", (capture_id,)) if "mcsa_analysis_runs" in tables else 0,
        "mcsa_feature_count": scalar("SELECT COUNT(*) FROM mcsa_feature_values f JOIN mcsa_analysis_runs a ON a.id=f.analysis_id WHERE a.capture_id=?", (capture_id,)) if "mcsa_feature_values" in tables else 0,
        "mcsa_fault_evidence_count": scalar("SELECT COUNT(*) FROM mcsa_fault_evidence f JOIN mcsa_analysis_runs a ON a.id=f.analysis_id WHERE a.capture_id=?", (capture_id,)) if "mcsa_fault_evidence" in tables else 0,
        "health_assessment_count": scalar("SELECT COUNT(*) FROM health_assessments WHERE capture_id=?", (capture_id,)) if "health_assessments" in tables else 0,
        "asset_health_history_count": scalar("SELECT COUNT(*) FROM asset_health_history WHERE asset_id=?", (asset_id,)) if "asset_health_history" in tables else 0,
        "vibration_analysis_count": scalar("SELECT COUNT(*) FROM vibration_analysis_runs WHERE capture_id=?", (capture_id,)) if "vibration_analysis_runs" in tables else 0,
        "vibration_feature_count": scalar("SELECT COUNT(*) FROM vibration_feature_values f JOIN vibration_analysis_runs a ON a.id=f.analysis_id WHERE a.capture_id=?", (capture_id,)) if "vibration_feature_values" in tables else 0,
        "vibration_fault_evidence_count": scalar("SELECT COUNT(*) FROM vibration_fault_evidence f JOIN vibration_analysis_runs a ON a.id=f.analysis_id WHERE a.capture_id=?", (capture_id,)) if "vibration_fault_evidence" in tables else 0,
        "vibration_method_execution_count": scalar("SELECT COUNT(*) FROM vibration_method_executions m JOIN vibration_analysis_runs a ON a.id=m.analysis_id WHERE a.capture_id=?", (capture_id,)) if "vibration_method_executions" in tables else 0,
        "rul_history_count": scalar("SELECT COUNT(*) FROM rul_indicator_history WHERE capture_id=?", (capture_id,)) if "rul_indicator_history" in tables else 0,
        "rul_estimate_count": scalar("SELECT COUNT(*) FROM rul_estimates WHERE capture_id=?", (capture_id,)) if "rul_estimates" in tables else 0,
        "prediction_count": scalar("SELECT COUNT(*) FROM predictions WHERE capture_id=?", (capture_id,)) if "predictions" in tables and "capture_id" in columns(connection, "predictions") else 0,
        "energy_count": scalar("SELECT COUNT(*) FROM energy_records WHERE capture_id=?", (capture_id,)) if "energy_records" in tables and "capture_id" in columns(connection, "energy_records") else 0,
        "alert_count": scalar("SELECT COUNT(*) FROM alerts WHERE asset_id=?", (asset_id,)) if "alerts" in tables else 0,
        "failure_mode_count": scalar("SELECT COUNT(*) FROM failure_modes") if "failure_modes" in tables else 0,
        "pipeline_stage_count": scalar("SELECT COUNT(*) FROM pipeline_stage_results WHERE capture_id=?", (capture_id,)) if "pipeline_stage_results" in tables else 0,
        "processing_run_count": scalar("SELECT COUNT(*) FROM processing_runs WHERE run_id=?", (capture_id,)) if "processing_runs" in tables else 0,
    }
    if "assets" in tables:
        row = connection.execute(
            "SELECT health,health_score,status,rul FROM assets WHERE id=?", (asset_id,)
        ).fetchone()
        result["asset_health"] = dict(zip(("health", "health_score", "status", "rul"), row)) if row else None
    if "plants" in tables:
        row = connection.execute(
            "SELECT p.health_score FROM plants p JOIN assets a ON a.plant_id=p.id WHERE a.id=?", (asset_id,)
        ).fetchone()
        result["plant_health_score"] = row[0] if row else None
    return result
