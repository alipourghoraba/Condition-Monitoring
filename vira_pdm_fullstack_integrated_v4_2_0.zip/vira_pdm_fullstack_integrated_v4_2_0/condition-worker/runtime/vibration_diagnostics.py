#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
from scipy import signal

from vibration_core.acfmd import acfmd, encoder_to_phase_and_ias
from vibration_core.adalmed import adalmed
from vibration_core.common import EPS, flatten_numeric, harmonic_energy_ratio, envelope_spectrum, preprocess, spectral_features, time_features
from vibration_core.compound_mhs import compound_mhs_separation
from vibration_core.dpmm import evaluate_dpmm, load_artifact
from vibration_core.edmf import edmf, select_structure_length
from vibration_core.fmd_mck_lkd import fmd_mck_lkd_pipeline
from vibration_core.fscnn import infer as fscnn_infer
from vibration_core.geometry import bearing_fault_frequencies, gear_frequencies, resolve_bearing_geometry, resolve_rotational_hz
from vibration_core.high_frequency_tf import extract_wistft_and_wavelet_features, predict_svm
from vibration_core.model_based_fft import diagnose_spectral_patterns
from vibration_core.rq_detector import ekf_condition_signal, minimum_distance_test, rayleigh_quotient_spectrum
from vibration_core.stochastic_resonance import adaptive_stochastic_resonance
from vibration_core.supervised import infer_supervised
from vibration_core.tsma import tsma

SCHEMA_VERSION = "1.0"
ENGINE_VERSION = "2.0.0"


def _read_json(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError(f"expected JSON object in {path}")
    return data


def _json_safe(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, np.ndarray):
        return [_json_safe(v) for v in value.tolist()]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        value = float(value)
        return value if math.isfinite(value) else None
    if isinstance(value, Path):
        return str(value)
    return value


def _compact_method_result(result: dict[str, Any], *, max_series_points: int = 1024) -> dict[str, Any]:
    def compact(value: Any, key: str = "") -> Any:
        if isinstance(value, np.ndarray):
            arr = value.reshape(-1)
            if arr.size > max_series_points:
                idx = np.linspace(0, arr.size - 1, max_series_points).astype(int)
                arr = arr[idx]
            return _json_safe(arr)
        if isinstance(value, list) and len(value) > max_series_points and all(isinstance(v, (int, float, np.number)) for v in value):
            idx = np.linspace(0, len(value) - 1, max_series_points).astype(int)
            return [_json_safe(value[i]) for i in idx]
        if isinstance(value, Mapping):
            return {str(k): compact(v, str(k)) for k, v in value.items()}
        if isinstance(value, list):
            return [compact(v, key) for v in value]
        return _json_safe(value)
    return compact(result)


def _load_prepared_signals(manifest: Mapping[str, Any], prepared_dir: Path) -> dict[str, np.ndarray]:
    signals: dict[str, np.ndarray] = {}
    for channel, details in (manifest.get("channels") or {}).items():
        if not isinstance(details, Mapping):
            continue
        path = details.get("prepared_signal_path")
        candidates = [Path(path)] if path else []
        candidates += [prepared_dir / f"{channel}.npy", prepared_dir / f"{channel}.txt"]
        for candidate in candidates:
            if candidate.exists():
                if candidate.suffix.lower() == ".npy":
                    values = np.load(candidate, allow_pickle=False)
                else:
                    values = np.loadtxt(candidate)
                signals[str(channel)] = np.asarray(values, dtype=np.float64).reshape(-1)
                break
    return signals


def _targets(bearing: Mapping[str, float] | None, gears: Mapping[str, float] | None) -> dict[str, tuple[str, float]]:
    out: dict[str, tuple[str, float]] = {}
    if bearing:
        mapping = {
            "bpfo_outer_race_hz": ("VIB-BEARING-OUTER", "Outer-race bearing fault"),
            "bpfi_inner_race_hz": ("VIB-BEARING-INNER", "Inner-race bearing fault"),
            "bsf_rolling_element_hz": ("VIB-BEARING-BALL", "Rolling-element bearing fault"),
            "ftf_cage_hz": ("VIB-BEARING-CAGE", "Bearing cage fault"),
        }
        for key, (code, name) in mapping.items():
            if bearing.get(key):
                out[code] = (name, float(bearing[key]))
    if gears:
        for key, value in gears.items():
            if key.endswith("mesh_hz"):
                out[f"VIB-GEAR-{key.upper()}"] = ("Gear mesh/local tooth fault", float(value))
    return out


def _evidence_from_processed(method: str, values: np.ndarray, fs: float, targets: Mapping[str, tuple[str, float]], multiplier: float = 5.0) -> list[dict[str, Any]]:
    if not targets:
        return []
    f, a, _ = envelope_spectrum(values, fs)
    rows: list[dict[str, Any]] = []
    for code, (name, target) in targets.items():
        ratio = harmonic_energy_ratio(f, a, target, harmonics=4)
        rows.append({
            "fault_code": code,
            "fault_name": name,
            "score": float(np.clip(float(ratio["ratio"]) * multiplier, 0.0, 1.0)),
            "source_method": method,
            "theoretical_frequency_hz": float(target),
            "matched_frequency_hz": float(ratio["harmonics"][0]["actual_hz"]),
            "details": ratio,
        })
    return rows


def _status_result(method: str, *, status: str, features: Mapping[str, Any] | None = None, evidence: Sequence[Mapping[str, Any]] | None = None, diagnostics: Mapping[str, Any] | None = None, reason: str | None = None) -> dict[str, Any]:
    return {
        "method": method,
        "status": status,
        "reason": reason,
        "features": dict(features or {}),
        "fault_evidence": [dict(row) for row in (evidence or [])],
        "diagnostics": dict(diagnostics or {}),
    }


def _aggregate_evidence(method_results: Sequence[Mapping[str, Any]], warning: float, critical: float) -> list[dict[str, Any]]:
    grouped: dict[str, dict[str, Any]] = {}
    for method in method_results:
        for row in method.get("fault_evidence") or []:
            code = str(row.get("fault_code") or "VIB-UNKNOWN")
            score = float(row.get("score") or 0.0)
            item = grouped.setdefault(code, {"fault_code": code, "fault_name": row.get("fault_name") or code, "scores": [], "sources": []})
            item["scores"].append(score)
            item["sources"].append({"method": row.get("source_method") or method.get("method"), "score": score, "theoretical_frequency_hz": row.get("theoretical_frequency_hz"), "matched_frequency_hz": row.get("matched_frequency_hz"), "details": row.get("details")})
    rows: list[dict[str, Any]] = []
    for item in grouped.values():
        scores = sorted(item.pop("scores"), reverse=True)
        # Evidence fusion is deliberately not a calibrated probability. The top
        # method dominates, while corroborating methods can strengthen it.
        fused = scores[0] if scores else 0.0
        if len(scores) > 1:
            fused = min(1.0, 0.7 * scores[0] + 0.3 * float(np.mean(scores[1:])))
        severity = "CRITICAL" if fused >= critical else "WARNING" if fused >= warning else "HEALTHY"
        item.update({"evidence_score": float(fused), "severity": severity, "semantics": "multi-method vibration evidence; not calibrated probability"})
        rows.append(item)
    return sorted(rows, key=lambda r: r["evidence_score"], reverse=True)


def analyze_vibration_channel(*, channel: str, values: np.ndarray, fs: float, metadata: Mapping[str, Any], config: Mapping[str, Any], baseline: Mapping[str, Any] | None = None, all_signals: Mapping[str, np.ndarray] | None = None) -> dict[str, Any]:
    max_samples = int(config.get("maximum_processing_samples") or 120000)
    x = preprocess(values)
    if x.size > max_samples:
        step = int(np.ceil(x.size / max_samples))
        x = signal.decimate(x, step, ftype="fir", zero_phase=True)
        fs_work = fs / step
    else:
        step = 1
        fs_work = float(fs)

    rotation = resolve_rotational_hz(metadata)
    bearing_geometry = resolve_bearing_geometry(metadata)
    bearing = None
    if rotation and bearing_geometry:
        bearing = bearing_fault_frequencies(rotational_hz=rotation, **{k: bearing_geometry[k] for k in ("rolling_elements", "ball_diameter_mm", "pitch_diameter_mm")}, contact_angle_deg=float(bearing_geometry.get("contact_angle_deg", 0.0)))
    mechanics = metadata.get("mechanical") or metadata.get("machinery") or {}
    gears = None
    if rotation and isinstance(mechanics.get("gearbox"), Mapping) and mechanics["gearbox"].get("stages"):
        gears = gear_frequencies(input_shaft_hz=rotation, stages=list(mechanics["gearbox"]["stages"]))
    targets = _targets(bearing, gears)
    methods_cfg = config.get("methods") or {}
    results: list[dict[str, Any]] = []

    basic = {**time_features(x), **spectral_features(x, fs_work)}
    results.append(_status_result("basic_time_frequency_envelope", status="executed", features=basic, diagnostics={"sample_rate_hz": fs_work, "samples": x.size, "decimation_factor": step}))

    supervised_cfg = methods_cfg.get("supervised_ml") or {}
    if supervised_cfg.get("enabled", True):
        artifact_path = supervised_cfg.get("artifact_path")
        if artifact_path:
            try:
                pred = infer_supervised(basic, artifact_path)
                results.append(_status_result("SupervisedML", status="executed", features=pred, diagnostics={"artifact_path": str(Path(artifact_path).resolve())}))
            except Exception as exc:
                results.append(_status_result("SupervisedML", status="failed", reason=str(exc)))
        else:
            results.append(_status_result("SupervisedML", status="skipped", reason="No validated supervised vibration artifact configured."))

    try:
        spectral = diagnose_spectral_patterns(x, fs_work, rotational_hz=rotation, bearing_frequencies=bearing, gear_frequencies=gears, axial_channel="axial" in channel.lower())
        results.append(_status_result("model_based_fft", status="executed", features=spectral["features"], evidence=spectral["fault_evidence"], diagnostics={"spectrum_points": len(spectral["frequency_axis_hz"])}))
    except Exception as exc:
        results.append(_status_result("model_based_fft", status="failed", reason=str(exc)))

    edmf_cfg = methods_cfg.get("edmf") or {}
    if edmf_cfg.get("enabled", True):
        try:
            length, scores = select_structure_length(x, edmf_cfg.get("structure_candidates", [3, 5, 7, 9, 11]))
            y = edmf(x, structure_length=length)
            feat = {**time_features(y), "structure_length": length, "structure_kurtosis_scores": scores}
            results.append(_status_result("EDMF", status="executed", features=feat, evidence=_evidence_from_processed("EDMF", y, fs_work, targets), diagnostics={"paper_equations": "erosion/dilation/opening/closing and CDE/DCE/EOD/OED, Eq. 1-11"}))
        except Exception as exc:
            results.append(_status_result("EDMF", status="failed", reason=str(exc)))

    ad_cfg = methods_cfg.get("adalmed") or {}
    if ad_cfg.get("enabled", True):
        try:
            y, info = adalmed(x, filter_length=int(ad_cfg.get("filter_length", 50)), keep_fraction=float(ad_cfg.get("keep_fraction", 0.05)), max_iterations=int(ad_cfg.get("max_iterations", 20)))
            results.append(_status_result("AdaLMED", status="executed", features={**time_features(y), "output_kurtosis": info["output_kurtosis"]}, evidence=_evidence_from_processed("AdaLMED", y, fs_work, targets), diagnostics=info))
        except Exception as exc:
            results.append(_status_result("AdaLMED", status="failed", reason=str(exc)))

    tf_cfg = methods_cfg.get("wistft_wavelet") or {}
    tf_features = None
    if tf_cfg.get("enabled", True):
        try:
            band = tuple(map(float, tf_cfg.get("high_band_hz", [3000.0, 8000.0])))
            tf_features = extract_wistft_and_wavelet_features(x, fs_work, segment_seconds=float(tf_cfg.get("segment_seconds", 0.5)), high_band_hz=band, tf_bins=int(tf_cfg.get("tf_bins", 96)), output_bins=int(tf_cfg.get("output_bins", 500)))
            compact_features = {
                "high_band_hz": tf_features["high_band_hz"],
                "segment_seconds": tf_features["segment_seconds"],
                "wistft_peak_frequency_hz": tf_features["wistft"]["peak_frequency_hz"],
                "wistft_peak_normalized_amplitude": tf_features["wistft"]["peak_normalized_amplitude"],
                "morlet_peak_frequency_hz": tf_features["morlet"]["peak_frequency_hz"],
            }
            results.append(_status_result("WISTFT_WT_HFBA", status="executed", features=compact_features, diagnostics={"wistft_nfv": tf_features["wistft"]["normalized_feature_vector"], "morlet_nfv": tf_features["morlet"]["normalized_feature_vector"]}))
            svm_path = (methods_cfg.get("wistft_svm") or {}).get("model_path")
            if svm_path:
                pred = predict_svm(tf_features["wistft"]["normalized_feature_vector"], svm_path)
                results.append(_status_result("WISTFT_SVM", status="executed", features=pred, diagnostics={"artifact_required": True}))
            else:
                results.append(_status_result("WISTFT_SVM", status="skipped", reason="No trained SVM artifact configured; features were still generated."))
        except Exception as exc:
            results.append(_status_result("WISTFT_WT_HFBA", status="failed", reason=str(exc)))

    rq_cfg = methods_cfg.get("ekf_rayleigh_min_distance") or {}
    if rq_cfg.get("enabled", True) and targets:
        try:
            conditioned, ekf_info = ekf_condition_signal(x, fs_work, dominant_components=int(rq_cfg.get("dominant_components", 3)))
            rq_rows = []
            rq_evidence = []
            baseline_thresholds = (baseline or {}).get("rayleigh_thresholds") or {}
            for code, (name, target) in targets.items():
                width = max(1.0, float(rq_cfg.get("search_band_fraction", 0.04)) * target)
                rq = rayleigh_quotient_spectrum(conditioned, fs_work, low_hz=max(0.1, target - width), high_hz=min(fs_work / 2, target + width))
                gamma = float(baseline_thresholds.get(code, rq["peak_amplitude"] * 1.5))
                test = minimum_distance_test(conditioned, fs_work, frequency_hz=float(rq["peak_frequency_hz"]), threshold_amplitude=gamma)
                score = float(np.clip(test["estimated_amplitude"] / (gamma + EPS) - 0.5, 0.0, 1.0))
                rq_rows.append({"fault_code": code, "rayleigh": {k: v for k, v in rq.items() if k not in {"frequencies_hz", "rayleigh_quotient"}}, "minimum_distance": test})
                rq_evidence.append({"fault_code": code, "fault_name": name, "score": score, "source_method": "EKF_Rayleigh_MinDistance", "theoretical_frequency_hz": target, "matched_frequency_hz": rq["peak_frequency_hz"], "details": test})
            results.append(_status_result("EKF_Rayleigh_MinDistance", status="executed", features={"target_count": len(rq_rows)}, evidence=rq_evidence, diagnostics={"ekf": ekf_info, "targets": rq_rows}))
        except Exception as exc:
            results.append(_status_result("EKF_Rayleigh_MinDistance", status="failed", reason=str(exc)))
    elif rq_cfg.get("enabled", True):
        results.append(_status_result("EKF_Rayleigh_MinDistance", status="skipped", reason="Bearing/gear geometry and rotational speed are required."))

    tsma_cfg = methods_cfg.get("tsma") or {}
    if tsma_cfg.get("enabled", True) and rotation:
        try:
            samples_per_cycle = max(2, int(round(fs_work / rotation)))
            y, info = tsma(x, samples_per_cycle)
            results.append(_status_result("TSMA", status="executed", features={**time_features(y), **info}, evidence=_evidence_from_processed("TSMA", y, fs_work, targets), diagnostics={"application": "gear/periodic impulse enhancement"}))
        except Exception as exc:
            results.append(_status_result("TSMA", status="failed", reason=str(exc)))
    elif tsma_cfg.get("enabled", True):
        results.append(_status_result("TSMA", status="skipped", reason="Rotational speed is required."))

    primary_target = next(iter(targets.values()))[1] if targets else None
    sr_cfg = methods_cfg.get("improved_stochastic_resonance") or {}
    if sr_cfg.get("enabled", False) and primary_target:
        try:
            y, info = adaptive_stochastic_resonance(x, fs_work, target_hz=primary_target, particles=int(sr_cfg.get("particles", 12)), iterations=int(sr_cfg.get("iterations", 10)))
            results.append(_status_result("ImprovedPiecewiseSR", status="executed", features={"modified_snr_db": info["modified_snr_db"]}, evidence=_evidence_from_processed("ImprovedPiecewiseSR", y, float(info["effective_sample_rate_hz"]), targets), diagnostics=info))
        except Exception as exc:
            results.append(_status_result("ImprovedPiecewiseSR", status="failed", reason=str(exc)))
    elif sr_cfg.get("enabled", False):
        results.append(_status_result("ImprovedPiecewiseSR", status="skipped", reason="A theoretical fault frequency is required."))

    fmd_cfg = methods_cfg.get("fmd_mck_lkd") or {}
    if fmd_cfg.get("enabled", False) and primary_target:
        try:
            y, info = fmd_mck_lkd_pipeline(x, fs_work, target_frequency_hz=primary_target, modes=int(fmd_cfg.get("modes", 4)), filter_length=int(fmd_cfg.get("filter_length", 40)), shifts=int(fmd_cfg.get("shifts", 1)))
            results.append(_status_result("FMD_MCK_LKD", status="executed", features={"combined_objective": info["mck_lkd"]["combined_objective"], "fault_harmonic_ratio": info["fault_harmonic_evidence"]["ratio"]}, evidence=_evidence_from_processed("FMD_MCK_LKD", y, fs_work, targets), diagnostics=info))
        except Exception as exc:
            results.append(_status_result("FMD_MCK_LKD", status="failed", reason=str(exc)))

    comp_cfg = methods_cfg.get("compound_mhs_pca_ica") or {}
    if comp_cfg.get("enabled", True) and bearing and gears:
        try:
            bearing_target = float(bearing["bpfo_outer_race_hz"])
            gear_target = next(float(v) for k, v in gears.items() if k.endswith("mesh_hz"))
            info = compound_mhs_separation(x, fs_work, bearing_frequency_hz=bearing_target, gear_mesh_frequency_hz=gear_target, max_imfs=int(comp_cfg.get("max_imfs", 8)), components=int(comp_cfg.get("components", 3)))
            results.append(_status_result("EMD_Hilbert_MHS_PCA_ICA", status="executed", features={"imf_count": info["imf_count"], "decomposition_backend": info["decomposition_backend"], "bearing_evidence": info["bearing_evidence"], "gear_evidence": info["gear_evidence"]}, diagnostics=info))
        except Exception as exc:
            results.append(_status_result("EMD_Hilbert_MHS_PCA_ICA", status="failed", reason=str(exc)))
    elif comp_cfg.get("enabled", True):
        results.append(_status_result("EMD_Hilbert_MHS_PCA_ICA", status="skipped", reason="Both bearing and gearbox metadata are required for compound separation."))

    dp_cfg = methods_cfg.get("dpmm_early_anomaly") or {}
    if dp_cfg.get("enabled", True):
        path = dp_cfg.get("artifact_path")
        if path:
            try:
                artifact = load_artifact(path)
                # Build subwindow feature vectors in the artifact's exact order.
                window = max(64, int(fs_work * 0.5))
                rows = []
                for start in range(0, x.size - window + 1, window):
                    segment_x = x[start:start + window]
                    base = {**time_features(segment_x), **spectral_features(segment_x, fs_work)}
                    rows.append([float(base[name]) for name in artifact.feature_names])
                result = evaluate_dpmm(artifact, np.asarray(rows))
                results.append(_status_result("DPMM_KL_EarlyAnomaly", status="executed" if result.get("status") == "ok" else "insufficient_data", features=result, diagnostics={"artifact_path": str(Path(path).resolve())}))
            except Exception as exc:
                results.append(_status_result("DPMM_KL_EarlyAnomaly", status="failed", reason=str(exc)))
        else:
            results.append(_status_result("DPMM_KL_EarlyAnomaly", status="skipped", reason="No healthy-trained DPMM artifact configured."))

    fscnn_cfg = methods_cfg.get("fscnn") or {}
    if fscnn_cfg.get("enabled", True):
        path = fscnn_cfg.get("model_path")
        if path:
            try:
                pred = fscnn_infer(x, path, labels_path=fscnn_cfg.get("labels_path"))
                results.append(_status_result("FSCNN", status="executed", features=pred, diagnostics={"trained_model_required": True}))
            except Exception as exc:
                results.append(_status_result("FSCNN", status="failed", reason=str(exc)))
        else:
            results.append(_status_result("FSCNN", status="skipped", reason="Architecture is included, but no machine-specific trained checkpoint is configured."))

    ac_cfg = methods_cfg.get("acfmd_encoder") or {}
    encoder_name = str(ac_cfg.get("encoder_channel") or "ENCODER")
    if ac_cfg.get("enabled", True) and all_signals and encoder_name in all_signals:
        try:
            encoder = all_signals[encoder_name]
            phase, ias = encoder_to_phase_and_ias(encoder, fs, counts_per_revolution=ac_cfg.get("counts_per_revolution"), input_is_phase=bool(ac_cfg.get("input_is_phase", True)))
            n = min(values.size, phase.size)
            info = acfmd(values[:n], phase[:n], fs)
            results.append(_status_result("ACFMD_Encoder", status="executed", features={"peak_order": info["peak_order"], "median_ias_hz": float(np.median(ias))}, diagnostics=info))
        except Exception as exc:
            results.append(_status_result("ACFMD_Encoder", status="failed", reason=str(exc)))
    elif ac_cfg.get("enabled", True):
        results.append(_status_result("ACFMD_Encoder", status="skipped", reason=f"Encoder channel {encoder_name!r} was not supplied."))

    warning = float(config.get("warning_score", 0.25))
    critical = float(config.get("critical_score", 0.55))
    fault_scores = _aggregate_evidence(results, warning, critical)
    worst = fault_scores[0] if fault_scores else None
    overall = worst["severity"] if worst else "HEALTHY"
    health = 100.0 if not worst else float(np.clip(100.0 * (1.0 - worst["evidence_score"]), 0.0, 100.0))

    flat: dict[str, float] = {}
    for result in results:
        flatten_numeric(str(result["method"]), result.get("features") or {}, flat)
    return {
        "channel": channel,
        "sample_rate_hz": float(fs),
        "working_sample_rate_hz": float(fs_work),
        "sample_count": int(values.size),
        "duration_seconds": float(values.size / fs),
        "rotational_frequency_hz": rotation,
        "bearing_frequencies": bearing,
        "gear_frequencies": gears,
        "method_results": [_compact_method_result(r) for r in results],
        "fault_scores": fault_scores,
        "summary": {"severity": overall, "health_index": health, "active_faults": sum(1 for r in fault_scores if r["severity"] != "HEALTHY"), "method_count": len(results), "executed_methods": sum(1 for r in results if r["status"] == "executed")},
        "flat_features": flat,
    }


def run_vibration_diagnostics(*, manifest_path: str | Path, metadata_path: str | Path, prepared_dir: str | Path, config_path: str | Path, output_report: str | Path, output_features_csv: str | Path, baseline_path: str | Path | None = None) -> dict[str, Any]:
    manifest = _read_json(manifest_path)
    metadata = _read_json(metadata_path)
    config_file = Path(config_path).resolve()
    config = _read_json(config_file)
    baseline_file = Path(baseline_path).resolve() if baseline_path else None
    baseline = _read_json(baseline_file) if baseline_file and baseline_file.exists() else None

    # Resolve all trained-artifact paths relative to the configuration file so
    # the worker behaves identically regardless of its current directory.
    for method in (config.get("methods") or {}).values():
        if not isinstance(method, dict):
            continue
        for key in ("artifact_path", "model_path", "labels_path"):
            value = method.get(key)
            if value and not Path(str(value)).is_absolute():
                method[key] = str((config_file.parent / str(value)).resolve())
    if baseline:
        dpmm = (config.get("methods") or {}).get("dpmm_early_anomaly") or {}
        if not dpmm.get("artifact_path") and baseline.get("dpmm_artifact"):
            artifact = Path(str(baseline["dpmm_artifact"]))
            if not artifact.is_absolute() and baseline_file is not None:
                artifact = (baseline_file.parent / artifact).resolve()
            dpmm["artifact_path"] = str(artifact)

    prepared = Path(prepared_dir)
    signals = _load_prepared_signals(manifest, prepared)
    prefixes = tuple(config.get("channel_prefixes") or ["VIB_"])
    channels = [name for name in signals if name.startswith(prefixes)]
    fs = float(manifest["fs"])
    channel_reports = [analyze_vibration_channel(channel=name, values=signals[name], fs=fs, metadata=metadata, config=config, baseline=baseline, all_signals=signals) for name in sorted(channels)]

    all_faults: dict[str, dict[str, Any]] = {}
    for report in channel_reports:
        for row in report["fault_scores"]:
            code = row["fault_code"]
            existing = all_faults.get(code)
            if existing is None or row["evidence_score"] > existing["evidence_score"]:
                all_faults[code] = {**row, "channel": report["channel"]}
    asset_faults = sorted(all_faults.values(), key=lambda r: r["evidence_score"], reverse=True)
    health = min((r["summary"]["health_index"] for r in channel_reports), default=None)
    severity = asset_faults[0]["severity"] if asset_faults else ("NO_VIBRATION_DATA" if not channels else "HEALTHY")
    report = {
        "schema_version": SCHEMA_VERSION,
        "engine": "Vira vibration diagnostic core",
        "engine_version": ENGINE_VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "asset": manifest.get("asset") or {},
        "segment": manifest.get("segment") or {},
        "configuration_path": str(config_file),
        "baseline_path": str(baseline_file) if baseline_file else None,
        "summary": {"status": severity, "health_index": health, "vibration_channel_count": len(channels), "active_fault_count": sum(1 for r in asset_faults if r["severity"] != "HEALTHY")},
        "fault_scores": asset_faults,
        "channels": channel_reports,
        "important_semantics": {"evidence_score": "multi-method diagnostic evidence, not calibrated probability", "trained_methods": "SVM, DPMM and FSCNN execute only when a validated artifact is configured", "encoder_method": "ACFMD executes only when an encoder/phase channel is present"},
    }
    Path(output_report).parent.mkdir(parents=True, exist_ok=True)
    Path(output_report).write_text(json.dumps(_json_safe(report), ensure_ascii=False, indent=2), encoding="utf-8")

    names = sorted({name for channel in channel_reports for name in channel["flat_features"]})
    with Path(output_features_csv).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["channel", *names])
        for channel in channel_reports:
            writer.writerow([channel["channel"], *[channel["flat_features"].get(name, "") for name in names]])
    return report


def ensure_vibration_schema(connection: sqlite3.Connection) -> None:
    connection.executescript("""
    CREATE TABLE IF NOT EXISTS vibration_analysis_runs (
        id TEXT PRIMARY KEY,
        asset_id TEXT NOT NULL REFERENCES assets(id),
        sensor_id TEXT NOT NULL REFERENCES sensors(id),
        capture_id TEXT NOT NULL,
        channel TEXT NOT NULL,
        timestamp DATETIME NOT NULL,
        sample_rate_hz REAL NOT NULL,
        duration_seconds REAL NOT NULL,
        severity TEXT NOT NULL,
        health_index REAL,
        report_json JSON NOT NULL,
        created_at DATETIME NOT NULL,
        UNIQUE(sensor_id, capture_id)
    );
    CREATE TABLE IF NOT EXISTS vibration_feature_values (
        id TEXT PRIMARY KEY,
        analysis_id TEXT NOT NULL REFERENCES vibration_analysis_runs(id) ON DELETE CASCADE,
        feature_name TEXT NOT NULL,
        value REAL NOT NULL,
        unit TEXT,
        method TEXT,
        category TEXT,
        UNIQUE(analysis_id, feature_name)
    );
    CREATE TABLE IF NOT EXISTS vibration_fault_evidence (
        id TEXT PRIMARY KEY,
        analysis_id TEXT NOT NULL REFERENCES vibration_analysis_runs(id) ON DELETE CASCADE,
        fault_code TEXT NOT NULL,
        fault_name TEXT NOT NULL,
        severity TEXT NOT NULL,
        evidence_score REAL NOT NULL,
        theoretical_frequency_hz REAL,
        matched_frequency_hz REAL,
        source_method TEXT,
        details_json JSON,
        UNIQUE(analysis_id, fault_code)
    );
    CREATE TABLE IF NOT EXISTS vibration_method_executions (
        id TEXT PRIMARY KEY,
        analysis_id TEXT NOT NULL REFERENCES vibration_analysis_runs(id) ON DELETE CASCADE,
        method_name TEXT NOT NULL,
        status TEXT NOT NULL,
        reason TEXT,
        features_json JSON NOT NULL,
        diagnostics_json JSON NOT NULL,
        created_at DATETIME NOT NULL,
        UNIQUE(analysis_id, method_name)
    );
    CREATE TABLE IF NOT EXISTS vibration_model_results (
        id TEXT PRIMARY KEY,
        analysis_id TEXT NOT NULL REFERENCES vibration_analysis_runs(id) ON DELETE CASCADE,
        model_name TEXT NOT NULL,
        model_version TEXT,
        predicted_label TEXT,
        score REAL,
        artifact_path TEXT,
        details_json JSON,
        UNIQUE(analysis_id, model_name)
    );
    CREATE INDEX IF NOT EXISTS idx_vibration_analysis_asset_time ON vibration_analysis_runs(asset_id, timestamp);
    CREATE INDEX IF NOT EXISTS idx_vibration_fault_code ON vibration_fault_evidence(fault_code, severity);
    """)


def persist_vibration_report(connection: sqlite3.Connection, *, report: Mapping[str, Any], asset_id: str, capture_id: str, sensor_ids: Mapping[str, str], timestamp: datetime, plant_id: str | None = None) -> dict[str, int]:
    ensure_vibration_schema(connection)
    stats = {
        "analyses_upserted": 0,
        "features_upserted": 0,
        "fault_evidence_upserted": 0,
        "method_executions_upserted": 0,
        "model_results_upserted": 0,
        "alerts_upserted": 0,
        "alerts_resolved": 0,
        "failure_modes_upserted": 0,
    }
    for channel in report.get("channels") or []:
        name = str(channel["channel"])
        sensor_id = sensor_ids.get(name)
        if not sensor_id:
            continue
        analysis_id = "vib-" + uuid.uuid5(uuid.NAMESPACE_URL, f"{sensor_id}|{capture_id}").hex[:24]
        connection.execute("""
            INSERT INTO vibration_analysis_runs(id,asset_id,sensor_id,capture_id,channel,timestamp,sample_rate_hz,duration_seconds,severity,health_index,report_json,created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(sensor_id,capture_id) DO UPDATE SET
              timestamp=excluded.timestamp, sample_rate_hz=excluded.sample_rate_hz,
              duration_seconds=excluded.duration_seconds, severity=excluded.severity,
              health_index=excluded.health_index, report_json=excluded.report_json
        """, (analysis_id, asset_id, sensor_id, capture_id, name, timestamp.replace(tzinfo=None).isoformat(sep=" "), float(channel["sample_rate_hz"]), float(channel["duration_seconds"]), str(channel["summary"]["severity"]), channel["summary"]["health_index"], json.dumps(_json_safe(channel), ensure_ascii=False), datetime.now(timezone.utc).replace(tzinfo=None).isoformat(sep=" ")))
        stats["analyses_upserted"] += 1
        for feature_name, value in (channel.get("flat_features") or {}).items():
            if not isinstance(value, (int, float)) or not math.isfinite(float(value)):
                continue
            row_id = "vf-" + uuid.uuid5(uuid.NAMESPACE_URL, f"{analysis_id}|{feature_name}").hex[:24]
            method = feature_name.split(".", 1)[0]
            connection.execute("""
                INSERT INTO vibration_feature_values(id,analysis_id,feature_name,value,unit,method,category)
                VALUES(?,?,?,?,?,?,?)
                ON CONFLICT(analysis_id,feature_name) DO UPDATE SET value=excluded.value, method=excluded.method
            """, (row_id, analysis_id, feature_name, float(value), None, method, "vibration"))
            stats["features_upserted"] += 1
        for fault in channel.get("fault_scores") or []:
            row_id = "ve-" + uuid.uuid5(uuid.NAMESPACE_URL, f"{analysis_id}|{fault['fault_code']}").hex[:24]
            source = (fault.get("sources") or [{}])[0]
            connection.execute("""
                INSERT INTO vibration_fault_evidence(id,analysis_id,fault_code,fault_name,severity,evidence_score,theoretical_frequency_hz,matched_frequency_hz,source_method,details_json)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(analysis_id,fault_code) DO UPDATE SET severity=excluded.severity,evidence_score=excluded.evidence_score,theoretical_frequency_hz=excluded.theoretical_frequency_hz,matched_frequency_hz=excluded.matched_frequency_hz,source_method=excluded.source_method,details_json=excluded.details_json
            """, (row_id, analysis_id, fault["fault_code"], fault["fault_name"], fault["severity"], float(fault["evidence_score"]), source.get("theoretical_frequency_hz"), source.get("matched_frequency_hz"), source.get("method"), json.dumps(_json_safe(fault), ensure_ascii=False)))
            stats["fault_evidence_upserted"] += 1
        for method in channel.get("method_results") or []:
            method_name = str(method.get("method") or "UNKNOWN_METHOD")
            method_row_id = "vme-" + uuid.uuid5(uuid.NAMESPACE_URL, f"{analysis_id}|{method_name}").hex[:24]
            connection.execute("""
                INSERT INTO vibration_method_executions(id,analysis_id,method_name,status,reason,features_json,diagnostics_json,created_at)
                VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(analysis_id,method_name) DO UPDATE SET status=excluded.status,reason=excluded.reason,features_json=excluded.features_json,diagnostics_json=excluded.diagnostics_json,created_at=excluded.created_at
            """, (method_row_id, analysis_id, method_name, str(method.get("status") or "unknown"), method.get("reason"), json.dumps(_json_safe(method.get("features") or {}), ensure_ascii=False), json.dumps(_json_safe(method.get("diagnostics") or {}), ensure_ascii=False), datetime.now(timezone.utc).replace(tzinfo=None).isoformat(sep=" ")))
            stats["method_executions_upserted"] += 1
            if method_name not in {"FSCNN", "WISTFT_SVM", "DPMM_KL_EarlyAnomaly", "SupervisedML"} or method.get("status") != "executed":
                continue
            features = method.get("features") or {}
            diagnostics = method.get("diagnostics") or {}
            artifact_path = features.get("model_path") or diagnostics.get("artifact_path")
            score = features.get("score")
            if score is None and isinstance(features.get("class_probabilities"), Mapping):
                score = max(features["class_probabilities"].values(), default=None)
            row_id = "vm-" + uuid.uuid5(uuid.NAMESPACE_URL, f"{analysis_id}|{method['method']}").hex[:24]
            connection.execute("""
                INSERT INTO vibration_model_results(id,analysis_id,model_name,model_version,predicted_label,score,artifact_path,details_json)
                VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(analysis_id,model_name) DO UPDATE SET predicted_label=excluded.predicted_label,score=excluded.score,artifact_path=excluded.artifact_path,details_json=excluded.details_json
            """, (row_id, analysis_id, method["method"], str(features.get("model_version") or "2.0.0"), features.get("label") or ("anomaly" if features.get("anomaly_detected") else "healthy" if features.get("status") == "ok" else None), score, artifact_path, json.dumps(_json_safe(method), ensure_ascii=False)))
            stats["model_results_upserted"] += 1

        # Persist the vibration output on the sensor record as well.
        columns = {row[1] for row in connection.execute("PRAGMA table_info(sensors)")}
        updates = []
        params: list[Any] = []
        if "extracted_features" in columns:
            updates.append("extracted_features=?")
            params.append(json.dumps(_json_safe(channel.get("flat_features") or {}), ensure_ascii=False))
        if "diagnosis_report" in columns:
            updates.append("diagnosis_report=?")
            params.append(json.dumps(_json_safe(channel), ensure_ascii=False))
        if "processing_status" in columns:
            updates.append("processing_status='completed'")
        if "last_processed_at" in columns:
            updates.append("last_processed_at=?")
            params.append(datetime.now(timezone.utc).replace(tzinfo=None).isoformat(sep=" "))
        if updates:
            params.append(sensor_id)
            connection.execute(f"UPDATE sensors SET {', '.join(updates)} WHERE id=?", params)

    # Surface asset-level vibration evidence to the existing operational alert
    # and plant failure-mode tables while retaining full method detail in the
    # normalized vibration tables above.
    active_codes: set[str] = set()
    generated_db = timestamp.replace(tzinfo=None).isoformat(sep=" ")
    for fault in report.get("fault_scores") or []:
        code = str(fault.get("fault_code") or "VIB-UNKNOWN")
        severity = str(fault.get("severity") or "HEALTHY").upper()
        if severity in {"WARNING", "CRITICAL"}:
            active_codes.add(code)
            existing = connection.execute(
                "SELECT id FROM alerts WHERE asset_id=? AND code=? AND resolved=0 ORDER BY timestamp DESC LIMIT 1",
                (asset_id, code),
            ).fetchone()
            message = f"{fault.get('fault_name') or code}: vibration evidence {100.0 * float(fault.get('evidence_score') or 0.0):.1f}%"
            if existing:
                connection.execute(
                    "UPDATE alerts SET severity=?,message=?,timestamp=? WHERE id=?",
                    (severity.lower(), message, generated_db, existing[0]),
                )
            else:
                alert_id = "alt-" + uuid.uuid5(uuid.NAMESPACE_URL, f"{asset_id}|{code}|{capture_id}").hex[:24]
                connection.execute(
                    "INSERT INTO alerts(id,severity,asset_id,code,message,timestamp,acknowledged,resolved) VALUES(?,?,?,?,?,?,0,0)",
                    (alert_id, severity.lower(), asset_id, code, message, generated_db),
                )
            stats["alerts_upserted"] += 1
        if plant_id:
            mode_id = "fm-" + uuid.uuid5(uuid.NAMESPACE_URL, f"{plant_id}|{code}").hex[:22]
            connection.execute(
                """INSERT INTO failure_modes(id,plant_id,name,value) VALUES(?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET name=excluded.name,value=excluded.value""",
                (mode_id, plant_id, f"Vibration: {fault.get('fault_name') or code}", 100.0 * float(fault.get("evidence_score") or 0.0)),
            )
            stats["failure_modes_upserted"] += 1

    for alert_id, code in connection.execute(
        "SELECT id,code FROM alerts WHERE asset_id=? AND resolved=0 AND code LIKE 'VIB-%'",
        (asset_id,),
    ).fetchall():
        if str(code) not in active_codes:
            connection.execute(
                "UPDATE alerts SET resolved=1,resolved_at=?,resolution=? WHERE id=?",
                (generated_db, "Automatically cleared by a later vibration diagnostic window.", alert_id),
            )
            stats["alerts_resolved"] += 1
    return stats


def build_parser():
    import argparse
    parser = argparse.ArgumentParser(
        description="Run the specialized vibration diagnostic core on prepared high-rate channels."
    )
    parser.add_argument("--manifest", required=True, help="ingestion_manifest.json")
    parser.add_argument("--metadata", required=True, help="original metadata.json")
    parser.add_argument("--prepared-dir", required=True, help="folder containing VIB_*.npy")
    parser.add_argument("--config", default="vibration_config.json")
    parser.add_argument("--baseline", default=None)
    parser.add_argument("--output-report", default="vibration_diagnostic_report.json")
    parser.add_argument("--output-features", default="vibration_features.csv")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = run_vibration_diagnostics(
        manifest_path=args.manifest,
        metadata_path=args.metadata,
        prepared_dir=args.prepared_dir,
        config_path=args.config,
        output_report=args.output_report,
        output_features_csv=args.output_features,
        baseline_path=args.baseline,
    )
    print(json.dumps(_json_safe(result.get("summary") or {}), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
