from __future__ import annotations

from typing import Sequence

import numpy as np
from scipy import stats

from .common import finite_array


def _pad(x: np.ndarray, m: int) -> np.ndarray:
    left = m // 2
    right = m - 1 - left
    return np.pad(x, (left, right), mode="edge")


def erosion(x: Sequence[float] | np.ndarray, g: Sequence[float] | np.ndarray) -> np.ndarray:
    f = finite_array(x)
    se = np.asarray(g, dtype=np.float64).reshape(-1)
    if se.size < 1 or se.size > f.size:
        raise ValueError("invalid structural element")
    padded = _pad(f, se.size)
    windows = np.lib.stride_tricks.sliding_window_view(padded, se.size)
    return np.min(windows - se[None, :], axis=1)


def dilation(x: Sequence[float] | np.ndarray, g: Sequence[float] | np.ndarray) -> np.ndarray:
    f = finite_array(x)
    se = np.asarray(g, dtype=np.float64).reshape(-1)
    if se.size < 1 or se.size > f.size:
        raise ValueError("invalid structural element")
    padded = _pad(f, se.size)
    windows = np.lib.stride_tricks.sliding_window_view(padded, se.size)
    return np.max(windows + se[::-1][None, :], axis=1)


def opening(x: Sequence[float] | np.ndarray, g: Sequence[float] | np.ndarray) -> np.ndarray:
    return dilation(erosion(x, g), g)


def closing(x: Sequence[float] | np.ndarray, g: Sequence[float] | np.ndarray) -> np.ndarray:
    return erosion(dilation(x, g), g)


def edmf(values: Sequence[float] | np.ndarray, *, structure_length: int = 5, structure: Sequence[float] | None = None) -> np.ndarray:
    """Enhanced Difference Morphological Filter, equations (5)-(11) of Yu et al.

    The default structural element is flat. A non-flat element can be supplied
    explicitly for machine-specific calibration.
    """
    x = finite_array(values)
    if structure is None:
        m = int(structure_length)
        if m < 2:
            raise ValueError("structure_length must be at least 2")
        if m % 2 == 0:
            m += 1
        g = np.zeros(m, dtype=np.float64)
    else:
        g = np.asarray(structure, dtype=np.float64).reshape(-1)

    # CDE = closing -> dilation -> erosion
    cde = erosion(dilation(closing(x, g), g), g)
    # DCE = dilation -> closing -> erosion
    dce = erosion(closing(dilation(x, g), g), g)
    # EOD = erosion -> opening -> dilation
    eod = dilation(opening(erosion(x, g), g), g)
    # OED = opening -> erosion -> dilation
    oed = dilation(erosion(opening(x, g), g), g)

    cde_oed = (cde - oed) / 2.0
    dce_eod = (dce - eod) / 2.0
    return (dce_eod + cde_oed) / 2.0


def select_structure_length(values: Sequence[float] | np.ndarray, candidates: Sequence[int] = (3, 5, 7, 9, 11, 15, 21)) -> tuple[int, dict[int, float]]:
    x = finite_array(values)
    scores: dict[int, float] = {}
    for candidate in candidates:
        m = int(candidate)
        if m >= x.size // 4:
            continue
        y = edmf(x, structure_length=m)
        score = float(stats.kurtosis(y, fisher=False, bias=False, nan_policy="omit"))
        if np.isfinite(score):
            scores[m] = score
    if not scores:
        return 5, {5: float("nan")}
    best = max(scores, key=scores.get)
    return int(best), scores
