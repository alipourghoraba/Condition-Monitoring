from __future__ import annotations

import math
from typing import Any, Mapping


def bearing_fault_frequencies(*, rotational_hz: float, rolling_elements: int, ball_diameter_mm: float, pitch_diameter_mm: float, contact_angle_deg: float = 0.0) -> dict[str, float]:
    fr = float(rotational_hz)
    nb = int(rolling_elements)
    db = float(ball_diameter_mm)
    dp = float(pitch_diameter_mm)
    beta = math.radians(float(contact_angle_deg))
    if fr <= 0 or nb <= 0 or db <= 0 or dp <= 0 or db >= dp:
        raise ValueError("invalid bearing geometry or rotational speed")
    ratio = (db / dp) * math.cos(beta)
    return {
        "shaft_rotation_hz": fr,
        "ftf_cage_hz": 0.5 * fr * (1.0 - ratio),
        "bpfo_outer_race_hz": 0.5 * nb * fr * (1.0 - ratio),
        "bpfi_inner_race_hz": 0.5 * nb * fr * (1.0 + ratio),
        "bsf_rolling_element_hz": (dp / (2.0 * db)) * fr * (1.0 - ratio * ratio),
    }


def brb_vibration_frequencies(*, rotational_hz: float, synchronous_hz: float, poles: int, max_order: int = 3) -> list[float]:
    fr = float(rotational_hz)
    fsyn = float(synchronous_hz)
    p = int(poles)
    if fr <= 0 or fsyn <= 0 or p <= 0:
        return []
    rows = []
    for k in range(1, max_order + 1):
        rows.extend([fr - k * (fsyn - fr) * p, fr + k * (fsyn - fr) * p])
    return sorted({float(v) for v in rows if v > 0})


def gear_frequencies(*, input_shaft_hz: float, stages: list[Mapping[str, Any]]) -> dict[str, float]:
    current = float(input_shaft_hz)
    result: dict[str, float] = {"input_shaft_hz": current}
    for i, stage in enumerate(stages, start=1):
        driver = int(stage["driver_teeth"])
        driven = int(stage["driven_teeth"])
        if driver <= 0 or driven <= 0:
            raise ValueError("gear tooth counts must be positive")
        mesh = current * driver
        output = current * driver / driven
        result[f"stage_{i}_input_shaft_hz"] = current
        result[f"stage_{i}_mesh_hz"] = mesh
        result[f"stage_{i}_output_shaft_hz"] = output
        current = output
    result["output_shaft_hz"] = current
    return result


def resolve_rotational_hz(metadata: Mapping[str, Any]) -> float | None:
    mechanics = metadata.get("mechanical") or metadata.get("machinery") or {}
    for key in ("rotational_frequency_hz", "shaft_frequency_hz", "rotation_hz"):
        if mechanics.get(key) is not None:
            return float(mechanics[key])
    for key in ("speed_rpm", "shaft_speed_rpm", "rated_speed_rpm"):
        if mechanics.get(key) is not None:
            return float(mechanics[key]) / 60.0
    return None


def resolve_bearing_geometry(metadata: Mapping[str, Any]) -> dict[str, Any] | None:
    mechanics = metadata.get("mechanical") or metadata.get("machinery") or {}
    bearing = mechanics.get("bearing") or metadata.get("bearing")
    if not isinstance(bearing, Mapping):
        return None
    required = ("rolling_elements", "ball_diameter_mm", "pitch_diameter_mm")
    if any(bearing.get(k) is None for k in required):
        return None
    return dict(bearing)
