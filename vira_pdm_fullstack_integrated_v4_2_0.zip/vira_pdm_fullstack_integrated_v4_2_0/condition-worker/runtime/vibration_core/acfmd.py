from __future__ import annotations

from typing import Sequence

import numpy as np
from scipy import signal

from .common import EPS, finite_array


def angular_weighted_ics2(mode: np.ndarray, phase_rad: np.ndarray, orders: Sequence[int] = (1, 2, 3, 4, 5)) -> float:
    x = np.asarray(mode, dtype=np.float64)
    phase = np.asarray(phase_rad, dtype=np.float64)
    x = x[: min(x.size, phase.size)]
    phase = phase[: x.size]
    energy = float(np.mean(x * x)) + EPS
    score = 0.0
    x2 = x * x
    for order in orders:
        cyclic = np.mean(x2 * np.exp(-1j * order * phase))
        score += float(abs(cyclic) ** 2)
    return score / (energy * energy)


def encoder_to_phase_and_ias(encoder_values: Sequence[float] | np.ndarray, fs: float, *, counts_per_revolution: float | None = None, input_is_phase: bool = True) -> tuple[np.ndarray, np.ndarray]:
    raw = finite_array(encoder_values)
    if input_is_phase:
        phase = np.unwrap(raw)
    else:
        if not counts_per_revolution or counts_per_revolution <= 0:
            raise ValueError("counts_per_revolution is required for count input")
        phase = np.unwrap(raw * 2.0 * np.pi / counts_per_revolution)
    ias = np.gradient(phase) * fs / (2.0 * np.pi)
    return phase, ias


def acfmd(values: Sequence[float] | np.ndarray, phase_rad: Sequence[float] | np.ndarray, fs: float, *, initial_filters: int = 8, target_modes: int = 3, filter_length: int = 63) -> dict[str, object]:
    """Angular-domain cyclostationary FMD for encoder/IAS measurements.

    A multi-FIR bank supplies decomposition directions. Candidate modes are
    ranked by angular-weighted ICS2 and redundant highly-correlated modes are
    removed, mirroring the update/selection framework in the paper.
    """
    x = finite_array(values)
    phase = finite_array(phase_rad)
    n = min(x.size, phase.size)
    x, phase = x[:n], phase[:n]
    nyq = fs / 2.0
    centers = np.linspace(0.03 * nyq, 0.95 * nyq, int(initial_filters))
    bandwidth = max(0.04 * nyq, nyq / max(initial_filters, 2))
    modes: list[np.ndarray] = []
    filters: list[np.ndarray] = []
    for center in centers:
        low = max(0.005 * nyq, center - bandwidth / 2)
        high = min(0.995 * nyq, center + bandwidth / 2)
        taps = signal.firwin(filter_length, [low / nyq, high / nyq], pass_zero=False)
        modes.append(signal.fftconvolve(x, taps, mode="same"))
        filters.append(taps)

    while len(modes) > target_modes:
        corr = np.corrcoef(modes)
        np.fill_diagonal(corr, 0.0)
        i, j = np.unravel_index(np.argmax(np.abs(corr)), corr.shape)
        si = angular_weighted_ics2(modes[i], phase)
        sj = angular_weighted_ics2(modes[j], phase)
        remove = j if si >= sj else i
        modes.pop(remove)
        filters.pop(remove)

    scores = [angular_weighted_ics2(mode, phase) for mode in modes]
    best = int(np.argmax(scores))
    env = np.abs(signal.hilbert(modes[best] - np.mean(modes[best])))
    # Order spectrum without interpolation: project envelope onto exp(-j*k*phase).
    orders = np.linspace(0.0, 20.0, 1001)
    order_amp = np.array([abs(np.mean((env - np.mean(env)) * np.exp(-1j * order * phase))) for order in orders])
    return {
        "modes": [mode.astype(float).tolist() for mode in modes],
        "filters": [f.astype(float).tolist() for f in filters],
        "angular_weighted_ics2": [float(v) for v in scores],
        "selected_mode": best,
        "order_axis": orders.astype(float).tolist(),
        "envelope_order_spectrum": order_amp.astype(float).tolist(),
        "peak_order": float(orders[int(np.argmax(order_amp[1:]) + 1)]),
    }
