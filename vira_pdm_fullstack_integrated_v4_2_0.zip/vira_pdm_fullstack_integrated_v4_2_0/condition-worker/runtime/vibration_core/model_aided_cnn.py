from __future__ import annotations

"""Signal-agnostic numerical-model-aided CNN utilities.

The cited numerical-model-aided method validates a healthy numerical model
against healthy measurements using cosine similarity, iteratively updates the
model until the absolute correlation exceeds 0.7, injects fault models to build
otherwise unavailable classes, and then trains a compact 1-D CNN.  This module
implements the validation and CNN portions.  The actual electromagnetic or
multiphysics simulator remains an external engineering model and is never
silently replaced by synthetic noise.
"""

from dataclasses import dataclass
from typing import Any

import numpy as np


EPS = np.finfo(np.float64).eps


def finite_vector(values: np.ndarray) -> np.ndarray:
    x = np.asarray(values, dtype=np.float64).reshape(-1)
    x = x[np.isfinite(x)]
    if x.size < 16:
        raise ValueError("signal must contain at least 16 finite samples")
    return x


def resample_equal_length(a: np.ndarray, b: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Interpolate the longer/shorter vector onto one normalized time base."""
    x = finite_vector(a)
    y = finite_vector(b)
    n = min(max(x.size, y.size), 200_000)
    grid = np.linspace(0.0, 1.0, n, endpoint=False)
    xg = np.interp(grid, np.linspace(0.0, 1.0, x.size, endpoint=False), x)
    yg = np.interp(grid, np.linspace(0.0, 1.0, y.size, endpoint=False), y)
    return xg, yg


def cosine_similarity(measured: np.ndarray, simulated: np.ndarray, *, remove_mean: bool = True) -> float:
    """Cosine similarity used to accept or reject the healthy model.

    Mean removal prevents a common DC offset from dominating the validation.
    The paper's acceptance rule is ``abs(r) > 0.7``.
    """
    x, y = resample_equal_length(measured, simulated)
    if remove_mean:
        x = x - np.mean(x)
        y = y - np.mean(y)
    denominator = float(np.linalg.norm(x) * np.linalg.norm(y))
    if denominator <= EPS:
        raise ValueError("cosine similarity is undefined for a zero-energy signal")
    return float(np.dot(x, y) / denominator)


def estimate_additive_noise(measured: np.ndarray, simulated: np.ndarray) -> dict[str, float]:
    """Estimate white-noise mean/variance after aligning healthy signals."""
    x, y = resample_equal_length(measured, simulated)
    residual = x - y
    return {
        "mean": float(np.mean(residual)),
        "variance": float(np.var(residual, ddof=1)) if residual.size > 1 else 0.0,
        "standard_deviation": float(np.std(residual, ddof=1)) if residual.size > 1 else 0.0,
        "rmse": float(np.sqrt(np.mean(residual * residual))),
    }


@dataclass(frozen=True)
class HealthyModelValidation:
    similarity: float
    absolute_similarity: float
    threshold: float
    accepted: bool
    noise: dict[str, float]

    def to_dict(self) -> dict[str, Any]:
        return {
            "similarity": self.similarity,
            "absolute_similarity": self.absolute_similarity,
            "threshold": self.threshold,
            "accepted": self.accepted,
            "noise": self.noise,
        }


def validate_healthy_model(
    measured: np.ndarray,
    simulated: np.ndarray,
    *,
    threshold: float = 0.7,
) -> HealthyModelValidation:
    if not 0.0 < threshold <= 1.0:
        raise ValueError("threshold must be in (0, 1]")
    r = cosine_similarity(measured, simulated)
    return HealthyModelValidation(
        similarity=r,
        absolute_similarity=abs(r),
        threshold=float(threshold),
        accepted=bool(abs(r) > threshold),
        noise=estimate_additive_noise(measured, simulated),
    )


def build_model(num_classes: int, sequence_length: int):
    """Build the compact 1-D CNN reported for numerical-model-aided diagnosis.

    PyTorch is imported lazily so deterministic vibration-only processing does
    not require the deep-learning dependency.
    """
    if num_classes < 2:
        raise ValueError("num_classes must be at least 2")
    if sequence_length < 128:
        raise ValueError("sequence_length must be at least 128")
    try:
        import torch
        from torch import nn
    except ImportError as exc:  # pragma: no cover - dependency gate
        raise RuntimeError("PyTorch is required; install requirements-vibration-ml.txt") from exc

    class NumericalModelAidedCNN(nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.features = nn.Sequential(
                nn.Conv1d(1, 8, kernel_size=7, stride=2, padding=3),
                nn.BatchNorm1d(8),
                nn.ReLU(inplace=True),
                nn.MaxPool1d(kernel_size=3, stride=2, padding=1),
                nn.Conv1d(8, 32, kernel_size=5, stride=1, padding=2),
                nn.BatchNorm1d(32),
                nn.ReLU(inplace=True),
                nn.MaxPool1d(kernel_size=3, stride=2, padding=1),
                nn.Conv1d(32, 64, kernel_size=3, stride=1, padding=1),
                nn.BatchNorm1d(64),
                nn.ReLU(inplace=True),
                nn.MaxPool1d(kernel_size=3, stride=2, padding=1),
                nn.Conv1d(64, 128, kernel_size=3, stride=1, padding=1),
                nn.BatchNorm1d(128),
                nn.ReLU(inplace=True),
                nn.MaxPool1d(kernel_size=3, stride=2, padding=1),
            )
            with torch.no_grad():
                flattened = int(self.features(torch.zeros(1, 1, sequence_length)).numel())
            self.classifier = nn.Sequential(
                nn.Flatten(),
                nn.Linear(flattened, 256),
                nn.ReLU(inplace=True),
                nn.Dropout(0.5),
                nn.Linear(256, 64),
                nn.ReLU(inplace=True),
                nn.Dropout(0.3),
                nn.Linear(64, num_classes),
            )

        def forward(self, x):
            return self.classifier(self.features(x))

    return NumericalModelAidedCNN()
