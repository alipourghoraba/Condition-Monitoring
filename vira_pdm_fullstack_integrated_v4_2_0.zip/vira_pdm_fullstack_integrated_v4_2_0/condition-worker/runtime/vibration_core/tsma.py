from __future__ import annotations

import math
from typing import Sequence

import numpy as np

from .common import finite_array


def noise_gain(n_cycles: int, average_cycles: int) -> float:
    n = int(n_cycles)
    m = int(average_cycles)
    if not (1 <= m <= n):
        raise ValueError("average_cycles must be in [1, n_cycles]")
    if m <= (n + 1) / 2:
        return float((-4 * m * m + 3 * m * n + 3 * m + 1) / (3 * m * (n - m + 1)))
    return float((-4 * m * m - n * n + 5 * m * n - 2 * n + 5 * m) / (3 * m * m))


def optimize_average_cycles(n_cycles: int) -> tuple[int, dict[int, float]]:
    """Paper objective O[M] = 1/f + G, with normalized resolution f=N-M+1.

    The additive terms are made dimensionless by normalizing frequency
    resolution to the original N-cycle record.
    """
    n = int(n_cycles)
    if n < 2:
        return 1, {1: 1.0}
    objective: dict[int, float] = {}
    for m in range(1, n + 1):
        relative_resolution = max((n - m + 1) / n, 1e-12)
        objective[m] = float(1.0 / relative_resolution + noise_gain(n, m))
    return min(objective, key=objective.get), objective


def tsma(values: Sequence[float] | np.ndarray, samples_per_cycle: int, *, average_cycles: int | None = None) -> tuple[np.ndarray, dict[str, float]]:
    x = finite_array(values)
    p = int(samples_per_cycle)
    if p < 2:
        raise ValueError("samples_per_cycle must be >=2")
    n_cycles = x.size // p
    if n_cycles < 2:
        raise ValueError("at least two complete cycles are required")
    x = x[: n_cycles * p]
    cycles = x.reshape(n_cycles, p)
    if average_cycles is None:
        average_cycles, _ = optimize_average_cycles(n_cycles)
    m = int(average_cycles)
    if not (1 <= m <= n_cycles):
        raise ValueError("invalid average_cycles")

    # Moving average across neighboring cycles; output preserves periodicity.
    csum = np.vstack([np.zeros((1, p)), np.cumsum(cycles, axis=0)])
    averaged = (csum[m:] - csum[:-m]) / m
    out = averaged.reshape(-1)
    return out, {
        "samples_per_cycle": float(p),
        "input_cycles": float(n_cycles),
        "average_cycles": float(m),
        "output_cycles": float(n_cycles - m + 1),
        "noise_gain_bound": noise_gain(n_cycles, m),
        "relative_frequency_resolution": float((n_cycles - m + 1) / n_cycles),
    }
