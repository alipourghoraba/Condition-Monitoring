from __future__ import annotations

from typing import Sequence

import numpy as np
from scipy import optimize, signal, stats

from .common import EPS, envelope_spectrum, finite_array, harmonic_energy_ratio


def correlated_kurtosis(y: np.ndarray, period_samples: int, shifts: int = 1) -> float:
    y = np.asarray(y, dtype=np.float64)
    t = max(1, int(period_samples))
    m = max(1, int(shifts))
    product = np.ones_like(y)
    for shift in range(m + 1):
        shifted = np.zeros_like(y)
        offset = shift * t
        if offset < y.size:
            shifted[offset:] = y[: y.size - offset]
        product *= shifted
    numerator = float(np.sum(product * product))
    denominator = float(np.sum(y * y) ** (m + 1)) + EPS
    return numerator / denominator


def l_kurtosis(values: Sequence[float] | np.ndarray) -> float:
    y = np.sort(finite_array(values))
    n = y.size
    i = np.arange(1, n + 1, dtype=np.float64)
    c0 = np.ones(n)
    c1 = (i - 1) / max(n - 1, 1)
    c2 = ((i - 1) * (i - 2)) / max((n - 1) * (n - 2), 1)
    c3 = ((i - 1) * (i - 2) * (i - 3)) / max((n - 1) * (n - 2) * (n - 3), 1)
    a = 20 * c3 - 30 * c2 + 12 * c1 - c0
    d = 2 * c1 - c0
    return float(np.sum(a * y) / (np.sum(d * y) + EPS))


def envelope_spectrum_kurtosis(values: Sequence[float] | np.ndarray, fs: float) -> float:
    _, a, _ = envelope_spectrum(values, fs)
    return float(stats.kurtosis(a, fisher=False, bias=False, nan_policy="omit"))


def fmd_filter_bank(values: Sequence[float] | np.ndarray, fs: float, *, modes: int = 4, filter_length: int = 63) -> tuple[list[np.ndarray], dict[str, object]]:
    """Finite-impulse filter-bank implementation of the FMD decomposition frame.

    Candidate FIR modes cover the usable spectrum. Similar modes are pruned by
    correlation and the mode with larger correlated kurtosis is retained.
    """
    x = finite_array(values)
    nyq = fs / 2.0
    edges = np.linspace(0.01 * nyq, 0.98 * nyq, max(modes * 2 + 1, 5))
    candidates: list[np.ndarray] = []
    filters: list[np.ndarray] = []
    for i in range(len(edges) - 1):
        low, high = edges[i], edges[i + 1]
        taps = signal.firwin(filter_length, [low / nyq, high / nyq], pass_zero=False)
        mode = signal.fftconvolve(x, taps, mode="same")
        candidates.append(mode)
        filters.append(taps)
    while len(candidates) > modes:
        corr = np.corrcoef(candidates)
        np.fill_diagonal(corr, 0.0)
        i, j = np.unravel_index(np.argmax(np.abs(corr)), corr.shape)
        period_i = max(1, int(np.argmax(signal.correlate(np.abs(signal.hilbert(candidates[i])), np.abs(signal.hilbert(candidates[i])), mode="full")[candidates[i].size:]) + 1))
        period_j = max(1, int(np.argmax(signal.correlate(np.abs(signal.hilbert(candidates[j])), np.abs(signal.hilbert(candidates[j])), mode="full")[candidates[j].size:]) + 1))
        cki = correlated_kurtosis(candidates[i], period_i)
        ckj = correlated_kurtosis(candidates[j], period_j)
        remove = j if cki >= ckj else i
        candidates.pop(remove)
        filters.pop(remove)
    esk = [envelope_spectrum_kurtosis(m, fs) for m in candidates]
    threshold = 0.5 * max(esk) if esk else 0.0
    selected = [m for m, score in zip(candidates, esk) if score >= threshold]
    reconstructed = np.sum(selected, axis=0) if selected else np.sum(candidates, axis=0)
    return candidates, {
        "filters": [f.astype(float).tolist() for f in filters],
        "envelope_spectrum_kurtosis": [float(v) for v in esk],
        "selection_threshold": float(threshold),
        "selected_mode_count": len(selected),
        "reconstructed": reconstructed,
    }


def _convolution_matrix(x: np.ndarray, filter_length: int) -> np.ndarray:
    l = int(filter_length)
    padded = np.pad(x, (l - 1, 0))
    return np.vstack([padded[l - 1 - k : l - 1 - k + x.size] for k in range(l)]).T


def mck_lkd(values: Sequence[float] | np.ndarray, *, period_samples: int, filter_length: int = 50, shifts: int = 1, max_iterations: int = 30) -> tuple[np.ndarray, dict[str, object]]:
    x = finite_array(values)
    x = (x - np.mean(x)) / (np.std(x) + EPS)
    l = min(int(filter_length), max(4, x.size // 10))
    X = _convolution_matrix(x, l)
    f0 = np.zeros(l)
    f0[l // 2] = 1.0

    def objective(f: np.ndarray) -> float:
        norm = np.linalg.norm(f) + EPS
        y = X @ (f / norm)
        ck = correlated_kurtosis(y, period_samples, shifts)
        lk = abs(l_kurtosis(y))
        return -float(np.log(ck + EPS) + np.log(lk + EPS))

    result = optimize.minimize(objective, f0, method="Powell", options={"maxiter": int(max_iterations), "xtol": 1e-4, "ftol": 1e-4})
    f = result.x / (np.linalg.norm(result.x) + EPS)
    y = X @ f
    ck = correlated_kurtosis(y, period_samples, shifts)
    lk = l_kurtosis(y)
    return y, {
        "filter": f.astype(float).tolist(),
        "filter_length": int(l),
        "period_samples": int(period_samples),
        "shifts": int(shifts),
        "correlated_kurtosis": float(ck),
        "l_kurtosis": float(lk),
        "combined_objective": float(ck * abs(lk)),
        "optimizer_success": bool(result.success),
        "optimizer_message": str(result.message),
        "iterations": int(getattr(result, "nit", 0)),
    }


def fmd_mck_lkd_pipeline(values: Sequence[float] | np.ndarray, fs: float, *, target_frequency_hz: float, modes: int = 4, filter_length: int = 50, shifts: int = 1) -> tuple[np.ndarray, dict[str, object]]:
    modes_out, fmd_info = fmd_filter_bank(values, fs, modes=modes)
    reconstructed = np.asarray(fmd_info.pop("reconstructed"), dtype=np.float64)
    period = max(1, int(round(fs / target_frequency_hz)))
    y, mck_info = mck_lkd(reconstructed, period_samples=period, filter_length=filter_length, shifts=shifts)
    ef, ea, _ = envelope_spectrum(y, fs)
    ratio = harmonic_energy_ratio(ef, ea, target_frequency_hz, harmonics=4)
    return y, {"fmd": fmd_info, "mck_lkd": mck_info, "fault_harmonic_evidence": ratio}
