from __future__ import annotations

from typing import Sequence

import numpy as np
from scipy import signal
from sklearn.decomposition import FastICA, PCA

from .common import EPS, finite_array


def _imfs(values: np.ndarray, fs: float, max_imfs: int = 8) -> tuple[list[np.ndarray], str]:
    try:
        from PyEMD import EMD  # type: ignore
        result = EMD().emd(values, max_imf=max_imfs)
        return [np.asarray(row, dtype=np.float64) for row in result], "PyEMD"
    except Exception:
        # Deterministic fallback.  The report exposes that this is not EMD so a
        # deployment never mistakes the fallback for the paper's exact backend.
        nyq = fs / 2.0
        edges = np.geomspace(max(1.0, fs / values.size), nyq * 0.95, max_imfs + 1)
        rows: list[np.ndarray] = []
        for low, high in zip(edges[:-1], edges[1:]):
            if low >= high:
                continue
            sos = signal.butter(3, [low / nyq, high / nyq], btype="bandpass", output="sos")
            rows.append(signal.sosfiltfilt(sos, values))
        return rows, "logarithmic-filter-bank-fallback"


def _reference_signals(n: int, fs: float, bearing_hz: float | None, gear_hz: float | None) -> dict[str, np.ndarray]:
    t = np.arange(n, dtype=np.float64) / fs
    refs: dict[str, np.ndarray] = {}
    if bearing_hz and bearing_hz > 0:
        impulse_train = np.zeros(n, dtype=np.float64)
        period = max(1, int(round(fs / bearing_hz)))
        impulse_train[::period] = 1.0
        resonance = min(0.35 * fs, max(5.0 * bearing_hz, 1000.0))
        response_t = np.arange(max(16, int(0.02 * fs))) / fs
        response = np.exp(-300.0 * response_t) * np.sin(2 * np.pi * resonance * response_t)
        refs["bearing"] = signal.fftconvolve(impulse_train, response, mode="same")
    if gear_hz and gear_hz > 0:
        # Mesh carrier with shaft-order-like amplitude modulation.  The paper
        # uses simulated bearing/gear signatures to select relevant IMFs.
        modulation_hz = max(1.0, gear_hz / 20.0)
        refs["gear"] = (1.0 + 0.4 * np.cos(2 * np.pi * modulation_hz * t)) * np.cos(2 * np.pi * gear_hz * t)
    return refs


def _select_imfs(rows: list[np.ndarray], refs: dict[str, np.ndarray], top_per_fault: int = 3) -> tuple[list[np.ndarray], list[dict[str, float]]]:
    if not refs:
        return rows, [{"imf": float(i), "selection_score": 1.0} for i in range(len(rows))]
    selected: set[int] = set()
    diagnostics: list[dict[str, float]] = []
    per_ref_scores: dict[str, np.ndarray] = {}
    for name, reference in refs.items():
        scores = []
        ref = reference - np.mean(reference)
        ref_norm = np.linalg.norm(ref) + EPS
        for row in rows:
            centered = row - np.mean(row)
            scores.append(float(abs(np.dot(centered, ref)) / ((np.linalg.norm(centered) + EPS) * ref_norm)))
        array = np.asarray(scores)
        per_ref_scores[name] = array
        selected.update(np.argsort(array)[-min(top_per_fault, len(rows)):].tolist())
    for i in range(len(rows)):
        item: dict[str, float] = {"imf": float(i)}
        for name, scores in per_ref_scores.items():
            item[f"correlation_{name}"] = float(scores[i])
        item["selection_score"] = max((float(scores[i]) for scores in per_ref_scores.values()), default=0.0)
        diagnostics.append(item)
    indices = sorted(selected) or list(range(len(rows)))
    return [rows[i] for i in indices], diagnostics


def _marginal_hilbert_spectrum(imf: np.ndarray, fs: float, frequency_bins: int = 256, *, double_hilbert: bool = True) -> np.ndarray:
    # Li et al. first apply the Hilbert transform to each selected IMF and then
    # construct its Hilbert-Huang/marginal spectrum.  The first transform below
    # uses the quadrature component; the second builds the analytic signal used
    # for instantaneous frequency and amplitude.
    source = np.imag(signal.hilbert(imf)) if double_hilbert else imf
    analytic = signal.hilbert(source)
    amplitude = np.abs(analytic)
    phase = np.unwrap(np.angle(analytic))
    inst_freq = np.r_[np.diff(phase) * fs / (2 * np.pi), 0.0]
    valid = np.isfinite(inst_freq) & (inst_freq >= 0) & (inst_freq <= fs / 2)
    hist, _ = np.histogram(inst_freq[valid], bins=frequency_bins, range=(0, fs / 2), weights=amplitude[valid])
    return hist.astype(np.float64)


def compound_mhs_separation(
    values: Sequence[float] | np.ndarray,
    fs: float,
    *,
    bearing_frequency_hz: float | None = None,
    gear_mesh_frequency_hz: float | None = None,
    max_imfs: int = 8,
    components: int = 3,
) -> dict[str, object]:
    x = finite_array(values)
    rows, backend = _imfs(x, fs, max_imfs=max_imfs)
    if len(rows) < 2:
        raise RuntimeError("not enough IMF-like components for MHS separation")
    refs = _reference_signals(x.size, fs, bearing_frequency_hz, gear_mesh_frequency_hz)
    selected_rows, selection = _select_imfs(rows, refs)
    mhs = np.vstack([_marginal_hilbert_spectrum(row, fs, double_hilbert=True) for row in selected_rows])

    n_components = min(int(components), mhs.shape[0], mhs.shape[1])
    if n_components < 1:
        raise RuntimeError("MHS matrix does not contain a usable component")
    pca = PCA(n_components=n_components, random_state=42)
    reduced = pca.fit_transform(mhs.T)
    ica = FastICA(n_components=n_components, random_state=42, whiten="unit-variance", max_iter=1000, tol=1e-5)
    independent = ica.fit_transform(reduced).T
    freq = np.linspace(0.0, fs / 2.0, mhs.shape[1], endpoint=False)

    component_rows: list[dict[str, object]] = []
    for i, comp in enumerate(independent):
        magnitude = np.abs(comp)
        peak_idx = np.argsort(magnitude)[-10:][::-1]
        component_rows.append({
            "component": i,
            "spectrum": comp.astype(float).tolist(),
            "top_peaks": [{"frequency_hz": float(freq[j]), "amplitude": float(magnitude[j])} for j in peak_idx],
        })

    def evidence(target: float | None) -> dict[str, float] | None:
        if not target:
            return None
        best = {"component": -1.0, "amplitude": 0.0, "frequency_hz": float(target)}
        for i, comp in enumerate(independent):
            idx = int(np.argmin(np.abs(freq - target)))
            local = slice(max(0, idx - 2), min(freq.size, idx + 3))
            j = max(0, idx - 2) + int(np.argmax(np.abs(comp[local])))
            amp = float(abs(comp[j]))
            if amp > best["amplitude"]:
                best = {"component": float(i), "amplitude": amp, "frequency_hz": float(freq[j])}
        return best

    return {
        "decomposition_backend": backend,
        "original_imf_count": len(rows),
        "imf_count": len(selected_rows),
        "imf_selection": selection,
        "double_hilbert_transform": True,
        "mhs_matrix_shape": list(mhs.shape),
        "pca_explained_variance_ratio": pca.explained_variance_ratio_.astype(float).tolist(),
        "independent_components": component_rows,
        "bearing_evidence": evidence(bearing_frequency_hz),
        "gear_evidence": evidence(gear_mesh_frequency_hz),
    }
