from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
from scipy import signal, stats

EPS = 1e-12


def finite_array(values: Sequence[float] | np.ndarray) -> np.ndarray:
    x = np.asarray(values, dtype=np.float64).reshape(-1)
    if x.size == 0:
        raise ValueError("signal is empty")
    if not np.all(np.isfinite(x)):
        x = x[np.isfinite(x)]
    if x.size < 8:
        raise ValueError("signal has too few finite samples")
    return x


def preprocess(values: Sequence[float] | np.ndarray, *, detrend: bool = True, demean: bool = True) -> np.ndarray:
    x = finite_array(values)
    if detrend:
        x = signal.detrend(x, type="linear")
    elif demean:
        x = x - np.mean(x)
    return np.asarray(x, dtype=np.float64)


def rms(x: Sequence[float] | np.ndarray) -> float:
    a = np.asarray(x, dtype=np.float64)
    return float(np.sqrt(np.mean(a * a)))


def safe_ratio(a: float, b: float) -> float:
    return float(a / (b if abs(b) > EPS else EPS))


def time_features(values: Sequence[float] | np.ndarray) -> dict[str, float]:
    x = finite_array(values)
    ax = np.abs(x)
    xrms = rms(x)
    mean_abs = float(np.mean(ax))
    root_amp = float(np.mean(np.sqrt(ax + EPS)) ** 2)
    peak = float(np.max(ax))
    return {
        "mean": float(np.mean(x)),
        "std": float(np.std(x, ddof=1)) if x.size > 1 else 0.0,
        "rms": xrms,
        "peak": peak,
        "peak_to_peak": float(np.ptp(x)),
        "mean_abs": mean_abs,
        "variance": float(np.var(x, ddof=1)) if x.size > 1 else 0.0,
        "skewness": float(stats.skew(x, bias=False, nan_policy="omit")),
        "kurtosis": float(stats.kurtosis(x, fisher=False, bias=False, nan_policy="omit")),
        "crest_factor": safe_ratio(peak, xrms),
        "impulse_factor": safe_ratio(peak, mean_abs),
        "shape_factor": safe_ratio(xrms, mean_abs),
        "clearance_factor": safe_ratio(peak, root_amp),
        "zero_crossing_rate": float(np.mean(np.diff(np.signbit(x)).astype(np.float64))),
    }


def spectrum(values: Sequence[float] | np.ndarray, fs: float, *, window: str = "hann") -> tuple[np.ndarray, np.ndarray]:
    x = finite_array(values)
    if fs <= 0:
        raise ValueError("fs must be positive")
    win = signal.get_window(window, x.size, fftbins=True)
    coherent_gain = max(float(np.sum(win) / x.size), EPS)
    spec = np.fft.rfft(x * win)
    amp = 2.0 * np.abs(spec) / (x.size * coherent_gain)
    if amp.size:
        amp[0] *= 0.5
        if x.size % 2 == 0:
            amp[-1] *= 0.5
    freq = np.fft.rfftfreq(x.size, d=1.0 / fs)
    return freq, amp


def welch_psd(values: Sequence[float] | np.ndarray, fs: float, nperseg: int | None = None) -> tuple[np.ndarray, np.ndarray]:
    x = finite_array(values)
    nperseg = nperseg or min(4096, max(128, x.size // 8))
    nperseg = min(nperseg, x.size)
    f, p = signal.welch(x, fs=fs, window="hann", nperseg=nperseg, noverlap=nperseg // 2, scaling="density")
    return f.astype(float), p.astype(float)


def spectral_features(values: Sequence[float] | np.ndarray, fs: float) -> dict[str, float]:
    f, p = welch_psd(values, fs)
    total = float(np.sum(p)) + EPS
    centroid = float(np.sum(f * p) / total)
    spread = float(np.sqrt(np.sum(((f - centroid) ** 2) * p) / total))
    normalized = p / total
    entropy = float(-np.sum(normalized * np.log2(normalized + EPS)))
    peak_i = int(np.argmax(p))
    cumulative = np.cumsum(p) / total
    rolloff_i = int(np.searchsorted(cumulative, 0.95))
    return {
        "spectral_centroid_hz": centroid,
        "spectral_spread_hz": spread,
        "spectral_entropy": entropy,
        "spectral_peak_hz": float(f[peak_i]),
        "spectral_peak_psd": float(p[peak_i]),
        "spectral_rms_frequency_hz": float(np.sqrt(np.sum((f * f) * p) / total)),
        "spectral_rolloff_95_hz": float(f[min(rolloff_i, len(f) - 1)]),
    }


def analytic_envelope(values: Sequence[float] | np.ndarray) -> np.ndarray:
    x = finite_array(values)
    return np.abs(signal.hilbert(x))


def envelope_spectrum(values: Sequence[float] | np.ndarray, fs: float, *, band: tuple[float, float] | None = None) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    x = finite_array(values)
    if band is not None:
        low, high = band
        nyq = fs / 2.0
        low = max(0.1, float(low))
        high = min(float(high), nyq * 0.999)
        if not 0 < low < high < nyq:
            raise ValueError(f"invalid envelope band {band} for fs={fs}")
        sos = signal.butter(4, [low / nyq, high / nyq], btype="bandpass", output="sos")
        x = signal.sosfiltfilt(sos, x)
    env = analytic_envelope(x)
    env = env - np.mean(env)
    f, a = spectrum(env, fs)
    return f, a, env


def amplitude_near(freq: np.ndarray, amp: np.ndarray, target_hz: float, *, tolerance_hz: float | None = None) -> tuple[float, float]:
    if target_hz <= 0 or freq.size == 0:
        return 0.0, float(target_hz)
    if tolerance_hz is None:
        tolerance_hz = max(1.5 * (freq[1] - freq[0]) if freq.size > 1 else 1.0, 0.02 * target_hz)
    mask = np.abs(freq - target_hz) <= tolerance_hz
    if not np.any(mask):
        idx = int(np.argmin(np.abs(freq - target_hz)))
    else:
        indices = np.flatnonzero(mask)
        idx = int(indices[np.argmax(amp[indices])])
    return float(amp[idx]), float(freq[idx])


def harmonic_energy_ratio(freq: np.ndarray, amp: np.ndarray, fundamental_hz: float, *, harmonics: int = 5, upper_factor: float = 5.5) -> dict[str, Any]:
    fundamental_hz = float(fundamental_hz)
    if fundamental_hz <= 0:
        return {"ratio": 0.0, "harmonics": []}
    rows: list[dict[str, float]] = []
    numerator = 0.0
    for h in range(1, harmonics + 1):
        a, actual = amplitude_near(freq, amp, h * fundamental_hz)
        numerator += a * a
        rows.append({"order": h, "target_hz": h * fundamental_hz, "actual_hz": actual, "amplitude": a})
    mask = (freq >= 0) & (freq <= upper_factor * fundamental_hz)
    denominator = float(np.sum(amp[mask] ** 2)) + EPS
    return {"ratio": float(numerator / denominator), "harmonics": rows}


def band_energy(freq: np.ndarray, values: np.ndarray, low_hz: float, high_hz: float) -> float:
    mask = (freq >= low_hz) & (freq <= high_hz)
    if not np.any(mask):
        return 0.0
    return float(np.trapezoid(values[mask], freq[mask]))


def robust_z(value: float, median: float, mad: float) -> float:
    sigma = 1.4826 * max(abs(float(mad)), EPS)
    return float((value - median) / sigma)


def flatten_numeric(prefix: str, value: Any, output: dict[str, float]) -> None:
    if isinstance(value, Mapping):
        for k, v in value.items():
            flatten_numeric(f"{prefix}.{k}" if prefix else str(k), v, output)
    elif isinstance(value, (list, tuple)):
        for i, v in enumerate(value):
            flatten_numeric(f"{prefix}[{i}]", v, output)
    else:
        try:
            number = float(value)
        except (TypeError, ValueError):
            return
        if math.isfinite(number):
            output[prefix] = number


@dataclass(frozen=True)
class MethodResult:
    method: str
    status: str
    features: dict[str, Any]
    fault_evidence: list[dict[str, Any]]
    diagnostics: dict[str, Any]
    reason: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "method": self.method,
            "status": self.status,
            "reason": self.reason,
            "features": self.features,
            "fault_evidence": self.fault_evidence,
            "diagnostics": self.diagnostics,
        }
