from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

import joblib
import numpy as np


def load_supervised_artifact(path: str | Path) -> dict[str, Any]:
    artifact = joblib.load(Path(path))
    if not isinstance(artifact, dict) or "model" not in artifact or "feature_names" not in artifact:
        raise TypeError("invalid supervised vibration artifact")
    return artifact


def infer_supervised(features: Mapping[str, float], artifact_path: str | Path) -> dict[str, Any]:
    artifact = load_supervised_artifact(artifact_path)
    names = list(map(str, artifact["feature_names"]))
    missing = [name for name in names if name not in features]
    if missing:
        raise ValueError(f"supervised feature vector is missing: {missing[:10]}")
    x = np.asarray([[float(features[name]) for name in names]], dtype=np.float64)
    model = artifact["model"]
    label = model.predict(x)[0]
    result: dict[str, Any] = {
        "label": str(label),
        "model_name": str(artifact.get("model_name") or type(model).__name__),
        "model_version": str(artifact.get("version") or "1.0"),
        "model_path": str(Path(artifact_path).resolve()),
        "feature_count": len(names),
    }
    if hasattr(model, "predict_proba"):
        probabilities = model.predict_proba(x)[0]
        result["class_probabilities"] = {
            str(name): float(value) for name, value in zip(model.classes_, probabilities)
        }
        result["score"] = float(np.max(probabilities))
    elif hasattr(model, "decision_function"):
        decision = np.asarray(model.decision_function(x)).reshape(-1)
        result["decision_function"] = decision.astype(float).tolist()
        result["score"] = float(np.max(decision))
    return result
