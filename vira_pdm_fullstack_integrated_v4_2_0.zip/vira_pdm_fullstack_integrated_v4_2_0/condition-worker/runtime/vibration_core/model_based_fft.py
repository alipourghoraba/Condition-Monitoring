from __future__ import annotations

from typing import Any, Mapping, Sequence

import numpy as np

from .common import EPS, amplitude_near, envelope_spectrum, harmonic_energy_ratio, spectrum, time_features


def _normalized_amplitude(freq: np.ndarray, amp: np.ndarray, target: float, reference: float) -> tuple[float, float, float]:
    a, actual = amplitude_near(freq, amp, target)
    return a, actual, float(a / (reference + EPS))


def diagnose_spectral_patterns(values: Sequence[float] | np.ndarray, fs: float, *, rotational_hz: float | None, bearing_frequencies: Mapping[str, float] | None = None, gear_frequencies: Mapping[str, float] | None = None, axial_channel: bool = False) -> dict[str, Any]:
    freq, amp = spectrum(values, fs)
    tfeat = time_features(values)
    reference = float(np.max(amp[1:])) if amp.size > 1 else EPS
    evidence: list[dict[str, Any]] = []
    features: dict[str, Any] = dict(tfeat)

    if rotational_hz and rotational_hz > 0:
        a1, f1, r1 = _normalized_amplitude(freq, amp, rotational_hz, reference)
        a2, f2, r2 = _normalized_amplitude(freq, amp, 2 * rotational_hz, reference)
        a3, f3, r3 = _normalized_amplitude(freq, amp, 3 * rotational_hz, reference)
        features.update({"one_x_amplitude": a1, "one_x_frequency_hz": f1, "two_x_amplitude": a2, "two_x_frequency_hz": f2, "three_x_amplitude": a3, "two_x_to_one_x": float(a2 / (a1 + EPS))})
        # Betta et al.: unbalance high 1x; misalignment strong 2x and axial response;
        # looseness manifests many harmonics/subharmonics.
        evidence.append({"fault_code": "VIB-UNBALANCE", "fault_name": "Rotor/shaft unbalance", "score": float(np.clip(r1, 0, 1)), "source_method": "FFT model patterns", "matched_frequency_hz": f1, "theoretical_frequency_hz": rotational_hz, "details": {"one_x_ratio_to_max": r1}})
        misalign_score = np.clip((a2 / (a1 + EPS)) / 1.5, 0, 1)
        if axial_channel:
            misalign_score = min(1.0, float(misalign_score) * 1.2)
        evidence.append({"fault_code": "VIB-MISALIGNMENT", "fault_name": "Shaft/coupling misalignment", "score": float(misalign_score), "source_method": "FFT model patterns", "matched_frequency_hz": f2, "theoretical_frequency_hz": 2 * rotational_hz, "details": {"two_x_to_one_x": float(a2 / (a1 + EPS)), "axial_channel": axial_channel}})
        orders = harmonic_energy_ratio(freq, amp, rotational_hz, harmonics=8)
        features["rotation_harmonic_energy_ratio"] = orders["ratio"]
        evidence.append({"fault_code": "VIB-LOOSENESS", "fault_name": "Mechanical looseness", "score": float(np.clip(orders["ratio"] * 3.0, 0, 1)), "source_method": "FFT model patterns", "matched_frequency_hz": rotational_hz, "theoretical_frequency_hz": rotational_hz, "details": orders})

    if bearing_frequencies:
        try:
            ef, ea, _ = envelope_spectrum(values, fs)
        except Exception:
            ef, ea = freq, amp
        for key, target in bearing_frequencies.items():
            if key == "shaft_rotation_hz":
                continue
            ratio = harmonic_energy_ratio(ef, ea, float(target), harmonics=4)
            fault_code = {
                "bpfo_outer_race_hz": "VIB-BEARING-OUTER",
                "bpfi_inner_race_hz": "VIB-BEARING-INNER",
                "bsf_rolling_element_hz": "VIB-BEARING-BALL",
                "ftf_cage_hz": "VIB-BEARING-CAGE",
            }.get(key, f"VIB-{key.upper()}")
            evidence.append({"fault_code": fault_code, "fault_name": key.replace("_hz", "").replace("_", " ").title(), "score": float(np.clip(ratio["ratio"] * 5.0, 0, 1)), "source_method": "Envelope spectrum", "matched_frequency_hz": ratio["harmonics"][0]["actual_hz"], "theoretical_frequency_hz": float(target), "details": ratio})
            features[f"{key}.harmonic_energy_ratio"] = ratio["ratio"]

    if gear_frequencies:
        for key, target in gear_frequencies.items():
            if not key.endswith("mesh_hz"):
                continue
            mesh_amp, mesh_actual = amplitude_near(freq, amp, float(target))
            sideband_rows = []
            sideband_energy = 0.0
            shaft = rotational_hz or gear_frequencies.get(key.replace("mesh_hz", "input_shaft_hz")) or gear_frequencies.get("input_shaft_hz")
            if shaft:
                for order in range(1, 4):
                    for sign in (-1, 1):
                        target_sb = float(target) + sign * order * float(shaft)
                        a, actual = amplitude_near(freq, amp, target_sb)
                        sideband_energy += a * a
                        sideband_rows.append({"order": sign * order, "target_hz": target_sb, "actual_hz": actual, "amplitude": a})
            score = sideband_energy / (mesh_amp * mesh_amp + sideband_energy + EPS)
            features[f"{key}.mesh_amplitude"] = mesh_amp
            features[f"{key}.sideband_ratio"] = score
            evidence.append({"fault_code": "VIB-GEAR-FAULT", "fault_name": "Gear mesh modulation / local tooth fault", "score": float(np.clip(score, 0, 1)), "source_method": "Gear mesh sideband analysis", "matched_frequency_hz": mesh_actual, "theoretical_frequency_hz": float(target), "details": {"mesh_amplitude": mesh_amp, "sidebands": sideband_rows}})

    return {"features": features, "fault_evidence": evidence, "frequency_axis_hz": freq.astype(float).tolist(), "amplitude_spectrum": amp.astype(float).tolist()}
