from __future__ import annotations

from typing import Callable, Sequence

import numpy as np
from scipy import signal

from .common import EPS, amplitude_near, finite_array, spectrum


def potential_force(x: np.ndarray | float, *, a: float, b: float, xc: float, k: float) -> np.ndarray:
    z = np.asarray(x, dtype=np.float64)
    force = np.empty_like(z)
    inside = np.abs(z) <= xc
    force[inside] = a * z[inside] - b * z[inside] ** 3
    force[z > xc] = -k
    force[z < -xc] = k
    return force


def run_piecewise_sr(values: Sequence[float] | np.ndarray, *, dt: float, a: float, b: float, xc: float, k: float, scale_ratio: float = 1.0) -> np.ndarray:
    u = finite_array(values)
    ratio = max(float(scale_ratio), EPS)
    h = float(dt) / ratio
    y = np.zeros_like(u)
    for i in range(1, u.size):
        y[i] = y[i - 1] + h * (potential_force(y[i - 1], a=a, b=b, xc=xc, k=k) + u[i - 1])
        if not np.isfinite(y[i]) or abs(y[i]) > 1e8:
            y[i:] = 0.0
            break
    return y


def modified_snr(values: Sequence[float] | np.ndarray, fs: float, target_hz: float) -> float:
    f, a = spectrum(values, fs)
    ad, _ = amplitude_near(f, a, target_hz)
    if a.size <= 2:
        return -1e9
    idx_target = int(np.argmin(np.abs(f - target_hz)))
    others = np.delete(a, idx_target)
    second = float(np.max(others)) + EPS
    total_other = float(np.sum(others)) + EPS
    # Paper Eq. (12): (Ad/As) * [Ad/(sum(Ai)-Ad)] * N/2.
    # For an rFFT, N/2 equals len(spectrum)-1 for an even-length record.
    half_record = max(1.0, float(len(a) - 1))
    metric = (ad / second) * (ad / total_other) * half_record
    return float(10.0 * np.log10(metric + EPS))


def _pso(objective: Callable[[np.ndarray], float], bounds: np.ndarray, *, particles: int = 18, iterations: int = 20, seed: int = 42) -> tuple[np.ndarray, float]:
    rng = np.random.default_rng(seed)
    low, high = bounds[:, 0], bounds[:, 1]
    x = rng.uniform(low, high, size=(particles, len(low)))
    v = np.zeros_like(x)
    pbest = x.copy()
    pscore = np.array([objective(row) for row in x])
    gidx = int(np.argmax(pscore))
    gbest, gscore = pbest[gidx].copy(), float(pscore[gidx])
    for _ in range(iterations):
        r1 = rng.random(x.shape)
        r2 = rng.random(x.shape)
        v = 0.72 * v + 1.49 * r1 * (pbest - x) + 1.49 * r2 * (gbest - x)
        x = np.clip(x + v, low, high)
        score = np.array([objective(row) for row in x])
        improve = score > pscore
        pbest[improve] = x[improve]
        pscore[improve] = score[improve]
        idx = int(np.argmax(pscore))
        if pscore[idx] > gscore:
            gbest, gscore = pbest[idx].copy(), float(pscore[idx])
    return gbest, gscore


def adaptive_stochastic_resonance(values: Sequence[float] | np.ndarray, fs: float, *, target_hz: float, particles: int = 16, iterations: int = 15, max_samples: int = 12000) -> tuple[np.ndarray, dict[str, object]]:
    x = finite_array(values)
    if x.size > max_samples:
        dec = int(np.ceil(x.size / max_samples))
        x = signal.decimate(x, dec, ftype="fir", zero_phase=True)
        fs_eff = fs / dec
    else:
        fs_eff = float(fs)
    env = np.abs(signal.hilbert(x - np.mean(x)))
    env = (env - np.mean(env)) / (np.std(env) + EPS)
    bounds = np.array([
        [0.05, 2.0],   # a
        [0.05, 2.0],   # b
        [0.25, 2.5],   # xc
        [0.01, 2.0],   # k
        [1.0, 100.0],  # scale ratio
    ], dtype=float)

    def objective(params: np.ndarray) -> float:
        a, b, xc, k, ratio = params
        y = run_piecewise_sr(env, dt=1.0 / fs_eff, a=a, b=b, xc=xc, k=k, scale_ratio=ratio)
        return modified_snr(y, fs_eff, target_hz)

    best, score = _pso(objective, bounds, particles=particles, iterations=iterations)
    a, b, xc, k, ratio = map(float, best)
    y = run_piecewise_sr(env, dt=1.0 / fs_eff, a=a, b=b, xc=xc, k=k, scale_ratio=ratio)
    return y, {
        "parameters": {"a": a, "b": b, "xc": xc, "k": k, "scale_ratio": ratio},
        "modified_snr_db": float(score),
        "effective_sample_rate_hz": float(fs_eff),
        "target_frequency_hz": float(target_hz),
        "particles": int(particles),
        "iterations": int(iterations),
    }
