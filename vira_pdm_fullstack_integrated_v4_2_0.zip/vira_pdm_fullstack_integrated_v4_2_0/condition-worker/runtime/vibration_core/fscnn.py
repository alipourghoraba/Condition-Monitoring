from __future__ import annotations

from pathlib import Path
from typing import Any, Sequence

import json
import numpy as np

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
except Exception:  # pragma: no cover - optional dependency
    torch = None
    nn = object
    F = None


if torch is not None:
    class FrequencyScaledKernel(nn.Module):
        """Real Morlet-derived frequency-scaled trainable kernel, paper Eq. (9)."""
        def __init__(self, channels: int = 6, length: int = 25, omega0: float = 2.0, sigma: float = 0.5):
            super().__init__()
            self.channels = int(channels)
            self.length = int(length)
            self.omega0 = float(omega0)
            self.sigma = float(sigma)
            initial = torch.arange(1, channels + 1, dtype=torch.float32) / channels
            self.scale = nn.Parameter(initial)

        def forward(self) -> torch.Tensor:
            z = torch.linspace(-2.0 * torch.pi, 2.0 * torch.pi, self.length, device=self.scale.device)
            s = torch.clamp(self.scale, 0.01, 16.0).unsqueeze(1)
            kernel = torch.exp(-((z.unsqueeze(0) * s / self.sigma) ** 2))
            kernel = kernel * torch.cos(2.0 * torch.pi * self.omega0 * z.unsqueeze(0) * s)
            kernel = kernel / (torch.sqrt(torch.tensor(torch.pi, device=z.device)) * self.sigma)
            return kernel.unsqueeze(1)


    class ConvBlock1D(nn.Module):
        def __init__(self, in_channels: int, out_channels: int, kernel_size: int = 5, stride: int = 1, padding: int = 2):
            super().__init__()
            self.conv = nn.Conv1d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, bias=False)
            self.bn = nn.BatchNorm1d(out_channels)

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            return self.bn(self.conv(x))


    class PartiallyConnected2DLinear(nn.Module):
        """Paper Eq. (17): weights connect frequency/channel dimension to classes."""
        def __init__(self, classes: int, feature_channels: int):
            super().__init__()
            self.weight = nn.Parameter(torch.empty(feature_channels, classes))
            nn.init.xavier_uniform_(self.weight)
            self.bias = nn.Parameter(torch.zeros(classes))

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            # x: batch x 1 x time x feature_channels. Sum time and input channel,
            # then apply only feature_channels x classes weights.
            collapsed = x.sum(dim=(1, 2))
            return collapsed @ self.weight + self.bias


    class FSCNN(nn.Module):
        def __init__(self, classes: int, *, case_study: str = "CWRU"):
            super().__init__()
            if case_study.upper() == "ITSC":
                kernel_length, channel_h, pc_features = 50, 8, 6
            else:
                kernel_length, channel_h, pc_features = 25, 16, 14
            self.classes = int(classes)
            self.case_study = case_study
            self.frequency_kernel = FrequencyScaledKernel(6, kernel_length, omega0=2.0, sigma=0.5)
            self.bn0 = nn.BatchNorm1d(6)
            self.conv1 = ConvBlock1D(6, channel_h, kernel_size=5, stride=2)
            self.pool1 = nn.MaxPool1d(3, stride=2)
            self.conv2 = ConvBlock1D(channel_h, channel_h, kernel_size=5, stride=1, padding=2)
            self.pool2 = nn.MaxPool1d(5, stride=4, padding=2)
            self.conv2d = nn.Conv2d(1, 1, kernel_size=(3, 3), stride=(1, 2))
            self.pc_features = pc_features
            self.classifier = PartiallyConnected2DLinear(classes, pc_features)

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            if x.ndim == 2:
                x = x.unsqueeze(1)
            x = x.float()
            kernels = self.frequency_kernel()
            x = F.conv1d(x, kernels, stride=8)
            x = self.bn0(x)
            x = self.pool1(F.relu(self.conv1(x)))
            x = self.pool2(F.relu(self.conv2(x)))
            x = F.relu(self.conv2d(x.unsqueeze(1)))
            x = x.transpose(2, 3)
            # Preserve the paper's partially-connected width. Adaptive pooling
            # makes deployment robust to input-window length while retaining the
            # same classifier parameterization.
            x = F.adaptive_avg_pool2d(x, (max(1, x.shape[2]), self.pc_features))
            return self.classifier(x)


    def build_model(classes: int, case_study: str = "CWRU") -> FSCNN:
        return FSCNN(classes, case_study=case_study)
else:
    class FSCNN:  # type: ignore
        pass

    def build_model(classes: int, case_study: str = "CWRU"):
        raise ImportError("PyTorch is required for FSCNN")


def load_model(model_path: str | Path, *, labels_path: str | Path | None = None, device: str = "cpu") -> tuple[Any, list[str]]:
    if torch is None:
        raise ImportError("PyTorch is required for FSCNN")
    checkpoint = torch.load(Path(model_path), map_location=device, weights_only=False)
    labels = checkpoint.get("labels") if isinstance(checkpoint, dict) else None
    if labels_path:
        labels = json.loads(Path(labels_path).read_text(encoding="utf-8"))
    if not labels:
        raise ValueError("FSCNN checkpoint must contain labels or labels_path must be provided")
    case_study = checkpoint.get("case_study", "CWRU") if isinstance(checkpoint, dict) else "CWRU"
    model = build_model(len(labels), case_study=case_study)
    state = checkpoint.get("state_dict", checkpoint) if isinstance(checkpoint, dict) else checkpoint
    model.load_state_dict(state)
    model.to(device).eval()
    return model, list(map(str, labels))


def infer(values: Sequence[float] | np.ndarray, model_path: str | Path, *, labels_path: str | Path | None = None, device: str = "cpu") -> dict[str, Any]:
    if torch is None:
        raise ImportError("PyTorch is required for FSCNN")
    model, labels = load_model(model_path, labels_path=labels_path, device=device)
    x = np.asarray(values, dtype=np.float32).reshape(-1)
    x = (x - np.mean(x)) / (np.std(x) + 1e-12)
    with torch.no_grad():
        logits = model(torch.from_numpy(x).reshape(1, 1, -1).to(device))
        probabilities = torch.softmax(logits, dim=1).cpu().numpy()[0]
    idx = int(np.argmax(probabilities))
    return {
        "label": labels[idx],
        "score": float(probabilities[idx]),
        "class_scores": {label: float(score) for label, score in zip(labels, probabilities)},
        "model_path": str(Path(model_path).resolve()),
    }
