from __future__ import annotations

from typing import Sequence

import numpy as np
from scipy import signal, stats

from .common import EPS, finite_array


def soft_threshold(x: np.ndarray, threshold: float) -> np.ndarray:
    a = np.asarray(x, dtype=np.float64)
    t = max(float(threshold), 0.0)
    return np.sign(a) * np.maximum(np.abs(a) - t, 0.0)


def adaptive_k_sparse_lasso(values: Sequence[float] | np.ndarray, *, keep_fraction: float = 0.05, step_size: float = 0.8, iterations: int = 20) -> tuple[np.ndarray, dict[str, float]]:
    """Adaptive k-sparsity Lasso following Table II of Sun et al.

    The adaptive threshold T=v_(k) is the order statistic that preserves the
    requested fraction of largest-magnitude coefficients at each FBS iteration.
    """
    y = finite_array(values)
    keep = float(np.clip(keep_fraction, 1.0 / y.size, 1.0))
    mu = float(np.clip(step_size, 1e-6, 1.999))
    x = y.copy()
    threshold = 0.0
    for _ in range(max(1, int(iterations))):
        v = x - mu * (x - y)
        kth = max(1, int(round(keep * v.size)))
        threshold = float(np.partition(np.abs(v), -kth)[-kth])
        x = soft_threshold(v, threshold)
    return x, {
        "keep_fraction": keep,
        "threshold": threshold,
        "nonzero_fraction": float(np.count_nonzero(x) / x.size),
        "iterations": float(iterations),
    }


def _toeplitz_signal_matrix(y: np.ndarray, filter_length: int) -> np.ndarray:
    n = y.size
    l = int(filter_length)
    if l < 2 or l >= n:
        raise ValueError("filter_length must be in [2, len(signal)-1]")
    padded = np.pad(y, (l - 1, 0))
    # Row l contains y[n-l], matching the paper's Y0 layout.
    return np.vstack([padded[l - 1 - shift : l - 1 - shift + n] for shift in range(l)])


def adalmed(values: Sequence[float] | np.ndarray, *, filter_length: int = 50, keep_fraction: float = 0.05, inner_lasso_iterations: int = 8, max_iterations: int = 30, tolerance: float = 1e-5, ridge: float = 1e-8) -> tuple[np.ndarray, dict[str, object]]:
    """Adaptive Lasso-based Minimum Entropy Deconvolution (AdaLMED).

    Implements the iteration in Table III: construct Y0 and A=Y0Y0^T,
    calculate x=Y0^T f, apply adaptive k-sparse Lasso, form b, and update
    f=A^-1 b until kurtosis convergence.
    """
    y = finite_array(values)
    y = y - np.mean(y)
    l = min(int(filter_length), max(3, y.size // 8))
    if l % 2:
        l += 1
    y0 = _toeplitz_signal_matrix(y, l)
    a = y0 @ y0.T + ridge * np.eye(l)
    f = np.zeros(l, dtype=np.float64)
    center = l // 2
    f[max(0, center - 1)] = 1.0
    f[center] = -1.0
    f /= np.linalg.norm(f) + EPS

    history: list[dict[str, float]] = []
    last_kurt = float("-inf")
    output = y0.T @ f
    for iteration in range(max(1, int(max_iterations))):
        output = y0.T @ f
        sparse, lasso_info = adaptive_k_sparse_lasso(
            output,
            keep_fraction=keep_fraction,
            iterations=inner_lasso_iterations,
        )
        sum2 = float(np.sum(sparse * sparse))
        sum4 = float(np.sum(sparse ** 4)) + EPS
        b = (sum2 / sum4) * (y0 @ (sparse ** 3))
        f_new = np.linalg.solve(a, b)
        norm = np.linalg.norm(f_new)
        if norm > EPS:
            f_new /= norm
        output_new = y0.T @ f_new
        kurt = float(stats.kurtosis(output_new, fisher=False, bias=False, nan_policy="omit"))
        history.append({
            "iteration": float(iteration + 1),
            "kurtosis": kurt,
            "threshold": float(lasso_info["threshold"]),
            "nonzero_fraction": float(lasso_info["nonzero_fraction"]),
        })
        f = f_new
        output = output_new
        if np.isfinite(last_kurt) and abs(kurt - last_kurt) < tolerance:
            break
        last_kurt = kurt

    envelope = np.abs(signal.hilbert(output - np.mean(output)))
    return output, {
        "filter": f.astype(float).tolist(),
        "filter_length": int(l),
        "iterations": len(history),
        "converged": len(history) < max_iterations,
        "output_kurtosis": float(stats.kurtosis(output, fisher=False, bias=False, nan_policy="omit")),
        "envelope_rms": float(np.sqrt(np.mean(envelope * envelope))),
        "history": history,
    }
