from __future__ import annotations

from typing import Sequence

import numpy as np
from scipy import signal

from .common import EPS, finite_array


def _top_frequency_initialization(x: np.ndarray, fs: float, q: int, max_hz: float | None = None) -> np.ndarray:
    analytic = signal.hilbert(x - np.mean(x))
    spec = np.abs(np.fft.fft(analytic))
    freq = np.fft.fftfreq(x.size, d=1.0 / fs)
    mask = (freq > 0) & (freq < (max_hz or fs / 2.0))
    candidates = np.flatnonzero(mask)
    if candidates.size == 0:
        return np.array([2 * np.pi * 1.0 / fs])
    distance = max(1, x.size // 200)
    peaks, _ = signal.find_peaks(spec[candidates], distance=distance)
    idx = candidates[peaks] if peaks.size else candidates
    idx = idx[np.argsort(spec[idx])[-q:]]
    return np.sort(2.0 * np.pi * freq[idx] / fs)


def _ar_prediction(theta: np.ndarray, history: np.ndarray) -> complex:
    roots = np.exp(1j * theta)
    coeff = np.poly(roots)  # [1, a1, ..., aq]
    return complex(-np.dot(coeff[1:], history[: theta.size]))


def _numeric_jacobian(theta: np.ndarray, history: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    h0 = _ar_prediction(theta, history)
    jac = np.empty(theta.size, dtype=np.complex128)
    for i in range(theta.size):
        t = theta.copy()
        t[i] += eps
        jac[i] = (_ar_prediction(t, history) - h0) / eps
    return jac


def ekf_condition_signal(values: Sequence[float] | np.ndarray, fs: float, *, dominant_components: int = 3, process_variance: float = 1e-7, observation_variance: float | None = None, initialization_samples: int | None = None) -> tuple[np.ndarray, dict[str, object]]:
    """EKF-based tracking and suppression of multiple dominant harmonics.

    The observation is the time-varying AR relation whose polynomial roots are
    exp(j*theta_i), following Algorithms 1-3 of Samanta et al.
    """
    x_real = finite_array(values)
    x = signal.hilbert(x_real - np.mean(x_real))
    q = max(1, min(int(dominant_components), 8, x.size // 20))
    init_n = min(x.size, int(initialization_samples or max(512, fs * 2)))
    theta = _top_frequency_initialization(x_real[:init_n], fs, q)
    initial_theta = theta.copy()
    q = theta.size
    p = np.eye(q) * 1e-3
    qmat = np.eye(q) * float(process_variance)
    if observation_variance is None:
        observation_variance = max(float(np.var(x_real)) * 1e-3, 1e-9)
    r = float(observation_variance)
    conditioned = np.zeros_like(x_real)
    estimates = np.zeros((x.size, q), dtype=np.float64)

    conditioned[:q] = x_real[:q]
    for n in range(q, x.size):
        p_pred = p + qmat
        history = x[n - 1 : n - q - 1 : -1]
        if history.size < q:
            conditioned[n] = x_real[n]
            continue
        pred = _ar_prediction(theta, history)
        h_complex = _numeric_jacobian(theta, history)
        # Real/imag stacked scalar observation yields a 2 x q Jacobian.
        h = np.vstack([h_complex.real, h_complex.imag])
        innovation = np.array([(x[n] - pred).real, (x[n] - pred).imag])
        s = h @ p_pred @ h.T + np.eye(2) * r
        k = p_pred @ h.T @ np.linalg.pinv(s)
        theta = theta + k @ innovation
        theta = np.mod(theta, 2.0 * np.pi)
        p = (np.eye(q) - k @ h) @ p_pred
        conditioned[n] = float((x[n] - pred).real)
        estimates[n] = theta

    frequency_tracks = estimates * fs / (2.0 * np.pi)
    return conditioned, {
        "dominant_components": int(q),
        "initial_frequencies_hz": (initial_theta * fs / (2.0 * np.pi)).astype(float).tolist(),
        "median_tracked_frequencies_hz": np.nanmedian(frequency_tracks[q:], axis=0).astype(float).tolist(),
        "process_variance": float(process_variance),
        "observation_variance": float(r),
    }


def rayleigh_quotient_spectrum(values: Sequence[float] | np.ndarray, fs: float, *, low_hz: float, high_hz: float, search_points: int = 512, lag_length: int = 128) -> dict[str, object]:
    x = finite_array(values)
    l = min(max(8, int(lag_length)), x.size // 3)
    windows = np.lib.stride_tricks.sliding_window_view(x, l)
    r = (windows.T @ windows) / max(1, windows.shape[0])
    freq = np.linspace(max(0.0, low_hz), min(high_hz, fs / 2.0), int(search_points))
    n = np.arange(l, dtype=np.float64)
    w = np.exp(1j * 2.0 * np.pi * freq[:, None] * n[None, :] / fs)
    rq = np.real(np.einsum("fi,ij,fj->f", np.conjugate(w), r, w)) / l
    idx = int(np.argmax(rq))
    amplitude = float(np.sqrt(max(rq[idx], 0.0) / l))
    return {
        "frequencies_hz": freq.astype(float).tolist(),
        "rayleigh_quotient": rq.astype(float).tolist(),
        "peak_frequency_hz": float(freq[idx]),
        "peak_amplitude": amplitude,
        "lag_length": int(l),
    }


def minimum_distance_test(values: Sequence[float] | np.ndarray, fs: float, *, frequency_hz: float, threshold_amplitude: float) -> dict[str, object]:
    x = finite_array(values)
    n = np.arange(x.size, dtype=np.float64)
    omega = 2.0 * np.pi * float(frequency_hz) / fs
    m = np.column_stack([np.cos(omega * n), np.sin(omega * n)])
    alpha = np.linalg.lstsq(m, x, rcond=None)[0]
    amplitude = float(np.linalg.norm(alpha))
    gamma = max(float(threshold_amplitude), 0.0)

    # Constrained ML solutions are radial projections onto the threshold circle.
    if amplitude > EPS:
        on_boundary = alpha * (gamma / amplitude)
    else:
        on_boundary = np.array([gamma, 0.0])
    alpha_h0 = alpha if amplitude < gamma else on_boundary
    alpha_h1 = alpha if amplitude >= gamma else on_boundary
    d0 = float(np.sum((x - m @ alpha_h0) ** 2))
    d1 = float(np.sum((x - m @ alpha_h1) ** 2))
    return {
        "frequency_hz": float(frequency_hz),
        "estimated_amplitude": amplitude,
        "threshold_amplitude": gamma,
        "distance_h0": d0,
        "distance_h1": d1,
        "fault_detected": bool(d1 < d0),
        "test_margin": float(d0 - d1),
        "alpha": alpha.astype(float).tolist(),
    }
