from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

import joblib
import numpy as np
from sklearn.mixture import BayesianGaussianMixture
from sklearn.preprocessing import StandardScaler

EPS = 1e-12


@dataclass
class DPMMArtifact:
    scaler: StandardScaler
    benchmark: BayesianGaussianMixture
    threshold: float
    feature_names: list[str]
    metadata: dict[str, Any]


def fit_dpmm(features: np.ndarray, *, max_components: int = 12, random_state: int = 42) -> tuple[StandardScaler, BayesianGaussianMixture]:
    x = np.asarray(features, dtype=np.float64)
    if x.ndim != 2 or x.shape[0] < 5:
        raise ValueError("DPMM requires at least five feature vectors")
    scaler = StandardScaler().fit(x)
    z = scaler.transform(x)
    model = BayesianGaussianMixture(
        n_components=min(max_components, max(2, x.shape[0] // 5)),
        weight_concentration_prior_type="dirichlet_process",
        covariance_type="full",
        reg_covar=1e-6,
        max_iter=1000,
        random_state=random_state,
    ).fit(z)
    return scaler, model


def monte_carlo_kl(p: BayesianGaussianMixture, q: BayesianGaussianMixture, *, samples: int = 4000, random_state: int = 42) -> float:
    x, _ = p.sample(int(samples))
    lp = p.score_samples(x)
    lq = q.score_samples(x)
    return float(np.mean(lp - lq))


def symmetric_kl(p: BayesianGaussianMixture, q: BayesianGaussianMixture, *, samples: int = 4000, random_state: int = 42) -> float:
    return float(0.5 * (monte_carlo_kl(p, q, samples=samples, random_state=random_state) + monte_carlo_kl(q, p, samples=samples, random_state=random_state + 1)))


def calibrate_dpmm(healthy_features: np.ndarray, *, feature_names: Sequence[str], threshold_quantile: float = 0.99, reference_window: int = 20, max_components: int = 12, random_state: int = 42) -> DPMMArtifact:
    x = np.asarray(healthy_features, dtype=np.float64)
    scaler, benchmark = fit_dpmm(x, max_components=max_components, random_state=random_state)
    z = scaler.transform(x)
    distances: list[float] = []
    width = min(max(5, reference_window), max(5, x.shape[0] // 2))
    for start in range(0, max(1, x.shape[0] - width + 1)):
        subset = z[start : start + width]
        if subset.shape[0] < 5:
            continue
        current = BayesianGaussianMixture(
            n_components=min(benchmark.n_components, subset.shape[0]),
            weight_concentration_prior_type="dirichlet_process",
            covariance_type="full",
            reg_covar=1e-6,
            max_iter=500,
            random_state=random_state + start + 1,
        ).fit(subset)
        distances.append(symmetric_kl(benchmark, current, samples=1000, random_state=random_state + start))
    threshold = float(np.quantile(distances or [0.0], threshold_quantile))
    return DPMMArtifact(
        scaler=scaler,
        benchmark=benchmark,
        threshold=threshold,
        feature_names=list(feature_names),
        metadata={
            "method": "Dirichlet-process Bayesian Gaussian mixture + symmetric Monte-Carlo KL",
            "healthy_samples": int(x.shape[0]),
            "feature_count": int(x.shape[1]),
            "threshold_quantile": float(threshold_quantile),
            "reference_window": int(width),
        },
    )


def evaluate_dpmm(artifact: DPMMArtifact, current_features: np.ndarray, *, random_state: int = 42) -> dict[str, Any]:
    x = np.asarray(current_features, dtype=np.float64)
    if x.ndim == 1:
        x = x.reshape(1, -1)
    if x.shape[1] != len(artifact.feature_names):
        raise ValueError("current DPMM feature count does not match artifact")
    if x.shape[0] < 5:
        # Repeat is not statistically ideal; caller should accumulate windows.
        return {
            "status": "insufficient_data",
            "required_windows": 5,
            "available_windows": int(x.shape[0]),
            "threshold": float(artifact.threshold),
        }
    z = artifact.scaler.transform(x)
    current = BayesianGaussianMixture(
        n_components=min(artifact.benchmark.n_components, x.shape[0]),
        weight_concentration_prior_type="dirichlet_process",
        covariance_type="full",
        reg_covar=1e-6,
        max_iter=500,
        random_state=random_state,
    ).fit(z)
    divergence = symmetric_kl(artifact.benchmark, current, samples=3000, random_state=random_state)
    return {
        "status": "ok",
        "symmetric_kl": float(divergence),
        "threshold": float(artifact.threshold),
        "anomaly_detected": bool(divergence > artifact.threshold),
        "margin": float(divergence - artifact.threshold),
        "active_components_benchmark": int(np.sum(artifact.benchmark.weights_ > 0.01)),
        "active_components_current": int(np.sum(current.weights_ > 0.01)),
    }


def save_artifact(artifact: DPMMArtifact, path: str | Path) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(artifact, output)


def load_artifact(path: str | Path) -> DPMMArtifact:
    obj = joblib.load(Path(path))
    if not isinstance(obj, DPMMArtifact):
        raise TypeError("invalid DPMM artifact")
    return obj
