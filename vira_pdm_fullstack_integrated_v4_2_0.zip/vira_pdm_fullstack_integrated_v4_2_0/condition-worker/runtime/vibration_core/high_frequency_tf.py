from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import joblib
import numpy as np
from scipy import signal

from .common import EPS, finite_array


def _frequency_grid(low_hz: float, high_hz: float, bins: int) -> np.ndarray:
    if bins < 2 or low_hz <= 0 or high_hz <= low_hz:
        raise ValueError("invalid WISTFT frequency grid")
    return np.linspace(float(low_hz), float(high_hz), int(bins), dtype=np.float64)


def wistft(values: Sequence[float] | np.ndarray, fs: float, *, low_hz: float, high_hz: float, bins: int = 128, z_periods: float = 2.0, hop_samples: int | None = None) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Discrete WISTFT based on a frequency-dependent rectangular window.

    For each analyzed frequency f, the window length is round(z*fs/f), matching
    the paper's frequency-period dependent rectangular window. The complex
    exponential is mixed to baseband and rectangularly integrated.
    """
    x = finite_array(values)
    fs = float(fs)
    if fs <= 0:
        raise ValueError("fs must be positive")
    high_hz = min(float(high_hz), fs * 0.499)
    frequencies = _frequency_grid(low_hz, high_hz, bins)
    hop = int(hop_samples or max(1, round(fs * 0.002)))
    time_indices = np.arange(0, x.size, hop, dtype=int)
    t = np.arange(x.size, dtype=np.float64) / fs
    result = np.empty((frequencies.size, time_indices.size), dtype=np.complex128)

    for row, f in enumerate(frequencies):
        window_len = max(3, int(round(float(z_periods) * fs / f)))
        mixed = x * np.exp(-1j * 2.0 * np.pi * f * t)
        # Discrete form of X(t,f)=(f/z)∫[t-z/f,t]x(τ)e^-j2πfτ dτ.
        # A causal rectangular FIR preserves the paper's trailing window; the
        # 1/fs term is the discrete integration increment.
        kernel = np.ones(window_len, dtype=np.float64) * (f / (float(z_periods) * fs))
        integrated = signal.lfilter(kernel, [1.0], mixed)
        result[row] = integrated[time_indices]
    return time_indices.astype(np.float64) / fs, frequencies, result


def morlet_tf(values: Sequence[float] | np.ndarray, fs: float, *, frequencies: Sequence[float], cycles: float = 6.0, hop_samples: int | None = None) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    x = finite_array(values)
    freq = np.asarray(frequencies, dtype=np.float64)
    hop = int(hop_samples or max(1, round(fs * 0.002)))
    time_indices = np.arange(0, x.size, hop, dtype=int)
    out = np.empty((freq.size, time_indices.size), dtype=np.complex128)
    for i, f in enumerate(freq):
        sigma_t = cycles / (2.0 * np.pi * f)
        half = max(8, int(round(4.0 * sigma_t * fs)))
        tau = np.arange(-half, half + 1, dtype=np.float64) / fs
        wavelet = np.exp(1j * 2.0 * np.pi * f * tau) * np.exp(-(tau * tau) / (2.0 * sigma_t * sigma_t))
        wavelet /= np.sqrt(np.sum(np.abs(wavelet) ** 2) + EPS)
        conv = signal.fftconvolve(x, np.conjugate(wavelet[::-1]), mode="same")
        out[i] = conv[time_indices]
    return time_indices.astype(np.float64) / fs, freq, out


def hfba_feature_vector(tf_coefficients: np.ndarray, time_s: np.ndarray, *, output_bins: int = 500, max_output_hz: float = 1000.0) -> dict[str, np.ndarray | float]:
    coeff = np.asarray(tf_coefficients)
    if coeff.ndim != 2:
        raise ValueError("tf_coefficients must be frequency x time")
    hfba = np.sum(np.abs(coeff), axis=0)
    if hfba.size < 4:
        raise ValueError("HFBA time series is too short")
    dt = float(np.median(np.diff(time_s))) if len(time_s) > 1 else 1.0
    fa = np.abs(np.fft.rfft(hfba - np.mean(hfba)))
    ff = np.fft.rfftfreq(hfba.size, d=dt)
    mask = (ff > 0.0) & (ff <= max_output_hz)
    selected = fa[mask]
    selected_freq = ff[mask]
    if selected.size >= output_bins:
        fv = selected[:output_bins]
        fvf = selected_freq[:output_bins]
    else:
        fv = np.pad(selected, (0, output_bins - selected.size))
        fvf = np.pad(selected_freq, (0, output_bins - selected_freq.size), constant_values=np.nan)
    nfv = fv / (np.max(np.abs(fv)) + EPS)
    peak = int(np.argmax(nfv))
    return {
        "hfba": hfba,
        "feature_vector": fv,
        "normalized_feature_vector": nfv,
        "feature_frequencies_hz": fvf,
        "peak_frequency_hz": float(fvf[peak]) if np.isfinite(fvf[peak]) else 0.0,
        "peak_normalized_amplitude": float(nfv[peak]),
    }


def extract_wistft_and_wavelet_features(values: Sequence[float] | np.ndarray, fs: float, *, segment_seconds: float = 0.5, high_band_hz: tuple[float, float] = (3000.0, 8000.0), tf_bins: int = 128, output_bins: int = 500) -> dict[str, object]:
    x = finite_array(values)
    n = min(x.size, max(16, int(round(segment_seconds * fs))))
    x = x[:n]
    low, high = high_band_hz
    high = min(high, fs * 0.49)
    low = min(low, high * 0.8)
    if low <= 0 or high <= low:
        raise ValueError("sampling rate is too low for configured high-frequency band")

    tw, fw, xw = wistft(x, fs, low_hz=low, high_hz=high, bins=tf_bins)
    wfeat = hfba_feature_vector(xw, tw, output_bins=output_bins)
    tc, fc, xc = morlet_tf(x, fs, frequencies=fw)
    cfeat = hfba_feature_vector(xc, tc, output_bins=output_bins)
    return {
        "segment_samples": int(n),
        "segment_seconds": float(n / fs),
        "high_band_hz": [float(low), float(high)],
        "wistft": wfeat,
        "morlet": cfeat,
    }


def predict_svm(feature_vector: Sequence[float], model_path: str | Path) -> dict[str, object]:
    path = Path(model_path)
    if not path.exists():
        raise FileNotFoundError(path)
    model = joblib.load(path)
    x = np.asarray(feature_vector, dtype=np.float64).reshape(1, -1)
    label = model.predict(x)[0]
    result: dict[str, object] = {"label": str(label), "model_path": str(path.resolve())}
    if hasattr(model, "decision_function"):
        result["decision_function"] = np.asarray(model.decision_function(x)).reshape(-1).astype(float).tolist()
    if hasattr(model, "predict_proba"):
        result["class_probabilities"] = {
            str(c): float(p) for c, p in zip(model.classes_, model.predict_proba(x)[0])
        }
    return result
