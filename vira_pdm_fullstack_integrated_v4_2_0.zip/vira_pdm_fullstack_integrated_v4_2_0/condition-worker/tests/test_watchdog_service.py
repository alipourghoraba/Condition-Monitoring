from __future__ import annotations

import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from condition_service.discovery import build_candidate, provisional_key
from condition_service.state_db import connect, counts_by_status, update_job, upsert_discovered
from condition_service.validation import canonical_fingerprint, validate_metadata


class WatchdogServiceTests(unittest.TestCase):
    def test_schema_template_is_empty_and_complete(self):
        c = sqlite3.connect(ROOT / "database" / "vira_schema_template.db")
        try:
            count = c.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchone()[0]
            self.assertEqual(count, 40)
            self.assertEqual(c.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(c.execute("SELECT COUNT(*) FROM assets").fetchone()[0], 0)
        finally:
            c.close()

    def test_metadata_schema_accepts_core_contract(self):
        metadata = {
            "asset_id": "MOTOR_01",
            "fs": 15000,
            "sensors": {
                "CT_A": {"type": "current"}, "CT_B": {"type": "current"}, "CT_C": {"type": "current"},
                "VIB_radial": {"type": "vibration", "orientation": "radial"},
            },
            "segments": [{"start_ts": 1, "end_ts": 11, "files": {"CT_A": "raw/A.bin", "CT_B": "raw/B.bin", "CT_C": "raw/C.bin", "VIB_radial": "raw/V.bin"}}],
        }
        errors = validate_metadata(metadata, ROOT / "config" / "metadata.schema.json")
        self.assertEqual(errors, [])

    def test_state_db_is_separate_and_persistent(self):
        with tempfile.TemporaryDirectory() as td:
            db = connect(Path(td) / "watchdog.db")
            row = upsert_discovered(db, job_id="job-1", provisional_key="abc", asset_id="M", regime="nominal",
                                    metadata_path=Path("/tmp/meta.json"), bundle_dir=Path("/tmp"), segment_index=0,
                                    segment_start=1, max_attempts=3)
            self.assertEqual(row["status"], "DISCOVERED")
            update_job(db, "job-1", "STABILIZING")
            self.assertEqual(counts_by_status(db)["STABILIZING"], 1)
            self.assertIsNone(db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='processing_runs'").fetchone())
            db.close()

    def test_content_fingerprint_changes_with_channel_hash(self):
        with tempfile.TemporaryDirectory() as td:
            metadata_path = Path(td) / "metadata.json"
            metadata_path.write_text(json.dumps({"asset_id": "M", "fs": 1000, "sensors": {"CT_A":{"type":"current"},"CT_B":{"type":"current"},"CT_C":{"type":"current"}}, "segments": [{"files": {"CT_A":"A","CT_B":"B","CT_C":"C"}}]}), encoding="utf-8")
            base = {"channels": [{"channel": "CT_A", "sha256": "a", "size_bytes": 4}, {"channel": "CT_B", "sha256": "b", "size_bytes": 4}, {"channel": "CT_C", "sha256": "c", "size_bytes": 4}]}
            a = canonical_fingerprint(base, metadata_path, 0)
            base["channels"][2]["sha256"] = "changed"
            b = canonical_fingerprint(base, metadata_path, 0)
            self.assertNotEqual(a, b)


if __name__ == "__main__":
    unittest.main()
