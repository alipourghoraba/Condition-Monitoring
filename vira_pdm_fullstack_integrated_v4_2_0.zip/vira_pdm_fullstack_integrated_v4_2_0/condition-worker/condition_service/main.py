from __future__ import annotations

import argparse
import json
import os
import signal
import sys
import threading
from pathlib import Path

import uvicorn

from .api import create_app
from .bootstrap import ensure_core_database
from .config import WatchdogConfig
from .state_db import connect, counts_by_status, instance_status, list_jobs
from .worker import WatchdogWorker


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Vira v4.1 condition-monitoring watchdog")
    p.add_argument("command", choices=["serve", "watch", "once", "status"], nargs="?", default="serve")
    p.add_argument("--config", default=os.getenv("VIRA_WATCHDOG_CONFIG", "/app/config/watchdog_config.json"))
    p.add_argument("--force-stable", action="store_true", help="testing only: bypass stability waiting in once mode")
    return p


def main(argv=None) -> int:
    args = parser().parse_args(argv)
    config = WatchdogConfig.from_file(args.config)
    ensure_core_database(config)

    if args.command == "status":
        c = connect(config.state_database)
        try:
            print(json.dumps({"jobs": counts_by_status(c), "instances": instance_status(c), "recent": list_jobs(c, limit=20)}, ensure_ascii=False, indent=2))
        finally:
            c.close()
        return 0

    worker = WatchdogWorker(config)
    if args.command == "once":
        try:
            result = worker.scan_once(force_stable=args.force_stable)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        finally:
            worker.close()

    if args.command == "watch":
        def stop_handler(_sig, _frame):
            worker.stop()
        signal.signal(signal.SIGTERM, stop_handler)
        signal.signal(signal.SIGINT, stop_handler)
        worker.run_forever()
        return 0

    thread = threading.Thread(target=worker.run_forever, name="condition-watchdog-worker", daemon=True)
    thread.start()
    app = create_app(config, worker)
    try:
        uvicorn.run(app, host=config.api_host, port=config.api_port, log_level="info")
    finally:
        worker.stop()
        thread.join(timeout=max(5.0, config.poll_seconds + 2.0))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
