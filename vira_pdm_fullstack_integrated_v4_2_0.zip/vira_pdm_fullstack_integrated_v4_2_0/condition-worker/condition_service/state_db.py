from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping


def utc_iso(dt: datetime | None = None) -> str:
    return (dt or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def connect(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(path, timeout=60.0, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA busy_timeout=60000")
    c.execute("PRAGMA foreign_keys=ON")
    ensure_schema(c)
    return c


def ensure_schema(c: sqlite3.Connection) -> None:
    c.executescript(
        """
        CREATE TABLE IF NOT EXISTS watchdog_jobs(
            id TEXT PRIMARY KEY,
            provisional_key TEXT NOT NULL UNIQUE,
            capture_fingerprint TEXT UNIQUE,
            asset_id TEXT,
            operating_regime TEXT,
            metadata_path TEXT NOT NULL,
            bundle_dir TEXT NOT NULL,
            segment_index INTEGER NOT NULL,
            segment_start TEXT,
            run_id TEXT,
            status TEXT NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0,
            max_attempts INTEGER NOT NULL,
            discovered_at TEXT NOT NULL,
            stable_at TEXT,
            queued_at TEXT,
            started_at TEXT,
            finished_at TEXT,
            next_retry_at TEXT,
            worker_id TEXT,
            output_dir TEXT,
            error_code TEXT,
            error_message TEXT,
            preflight_json TEXT,
            post_validation_json TEXT,
            summary_json TEXT,
            updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS ix_watchdog_jobs_status ON watchdog_jobs(status);
        CREATE INDEX IF NOT EXISTS ix_watchdog_jobs_asset ON watchdog_jobs(asset_id, discovered_at);
        CREATE INDEX IF NOT EXISTS ix_watchdog_jobs_retry ON watchdog_jobs(status, next_retry_at);

        CREATE TABLE IF NOT EXISTS watchdog_instances(
            instance_id TEXT PRIMARY KEY,
            hostname TEXT,
            pid INTEGER,
            service_version TEXT NOT NULL,
            core_version TEXT,
            state TEXT NOT NULL,
            current_job_id TEXT,
            started_at TEXT NOT NULL,
            heartbeat_at TEXT NOT NULL,
            lease_expires_at TEXT NOT NULL,
            last_scan_at TEXT,
            config_hash TEXT,
            summary_json TEXT
        );
        """
    )
    c.commit()


def upsert_discovered(c: sqlite3.Connection, *, job_id: str, provisional_key: str, asset_id: str, regime: str,
                      metadata_path: Path, bundle_dir: Path, segment_index: int, segment_start: Any,
                      max_attempts: int) -> sqlite3.Row:
    now = utc_iso()
    c.execute(
        """
        INSERT INTO watchdog_jobs(
          id,provisional_key,asset_id,operating_regime,metadata_path,bundle_dir,segment_index,
          segment_start,status,attempts,max_attempts,discovered_at,updated_at
        ) VALUES(?,?,?,?,?,?,?,?, 'DISCOVERED',0,?,?,?)
        ON CONFLICT(provisional_key) DO UPDATE SET
          asset_id=excluded.asset_id,operating_regime=excluded.operating_regime,
          metadata_path=excluded.metadata_path,bundle_dir=excluded.bundle_dir,
          segment_index=excluded.segment_index,segment_start=excluded.segment_start,
          max_attempts=excluded.max_attempts,updated_at=excluded.updated_at
        """,
        (job_id, provisional_key, asset_id, regime, str(metadata_path), str(bundle_dir), segment_index,
         str(segment_start) if segment_start is not None else None, max_attempts, now, now),
    )
    c.commit()
    return c.execute("SELECT * FROM watchdog_jobs WHERE provisional_key=?", (provisional_key,)).fetchone()


def update_job(c: sqlite3.Connection, job_id: str, status: str, **fields: Any) -> None:
    allowed = {
        "capture_fingerprint", "run_id", "attempts", "stable_at", "queued_at", "started_at", "finished_at",
        "next_retry_at", "worker_id", "output_dir", "error_code", "error_message", "preflight_json",
        "post_validation_json", "summary_json", "operating_regime"
    }
    data: dict[str, Any] = {"status": status, "updated_at": utc_iso()}
    for key, value in fields.items():
        if key not in allowed:
            raise KeyError(key)
        if key.endswith("_json") and value is not None and not isinstance(value, str):
            value = json.dumps(value, ensure_ascii=False, allow_nan=False, default=str)
        data[key] = value
    set_clause = ",".join(f"{k}=?" for k in data)
    c.execute(f"UPDATE watchdog_jobs SET {set_clause} WHERE id=?", (*data.values(), job_id))
    c.commit()


def get_job(c: sqlite3.Connection, job_id: str) -> sqlite3.Row | None:
    return c.execute("SELECT * FROM watchdog_jobs WHERE id=?", (job_id,)).fetchone()


def get_by_provisional(c: sqlite3.Connection, key: str) -> sqlite3.Row | None:
    return c.execute("SELECT * FROM watchdog_jobs WHERE provisional_key=?", (key,)).fetchone()


def get_by_fingerprint(c: sqlite3.Connection, fingerprint: str) -> sqlite3.Row | None:
    return c.execute("SELECT * FROM watchdog_jobs WHERE capture_fingerprint=?", (fingerprint,)).fetchone()


def list_jobs(c: sqlite3.Connection, *, status: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
    limit = max(1, min(int(limit), 1000))
    if status:
        rows = c.execute("SELECT * FROM watchdog_jobs WHERE status=? ORDER BY discovered_at DESC LIMIT ?", (status, limit)).fetchall()
    else:
        rows = c.execute("SELECT * FROM watchdog_jobs ORDER BY discovered_at DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


def counts_by_status(c: sqlite3.Connection) -> dict[str, int]:
    return {str(r[0]): int(r[1]) for r in c.execute("SELECT status,COUNT(*) FROM watchdog_jobs GROUP BY status")}


def retry_due(row: sqlite3.Row) -> bool:
    if str(row["status"]) != "RETRY_WAIT":
        return True
    value = row["next_retry_at"]
    if not value:
        return True
    return datetime.fromisoformat(str(value).replace("Z", "+00:00")) <= datetime.now(timezone.utc)


def schedule_retry(c: sqlite3.Connection, job_id: str, *, attempts: int, delay_seconds: float, error_code: str, error_message: str) -> None:
    next_at = utc_iso(datetime.now(timezone.utc) + timedelta(seconds=max(0.0, delay_seconds)))
    update_job(c, job_id, "RETRY_WAIT", attempts=attempts, next_retry_at=next_at,
               error_code=error_code, error_message=error_message, finished_at=utc_iso())


def claim_instance(c: sqlite3.Connection, *, instance_id: str, hostname: str, pid: int, service_version: str,
                   core_version: str, lease_seconds: float, config_hash: str) -> bool:
    now = datetime.now(timezone.utc)
    now_s = utc_iso(now)
    lease_s = utc_iso(now + timedelta(seconds=lease_seconds))
    row = c.execute("SELECT instance_id,heartbeat_at,lease_expires_at FROM watchdog_instances WHERE instance_id=?", (instance_id,)).fetchone()
    if row is None:
        c.execute(
            "INSERT INTO watchdog_instances(instance_id,hostname,pid,service_version,core_version,state,started_at,heartbeat_at,lease_expires_at,config_hash) VALUES(?,?,?,?,?,'STARTING',?,?,?,?)",
            (instance_id, hostname, pid, service_version, core_version, now_s, now_s, lease_s, config_hash),
        )
    else:
        c.execute("UPDATE watchdog_instances SET hostname=?,pid=?,service_version=?,core_version=?,state='STARTING',heartbeat_at=?,lease_expires_at=?,config_hash=? WHERE instance_id=?",
                  (hostname,pid,service_version,core_version,now_s,lease_s,config_hash,instance_id))
    c.commit()
    return True


def heartbeat(c: sqlite3.Connection, *, instance_id: str, lease_seconds: float, state: str,
              current_job_id: str | None = None, last_scan_at: str | None = None,
              summary: Mapping[str, Any] | None = None) -> None:
    now = datetime.now(timezone.utc)
    c.execute(
        """UPDATE watchdog_instances SET state=?,current_job_id=?,heartbeat_at=?,lease_expires_at=?,
           last_scan_at=COALESCE(?,last_scan_at),summary_json=? WHERE instance_id=?""",
        (state,current_job_id,utc_iso(now),utc_iso(now+timedelta(seconds=lease_seconds)),last_scan_at,
         json.dumps(summary,ensure_ascii=False,default=str) if summary is not None else None,instance_id),
    )
    c.commit()


def instance_status(c: sqlite3.Connection, instance_id: str | None = None) -> list[dict[str, Any]]:
    if instance_id:
        rows = c.execute("SELECT * FROM watchdog_instances WHERE instance_id=?", (instance_id,)).fetchall()
    else:
        rows = c.execute("SELECT * FROM watchdog_instances ORDER BY heartbeat_at DESC").fetchall()
    return [dict(r) for r in rows]


def ensure_lock_schema(c: sqlite3.Connection) -> None:
    c.execute("CREATE TABLE IF NOT EXISTS watchdog_locks(name TEXT PRIMARY KEY, owner_id TEXT NOT NULL, lease_expires_at TEXT NOT NULL)")
    c.commit()


def acquire_lock(c: sqlite3.Connection, *, name: str, owner_id: str, lease_seconds: float) -> bool:
    ensure_lock_schema(c)
    now = datetime.now(timezone.utc)
    row = c.execute("SELECT owner_id,lease_expires_at FROM watchdog_locks WHERE name=?", (name,)).fetchone()
    if row is not None:
        expires = datetime.fromisoformat(str(row["lease_expires_at"]).replace("Z", "+00:00"))
        if str(row["owner_id"]) != owner_id and expires > now:
            return False
    c.execute(
        "INSERT INTO watchdog_locks(name,owner_id,lease_expires_at) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET owner_id=excluded.owner_id,lease_expires_at=excluded.lease_expires_at",
        (name, owner_id, utc_iso(now + timedelta(seconds=lease_seconds))),
    )
    c.commit()
    return True


def renew_lock(c: sqlite3.Connection, *, name: str, owner_id: str, lease_seconds: float) -> bool:
    now = datetime.now(timezone.utc)
    cur = c.execute("UPDATE watchdog_locks SET lease_expires_at=? WHERE name=? AND owner_id=?",
                    (utc_iso(now + timedelta(seconds=lease_seconds)), name, owner_id))
    c.commit()
    return cur.rowcount == 1


def release_lock(c: sqlite3.Connection, *, name: str, owner_id: str) -> None:
    c.execute("DELETE FROM watchdog_locks WHERE name=? AND owner_id=?", (name, owner_id))
    c.commit()
