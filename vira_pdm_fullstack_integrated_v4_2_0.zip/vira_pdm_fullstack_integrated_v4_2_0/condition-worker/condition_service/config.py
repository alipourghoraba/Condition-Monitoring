from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


def _path(value: str | None, base: Path) -> Path | None:
    if value is None or not str(value).strip():
        return None
    p = Path(str(value)).expanduser()
    return p.resolve() if p.is_absolute() else (base / p).resolve()


def _mapping_paths(raw: dict[str, Any] | None, base: Path) -> dict[str, Path]:
    out: dict[str, Path] = {}
    for key, value in (raw or {}).items():
        p = _path(str(value), base)
        if p is not None:
            out[str(key)] = p
    return out


@dataclass(frozen=True)
class WatchdogConfig:
    inbox_dirs: tuple[Path, ...]
    core_database: Path
    database_template: Path
    state_database: Path
    output_dir: Path
    staging_dir: Path
    quarantine_dir: Path
    log_dir: Path
    runtime_dir: Path
    metadata_schema: Path
    fault_scoring_config: Path
    vibration_config: Path
    rul_config: Path

    default_nominal_profile: Path | None = None
    profile_map: dict[str, Path] = field(default_factory=dict)
    profile_map_by_regime: dict[str, dict[str, Path]] = field(default_factory=dict)
    default_vibration_baseline: Path | None = None
    vibration_baseline_map: dict[str, Path] = field(default_factory=dict)
    default_rul_baseline: Path | None = None
    rul_baseline_map: dict[str, Path] = field(default_factory=dict)

    metadata_glob: str = "**/metadata.json"
    poll_seconds: float = 2.0
    file_stability_seconds: float = 3.0
    max_retries: int = 3
    retry_delays_seconds: tuple[float, ...] = (10.0, 30.0, 120.0)
    duration_policy: str = "strict"
    duplicate_policy: str = "strict"
    dtype: str = "auto"
    endian: str = "auto"
    scale_mode: str = "metadata"
    default_operating_regime: str = "nominal-load"
    timezone: str = "UTC"
    store_raw_blob: bool = False
    skip_vibration: bool = False
    skip_rul: bool = False
    skip_energy_if_unconfigured: bool = True
    rated_voltage_v: float | None = None
    voltage_basis: str | None = None
    power_factor: float | None = None
    energy_window_seconds: float | None = None
    plant_id: str | None = None
    zone_id: str | None = None

    api_host: str = "0.0.0.0"
    api_port: int = 8088
    heartbeat_seconds: float = 5.0
    lease_seconds: float = 20.0
    instance_id: str | None = None
    verbose: bool = False

    @classmethod
    def from_file(cls, path: str | Path) -> "WatchdogConfig":
        p = Path(path).resolve()
        raw = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError("watchdog config root must be a JSON object")
        base = p.parent

        inbox_raw = raw.get("inbox_dirs") or ["/data/inbox"]
        if isinstance(inbox_raw, str):
            inbox_raw = [inbox_raw]
        inbox = tuple(x for x in (_path(str(v), base) for v in inbox_raw) if x is not None)
        if not inbox:
            raise ValueError("at least one inbox directory is required")

        by_regime: dict[str, dict[str, Path]] = {}
        for asset, regimes in dict(raw.get("profile_map_by_regime") or {}).items():
            if not isinstance(regimes, dict):
                continue
            resolved = _mapping_paths(regimes, base)
            if resolved:
                by_regime[str(asset)] = resolved

        api = raw.get("api") or {}
        preflight = raw.get("preflight") or {}
        energy = raw.get("energy") or {}

        config = cls(
            inbox_dirs=inbox,
            core_database=_path(str(raw.get("core_database", "/data/db/vira.db")), base),  # type: ignore[arg-type]
            database_template=_path(str(raw.get("database_template", "/app/database/vira_schema_template.db")), base),  # type: ignore[arg-type]
            state_database=_path(str(raw.get("state_database", "/data/state/watchdog.db")), base),  # type: ignore[arg-type]
            output_dir=_path(str(raw.get("output_dir", "/data/outputs")), base),  # type: ignore[arg-type]
            staging_dir=_path(str(raw.get("staging_dir", "/data/staging")), base),  # type: ignore[arg-type]
            quarantine_dir=_path(str(raw.get("quarantine_dir", "/data/quarantine")), base),  # type: ignore[arg-type]
            log_dir=_path(str(raw.get("log_dir", "/data/logs")), base),  # type: ignore[arg-type]
            runtime_dir=_path(str(raw.get("runtime_dir", "/app/runtime")), base),  # type: ignore[arg-type]
            metadata_schema=_path(str(raw.get("metadata_schema", "/app/config/metadata.schema.json")), base),  # type: ignore[arg-type]
            fault_scoring_config=_path(str(raw.get("fault_scoring_config", "/app/config/fault_scoring_config.json")), base),  # type: ignore[arg-type]
            vibration_config=_path(str(raw.get("vibration_config", "/app/config/vibration_config.realtime.json")), base),  # type: ignore[arg-type]
            rul_config=_path(str(raw.get("rul_config", "/app/config/rul_config.json")), base),  # type: ignore[arg-type]
            default_nominal_profile=_path(raw.get("default_nominal_profile"), base),
            profile_map=_mapping_paths(raw.get("profile_map"), base),
            profile_map_by_regime=by_regime,
            default_vibration_baseline=_path(raw.get("default_vibration_baseline"), base),
            vibration_baseline_map=_mapping_paths(raw.get("vibration_baseline_map"), base),
            default_rul_baseline=_path(raw.get("default_rul_baseline"), base),
            rul_baseline_map=_mapping_paths(raw.get("rul_baseline_map"), base),
            metadata_glob=str(raw.get("metadata_glob", "**/metadata.json")),
            poll_seconds=float(raw.get("poll_seconds", 2.0)),
            file_stability_seconds=float(raw.get("file_stability_seconds", 3.0)),
            max_retries=max(1, int(raw.get("max_retries", 3))),
            retry_delays_seconds=tuple(float(v) for v in raw.get("retry_delays_seconds", [10, 30, 120])),
            duration_policy=str(preflight.get("duration_policy", raw.get("duration_policy", "strict"))),
            duplicate_policy=str(preflight.get("duplicate_policy", raw.get("duplicate_policy", "strict"))),
            dtype=str(raw.get("dtype", "auto")),
            endian=str(raw.get("endian", "auto")),
            scale_mode=str(raw.get("scale_mode", "metadata")),
            default_operating_regime=str(raw.get("default_operating_regime", raw.get("operating_regime", "nominal-load"))),
            timezone=str(raw.get("timezone", "UTC")),
            store_raw_blob=bool(raw.get("store_raw_blob", False)),
            skip_vibration=bool(raw.get("skip_vibration", False)),
            skip_rul=bool(raw.get("skip_rul", False)),
            skip_energy_if_unconfigured=bool(raw.get("skip_energy_if_unconfigured", True)),
            rated_voltage_v=_optional_float(energy.get("rated_voltage_v", raw.get("rated_voltage_v"))),
            voltage_basis=energy.get("voltage_basis", raw.get("voltage_basis")),
            power_factor=_optional_float(energy.get("power_factor", raw.get("power_factor"))),
            energy_window_seconds=_optional_float(energy.get("energy_window_seconds", raw.get("energy_window_seconds"))),
            plant_id=raw.get("plant_id"),
            zone_id=raw.get("zone_id"),
            api_host=str(api.get("host", "0.0.0.0")),
            api_port=int(api.get("port", 8088)),
            heartbeat_seconds=float(raw.get("heartbeat_seconds", 5.0)),
            lease_seconds=float(raw.get("lease_seconds", 20.0)),
            instance_id=raw.get("instance_id"),
            verbose=bool(raw.get("verbose", False)),
        )
        config.validate()
        return config

    def validate(self) -> None:
        required_paths = {
            "runtime_dir": self.runtime_dir,
            "database_template": self.database_template,
            "metadata_schema": self.metadata_schema,
            "fault_scoring_config": self.fault_scoring_config,
            "vibration_config": self.vibration_config,
            "rul_config": self.rul_config,
        }
        missing = [f"{name}={path}" for name, path in required_paths.items() if not path.exists()]
        if missing:
            raise FileNotFoundError("missing watchdog/core resources: " + ", ".join(missing))
        if self.poll_seconds <= 0 or self.file_stability_seconds < 0:
            raise ValueError("poll_seconds must be positive and file_stability_seconds non-negative")
        if self.duration_policy not in {"strict", "trim", "use_actual"}:
            raise ValueError("duration_policy must be strict, trim or use_actual")
        if self.duplicate_policy not in {"strict", "warn", "ignore"}:
            raise ValueError("duplicate_policy must be strict, warn or ignore")
        if self.dtype not in {"auto", "float32", "float64"}:
            raise ValueError("dtype must be auto, float32 or float64")
        if self.endian not in {"auto", "little", "big"}:
            raise ValueError("endian must be auto, little or big")
        if self.scale_mode not in {"metadata", "none", "raw"}:
            raise ValueError("scale_mode must be metadata, none or raw")
        if self.api_port <= 0 or self.api_port > 65535:
            raise ValueError("invalid api.port")
        if self.lease_seconds <= self.heartbeat_seconds:
            raise ValueError("lease_seconds must be greater than heartbeat_seconds")


def _optional_float(value: Any) -> float | None:
    if value is None or value == "":
        return None
    return float(value)
