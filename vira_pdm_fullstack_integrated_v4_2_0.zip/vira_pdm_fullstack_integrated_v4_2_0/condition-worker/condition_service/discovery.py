from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Mapping

from .config import WatchdogConfig
from .types import Candidate, StabilityObservation


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def discover_metadata(config: WatchdogConfig) -> list[Path]:
    found: set[Path] = set()
    for inbox in config.inbox_dirs:
        inbox.mkdir(parents=True, exist_ok=True)
        for path in inbox.glob(config.metadata_glob):
            if path.is_file():
                found.add(path.resolve())
    return sorted(found)


def asset_id_from_metadata(metadata: Mapping[str, Any]) -> str:
    return str(metadata.get("asset_id") or metadata.get("motor_id") or metadata.get("id") or "UNKNOWN_ASSET")


def operating_regime(metadata: Mapping[str, Any], default: str) -> str:
    op = metadata.get("operating_condition") or metadata.get("operation") or {}
    if isinstance(op, Mapping) and op.get("regime"):
        return str(op["regime"])
    if metadata.get("operating_regime"):
        return str(metadata["operating_regime"])
    return default


def segments(metadata: Mapping[str, Any], bundle_dir: Path) -> list[dict[str, Any]]:
    explicit = metadata.get("segments") or []
    if explicit:
        if not isinstance(explicit, list):
            raise ValueError("metadata.segments must be a list")
        return [dict(x) for x in explicit if isinstance(x, Mapping)]

    # Keep inference behavior compatible with the uploaded core, but only for
    # the conventional channel_timestamp.bin layout.
    groups: dict[str, dict[str, str]] = {}
    for path in bundle_dir.rglob("*.bin"):
        stem = path.stem
        if "_" not in stem:
            continue
        channel, ts = stem.rsplit("_", 1)
        if not ts.isdigit():
            continue
        if channel in {"CT_A", "CT_B", "CT_C"} or channel.startswith("VIB_") or channel == "ENCODER":
            groups.setdefault(ts, {})[channel] = str(path.relative_to(bundle_dir))
    out: list[dict[str, Any]] = []
    for ts, files in sorted(groups.items()):
        if all(c in files for c in ("CT_A", "CT_B", "CT_C")):
            out.append({"start_ts": int(ts), "end_ts": None, "files": files})
    return out


def resolve_reference(reference: str, bundle_dir: Path) -> Path:
    ref = Path(reference)
    candidates = []
    if ref.is_absolute():
        candidates.append(ref)
    candidates += [bundle_dir / ref, bundle_dir / ref.name, bundle_dir / "raw" / ref.name]
    for p in candidates:
        if p.exists():
            return p.resolve()
    # Return the most likely path even when missing so the caller can classify
    # the candidate as WAITING_FOR_FILES rather than malformed metadata.
    return (bundle_dir / ref).resolve()


def provisional_key(metadata_path: Path, asset_id: str, segment_index: int, segment: Mapping[str, Any]) -> str:
    files = segment.get("files") or {}
    payload = {
        "metadata_path": str(metadata_path.resolve()),
        "asset_id": asset_id,
        "segment_index": int(segment_index),
        "start_ts": segment.get("start_ts"),
        "files": {str(k): str(v) for k, v in sorted(dict(files).items())},
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def build_candidate(config: WatchdogConfig, metadata_path: Path, metadata: Mapping[str, Any], index: int, segment: Mapping[str, Any]) -> Candidate:
    bundle = metadata_path.parent.resolve()
    asset = asset_id_from_metadata(metadata)
    regime = operating_regime(metadata, config.default_operating_regime)
    files = segment.get("files") or {}
    if not isinstance(files, Mapping):
        raise ValueError("segment.files must be an object")
    missing_refs = [c for c in ("CT_A", "CT_B", "CT_C") if not files.get(c)]
    if missing_refs:
        raise ValueError("segment missing required current references: " + ", ".join(missing_refs))
    refs = tuple(resolve_reference(str(v), bundle) for _, v in sorted(files.items()))
    key = provisional_key(metadata_path, asset, index, segment)
    return Candidate(key, metadata_path.resolve(), bundle, int(index), dict(segment), asset, regime, refs)


def all_files_exist(candidate: Candidate) -> bool:
    return bool(candidate.referenced_files) and all(p.exists() and p.is_file() and p.stat().st_size > 0 for p in candidate.referenced_files)


def snapshot(candidate: Candidate) -> tuple[tuple[str, int, int], ...]:
    rows = []
    for p in candidate.referenced_files:
        st = p.stat()
        rows.append((str(p), int(st.st_size), int(st.st_mtime_ns)))
    return tuple(rows)


def stable(candidate: Candidate, observations: dict[str, StabilityObservation], seconds: float) -> bool:
    current = snapshot(candidate)
    now = time.monotonic()
    previous = observations.get(candidate.provisional_key)
    if previous is None or previous.snapshot != current:
        observations[candidate.provisional_key] = StabilityObservation(current, now)
        return seconds <= 0
    return now - previous.unchanged_since >= seconds
