from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any


TERMINAL_STATES = {"COMPLETED", "REJECTED_DATA", "QUARANTINED"}
ACTIVE_STATES = {"PREFLIGHT", "READY", "PROCESSING", "POST_VALIDATING"}


@dataclass(frozen=True)
class Candidate:
    provisional_key: str
    metadata_path: Path
    bundle_dir: Path
    segment_index: int
    segment: dict[str, Any]
    asset_id: str
    operating_regime: str
    referenced_files: tuple[Path, ...]


@dataclass
class StabilityObservation:
    snapshot: tuple[tuple[str, int, int], ...]
    unchanged_since: float


@dataclass(frozen=True)
class PreparedCapture:
    candidate: Candidate
    capture_fingerprint: str
    run_id: str
    staged_archive_dir: Path
    staged_metadata_path: Path
    staged_raw_dir: Path | None
    preflight_report: dict[str, Any]
    nominal_profile: Path
    vibration_baseline: Path | None
    rul_baseline: Path | None
