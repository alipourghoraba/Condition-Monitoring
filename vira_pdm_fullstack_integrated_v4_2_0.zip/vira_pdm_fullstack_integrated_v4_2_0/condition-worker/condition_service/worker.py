from __future__ import annotations

import hashlib
import json
import logging
import os
import platform
import socket
import sqlite3
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from .bootstrap import ensure_core_database
from .config import WatchdogConfig
from .discovery import all_files_exist, build_candidate, discover_metadata, read_json, segments, stable
from .executor import execute
from .state_db import (
    acquire_lock, claim_instance, connect, counts_by_status, get_by_fingerprint, heartbeat, release_lock,
    renew_lock, retry_due, schedule_retry, update_job, upsert_discovered, utc_iso,
)
from .types import StabilityObservation, TERMINAL_STATES
from .validation import DataValidationError, post_validate, preflight_and_stage, validate_metadata

SERVICE_VERSION = "4.1.0-watchdog.1"
CORE_VERSION = "4.1.0"
LOGGER = logging.getLogger("vira.watchdog")


def _short_id(prefix: str, text: str) -> str:
    return f"{prefix}-{hashlib.sha256(text.encode('utf-8')).hexdigest()[:24]}"


def _error_tail(value: str, limit: int = 8000) -> str:
    return value if len(value) <= limit else value[-limit:]


def _configure_logging(config: WatchdogConfig) -> None:
    config.log_dir.mkdir(parents=True, exist_ok=True)
    LOGGER.handlers.clear()
    LOGGER.setLevel(logging.DEBUG if config.verbose else logging.INFO)
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    LOGGER.addHandler(sh)
    fh = logging.FileHandler(config.log_dir / "watchdog.log", encoding="utf-8")
    fh.setFormatter(fmt)
    fh.setLevel(logging.DEBUG)
    LOGGER.addHandler(fh)


def _write_quarantine(config: WatchdogConfig, job_id: str, payload: Mapping[str, Any]) -> Path:
    target = config.quarantine_dir / job_id
    target.mkdir(parents=True, exist_ok=True)
    report = target / "quarantine_report.json"
    report.write_text(json.dumps(dict(payload), ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    return report


class WatchdogWorker:
    def __init__(self, config: WatchdogConfig):
        self.config = config
        _configure_logging(config)
        self.bootstrap = ensure_core_database(config)
        self.db = connect(config.state_database)
        host = socket.gethostname() or platform.node() or "worker"
        self.instance_id = config.instance_id or f"{host}-{os.getpid()}-{uuid.uuid4().hex[:6]}"
        self.stop_event = threading.Event()
        self.observations: dict[str, StabilityObservation] = {}
        config_hash = hashlib.sha256(json.dumps(config.__dict__, default=str, sort_keys=True).encode()).hexdigest()
        claim_instance(self.db, instance_id=self.instance_id, hostname=host, pid=os.getpid(), service_version=SERVICE_VERSION,
                       core_version=CORE_VERSION, lease_seconds=config.lease_seconds, config_hash=config_hash)
        self.has_lock = acquire_lock(self.db, name="condition-monitoring-worker", owner_id=self.instance_id, lease_seconds=config.lease_seconds)
        if not self.has_lock:
            raise RuntimeError("another watchdog instance owns condition-monitoring-worker lease")
        self.last_scan_at: str | None = None
        self.current_job_id: str | None = None

    def close(self) -> None:
        try:
            release_lock(self.db, name="condition-monitoring-worker", owner_id=self.instance_id)
        finally:
            self.db.close()

    def stop(self) -> None:
        self.stop_event.set()

    def _beat(self, state: str, summary: Mapping[str, Any] | None = None) -> None:
        if not renew_lock(self.db, name="condition-monitoring-worker", owner_id=self.instance_id, lease_seconds=self.config.lease_seconds):
            raise RuntimeError("watchdog worker lease was lost")
        heartbeat(self.db, instance_id=self.instance_id, lease_seconds=self.config.lease_seconds, state=state,
                  current_job_id=self.current_job_id, last_scan_at=self.last_scan_at, summary=summary)

    def _job_row(self, candidate) -> sqlite3.Row:
        job_id = _short_id("job", candidate.provisional_key)
        return upsert_discovered(
            self.db, job_id=job_id, provisional_key=candidate.provisional_key, asset_id=candidate.asset_id,
            regime=candidate.operating_regime, metadata_path=candidate.metadata_path, bundle_dir=candidate.bundle_dir,
            segment_index=candidate.segment_index, segment_start=candidate.segment.get("start_ts"), max_attempts=self.config.max_retries,
        )

    def _retry_or_quarantine(self, row: sqlite3.Row, *, error_code: str, error_message: str, detail: Mapping[str, Any] | None = None) -> None:
        attempts = int(row["attempts"] or 0)
        if attempts >= int(row["max_attempts"] or self.config.max_retries):
            report = _write_quarantine(self.config, str(row["id"]), {
                "job_id": row["id"], "asset_id": row["asset_id"], "run_id": row["run_id"],
                "metadata_path": row["metadata_path"], "status": "QUARANTINED", "error_code": error_code,
                "error_message": error_message, "detail": detail or {}, "at": utc_iso(),
                "note": "Source acquisition files were not moved or deleted; quarantine is an audit marker only.",
            })
            update_job(self.db, str(row["id"]), "QUARANTINED", finished_at=utc_iso(), error_code=error_code,
                       error_message=error_message, summary_json={"quarantine_report": str(report), "detail": detail or {}})
            return
        delays = self.config.retry_delays_seconds or (10.0,)
        delay = delays[min(max(attempts - 1, 0), len(delays) - 1)]
        schedule_retry(self.db, str(row["id"]), attempts=attempts, delay_seconds=delay,
                       error_code=error_code, error_message=error_message)

    def scan_once(self, *, force_stable: bool = False) -> dict[str, Any]:
        stats = {
            "metadata": 0, "segments": 0, "waiting_files": 0, "stabilizing": 0, "blocked_profile": 0,
            "rejected": 0, "processed": 0, "completed": 0, "failed": 0, "deduplicated": 0,
        }
        paths = discover_metadata(self.config)
        stats["metadata"] = len(paths)
        for metadata_path in paths:
            try:
                metadata = read_json(metadata_path)
                segs = segments(metadata, metadata_path.parent)
            except Exception as exc:
                LOGGER.error("metadata discovery failed %s: %s", metadata_path, exc)
                continue

            schema_errors = validate_metadata(metadata, self.config.metadata_schema)
            for index, segment in enumerate(segs):
                stats["segments"] += 1
                try:
                    candidate = build_candidate(self.config, metadata_path, metadata, index, segment)
                except Exception as exc:
                    LOGGER.error("candidate build failed %s[%d]: %s", metadata_path, index, exc)
                    continue
                row = self._job_row(candidate)
                job_id = str(row["id"])
                status = str(row["status"])
                if status in TERMINAL_STATES:
                    continue
                if status == "RETRY_WAIT" and not retry_due(row):
                    continue

                if schema_errors:
                    update_job(self.db, job_id, "REJECTED_DATA", finished_at=utc_iso(), error_code="METADATA_SCHEMA_INVALID",
                               error_message="; ".join(schema_errors), summary_json={"schema_errors": schema_errors})
                    _write_quarantine(self.config, job_id, {"schema_errors": schema_errors, "metadata_path": str(metadata_path), "at": utc_iso()})
                    stats["rejected"] += 1
                    continue

                if not all_files_exist(candidate):
                    update_job(self.db, job_id, "WAITING_FOR_FILES", error_code=None, error_message=None)
                    stats["waiting_files"] += 1
                    continue

                if not force_stable and not stable(candidate, self.observations, self.config.file_stability_seconds):
                    update_job(self.db, job_id, "STABILIZING")
                    stats["stabilizing"] += 1
                    continue

                update_job(self.db, job_id, "PREFLIGHT", stable_at=utc_iso(), error_code=None, error_message=None)
                try:
                    prepared = preflight_and_stage(self.config, candidate, job_id)
                except DataValidationError as exc:
                    update_job(self.db, job_id, "REJECTED_DATA", finished_at=utc_iso(), error_code="PREFLIGHT_REJECTED",
                               error_message=str(exc), preflight_json=exc.report)
                    _write_quarantine(self.config, job_id, {"error": str(exc), "preflight": exc.report, "at": utc_iso()})
                    stats["rejected"] += 1
                    continue
                except FileNotFoundError as exc:
                    update_job(self.db, job_id, "BLOCKED_PROFILE", error_code="PROFILE_NOT_FOUND", error_message=str(exc))
                    stats["blocked_profile"] += 1
                    continue
                except Exception as exc:
                    update_job(self.db, job_id, "FAILED", error_code="PREFLIGHT_EXCEPTION", error_message=str(exc))
                    stats["failed"] += 1
                    continue

                duplicate = get_by_fingerprint(self.db, prepared.capture_fingerprint)
                if duplicate is not None and str(duplicate["id"]) != job_id:
                    duplicate_status = str(duplicate["status"])
                    if duplicate_status == "COMPLETED":
                        update_job(self.db, job_id, "COMPLETED", run_id=duplicate["run_id"], finished_at=utc_iso(), output_dir=duplicate["output_dir"],
                                   summary_json={"deduplicated_from_job": duplicate["id"], "capture_fingerprint": prepared.capture_fingerprint})
                        stats["deduplicated"] += 1
                    elif duplicate_status in {"QUARANTINED", "REJECTED_DATA"}:
                        update_job(self.db, job_id, "QUARANTINED", finished_at=utc_iso(), error_code="DUPLICATE_TERMINAL_CAPTURE",
                                   error_message=f"identical capture already ended as {duplicate_status} in job {duplicate['id']}",
                                   summary_json={"duplicate_job": duplicate["id"], "capture_fingerprint": prepared.capture_fingerprint})
                    else:
                        update_job(self.db, job_id, "DUPLICATE_PENDING", error_code="DUPLICATE_IN_PROGRESS",
                                   error_message=f"identical capture is owned by job {duplicate['id']} ({duplicate_status})")
                    continue

                update_job(self.db, job_id, "READY", capture_fingerprint=prepared.capture_fingerprint, run_id=prepared.run_id,
                           preflight_json=prepared.preflight_report, queued_at=utc_iso())
                row = self.db.execute("SELECT * FROM watchdog_jobs WHERE id=?", (job_id,)).fetchone()
                attempts = int(row["attempts"] or 0) + 1
                update_job(self.db, job_id, "PROCESSING", attempts=attempts, started_at=utc_iso(), worker_id=self.instance_id,
                           output_dir=str(self.config.output_dir / prepared.run_id), error_code=None, error_message=None)
                self.current_job_id = job_id
                self._beat("PROCESSING")
                stats["processed"] += 1

                ok, execution_detail = execute(self.config, prepared, self.config.log_dir / f"{prepared.run_id}.log", self.stop_event)
                row = self.db.execute("SELECT * FROM watchdog_jobs WHERE id=?", (job_id,)).fetchone()
                if not ok:
                    message = execution_detail.get("log_tail") or "core pipeline failed"
                    self._retry_or_quarantine(row, error_code="CORE_EXECUTION_FAILED", error_message=_error_tail(str(message)), detail=execution_detail)
                    stats["failed"] += 1
                    self.current_job_id = None
                    continue

                update_job(self.db, job_id, "POST_VALIDATING")
                post = post_validate(self.config, prepared)
                if post["success"]:
                    update_job(self.db, job_id, "COMPLETED", finished_at=utc_iso(), post_validation_json=post,
                               summary_json=execution_detail.get("summary") or {}, error_code=None, error_message=None)
                    stats["completed"] += 1
                    LOGGER.info("completed asset=%s run=%s", candidate.asset_id, prepared.run_id)
                else:
                    row = self.db.execute("SELECT * FROM watchdog_jobs WHERE id=?", (job_id,)).fetchone()
                    self._retry_or_quarantine(row, error_code="POST_VALIDATION_FAILED",
                                              error_message="; ".join(post.get("errors") or ["post validation failed"]), detail=post)
                    stats["failed"] += 1
                self.current_job_id = None

        self.last_scan_at = utc_iso()
        self._beat("IDLE", {"cycle": stats, "jobs": counts_by_status(self.db)})
        return stats

    def run_forever(self) -> None:
        LOGGER.info("watchdog started instance=%s core_db=%s", self.instance_id, self.config.core_database)
        self._beat("IDLE", {"bootstrap": self.bootstrap})
        last_beat = 0.0
        try:
            while not self.stop_event.is_set():
                self.scan_once()
                deadline = time.monotonic() + self.config.poll_seconds
                while not self.stop_event.is_set() and time.monotonic() < deadline:
                    if time.monotonic() - last_beat >= self.config.heartbeat_seconds:
                        self._beat("IDLE", {"jobs": counts_by_status(self.db)})
                        last_beat = time.monotonic()
                    self.stop_event.wait(min(0.5, max(0.0, deadline - time.monotonic())))
        finally:
            try:
                heartbeat(self.db, instance_id=self.instance_id, lease_seconds=1, state="STOPPED",
                          current_job_id=None, last_scan_at=self.last_scan_at, summary={"stopped_at": utc_iso()})
            except Exception:
                pass
            self.close()
