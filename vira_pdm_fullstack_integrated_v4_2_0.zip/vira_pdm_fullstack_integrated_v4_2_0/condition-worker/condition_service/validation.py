from __future__ import annotations

import hashlib
import json
import sqlite3
import sys
from pathlib import Path
from typing import Any, Mapping

from jsonschema import Draft202012Validator

from .config import WatchdogConfig
from .types import Candidate, PreparedCapture


def ensure_runtime_imports(runtime_dir: Path) -> None:
    if str(runtime_dir) not in sys.path:
        sys.path.insert(0, str(runtime_dir))


def validate_metadata(metadata: Mapping[str, Any], schema_path: Path) -> list[str]:
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    validator = Draft202012Validator(schema)
    errors = []
    for error in sorted(validator.iter_errors(metadata), key=lambda e: list(e.absolute_path)):
        loc = ".".join(str(x) for x in error.absolute_path) or "$"
        errors.append(f"{loc}: {error.message}")
    return errors


def canonical_fingerprint(preflight_report: Mapping[str, Any], staged_metadata_path: Path, segment_index: int) -> str:
    metadata = json.loads(staged_metadata_path.read_text(encoding="utf-8"))
    channels = []
    for row in preflight_report.get("channels") or []:
        if isinstance(row, Mapping):
            channels.append({"channel": row.get("channel"), "sha256": row.get("sha256"), "size_bytes": row.get("size_bytes")})
    payload = {"segment_index": int(segment_index), "metadata": metadata, "channels": sorted(channels, key=lambda x: str(x.get("channel")))}
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _resolve_profile(config: WatchdogConfig, asset_id: str, regime: str) -> Path:
    by_regime = config.profile_map_by_regime.get(asset_id) or {}
    profile = by_regime.get(regime) or config.profile_map.get(asset_id) or config.default_nominal_profile
    if profile is None:
        raise FileNotFoundError(f"No nominal profile configured for asset={asset_id}, regime={regime}")
    if not profile.exists():
        raise FileNotFoundError(profile)
    return profile


def _optional_baseline(mapping: dict[str, Path], default: Path | None, asset_id: str) -> Path | None:
    path = mapping.get(asset_id) or default
    if path is not None and not path.exists():
        raise FileNotFoundError(path)
    return path


def preflight_and_stage(config: WatchdogConfig, candidate: Candidate, job_id: str) -> PreparedCapture:
    ensure_runtime_imports(config.runtime_dir)
    from recorded_data_preflight import audit_and_stage  # type: ignore

    stage_dir = config.staging_dir / job_id
    result = audit_and_stage(
        archive_dir=candidate.bundle_dir,
        metadata_path=candidate.metadata_path,
        raw_dir=None,
        segment_index=candidate.segment_index,
        dtype_request=config.dtype,
        endian_request=config.endian,
        duration_policy=config.duration_policy,
        duplicate_policy=config.duplicate_policy,
        staging_dir=stage_dir,
    )
    report = result.to_dict() if hasattr(result, "to_dict") else dict(result.__dict__)
    if not bool(report.get("success")):
        raise DataValidationError("; ".join(report.get("errors") or ["preflight failed"]), report)
    if config.duration_policy == "strict" and not bool(report.get("production_eligible")):
        raise DataValidationError("capture is not production eligible", report)

    staged_metadata = Path(str(report["staged_metadata_path"])).resolve()
    staged_archive = Path(str(report["staged_archive_dir"])).resolve()
    staged_raw_value = report.get("staged_raw_dir")
    staged_raw = Path(str(staged_raw_value)).resolve() if staged_raw_value else None
    fingerprint = canonical_fingerprint(report, staged_metadata, candidate.segment_index)
    safe_asset = "".join(ch if ch.isalnum() or ch in "-_" else "-" for ch in candidate.asset_id)[:40] or "ASSET"
    run_id = f"wd-{safe_asset}-{fingerprint[:16]}"
    return PreparedCapture(
        candidate=candidate,
        capture_fingerprint=fingerprint,
        run_id=run_id,
        staged_archive_dir=staged_archive,
        staged_metadata_path=staged_metadata,
        staged_raw_dir=staged_raw,
        preflight_report=report,
        nominal_profile=_resolve_profile(config, candidate.asset_id, candidate.operating_regime),
        vibration_baseline=_optional_baseline(config.vibration_baseline_map, config.default_vibration_baseline, candidate.asset_id),
        rul_baseline=_optional_baseline(config.rul_baseline_map, config.default_rul_baseline, candidate.asset_id),
    )


class DataValidationError(RuntimeError):
    def __init__(self, message: str, report: Mapping[str, Any] | None = None):
        super().__init__(message)
        self.report = dict(report or {})


def post_validate(config: WatchdogConfig, prepared: PreparedCapture) -> dict[str, Any]:
    ensure_runtime_imports(config.runtime_dir)
    from database_contract import capture_database_counts  # type: ignore

    out = config.output_dir / prepared.run_id
    required = [
        "run_summary.json", "ui_payload.json", "database_payload.json", "database_write_report.json",
        "fault_score_report.json", "vibration_diagnostic_report.json", "rule_based_rul_report.json",
        "energy_report.json", "raw_sensor_manifest.json", "feature_contract_audit.json",
        "mmd_fullstack.csv", "vibration_features.csv", "pipeline.log",
    ]
    missing = [name for name in required if not (out / name).exists()]
    errors: list[str] = []
    if missing:
        errors.append("missing outputs: " + ", ".join(missing))

    summary: dict[str, Any] = {}
    summary_path = out / "run_summary.json"
    if summary_path.exists():
        try:
            summary = json.loads(summary_path.read_text(encoding="utf-8"))
            if summary.get("success") is not True:
                errors.append(f"run_summary.success is not true: {summary.get('success')!r}")
        except Exception as exc:
            errors.append(f"invalid run_summary.json: {exc}")

    db_counts: dict[str, Any] = {}
    integrity = None
    fk: list[Any] = []
    asset_id = prepared.candidate.asset_id
    if config.core_database.exists():
        c = sqlite3.connect(config.core_database, timeout=60.0)
        try:
            c.execute("PRAGMA foreign_keys=ON")
            db_counts = capture_database_counts(c, prepared.run_id, asset_id)
            integrity = c.execute("PRAGMA integrity_check").fetchone()[0]
            fk = c.execute("PRAGMA foreign_key_check").fetchall()
        finally:
            c.close()
        must_be_positive = [
            "asset_count", "sensor_count", "current_sensor_count", "current_sensors_with_features",
            "current_sensors_with_diagnosis", "telemetry_count", "mcsa_analysis_count", "mcsa_feature_count",
            "mcsa_fault_evidence_count", "health_assessment_count", "asset_health_history_count",
            "pipeline_stage_count", "processing_run_count",
        ]
        if not config.skip_rul:
            must_be_positive += ["rul_history_count", "rul_estimate_count"]
        vibration_count = sum(1 for r in prepared.preflight_report.get("channels") or [] if str((r.get("metadata_sensor") or {}).get("type", "")).lower() == "vibration")
        if vibration_count and not config.skip_vibration:
            must_be_positive += ["vibration_analysis_count", "vibration_feature_count", "vibration_method_execution_count"]
        for key in must_be_positive:
            if int(db_counts.get(key) or 0) <= 0:
                errors.append(f"database contract missing {key}")
        if int(db_counts.get("current_sensor_count") or 0) != 3:
            errors.append(f"expected exactly 3 current sensors, found {db_counts.get('current_sensor_count')}")
        if integrity != "ok":
            errors.append(f"SQLite integrity_check={integrity}")
        if fk:
            errors.append(f"foreign-key violations={len(fk)}")
    else:
        errors.append(f"core database does not exist: {config.core_database}")

    return {
        "success": not errors,
        "run_id": prepared.run_id,
        "asset_id": asset_id,
        "output_dir": str(out),
        "missing_outputs": missing,
        "database_counts": db_counts,
        "integrity_check": integrity,
        "foreign_key_violations": [list(x) for x in fk],
        "run_summary": summary,
        "errors": errors,
    }
