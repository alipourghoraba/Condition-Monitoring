from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import PlainTextResponse

from .config import WatchdogConfig
from .state_db import connect, counts_by_status, instance_status, list_jobs


def _decode(row: dict[str, Any]) -> dict[str, Any]:
    for key in ("preflight_json", "post_validation_json", "summary_json"):
        value = row.get(key)
        if isinstance(value, str) and value:
            try:
                row[key] = json.loads(value)
            except Exception:
                pass
    return row


def create_app(config: WatchdogConfig, worker=None) -> FastAPI:
    app = FastAPI(title="Vira Condition Monitoring Watchdog", version="4.1.0-watchdog.1")

    def db():
        return connect(config.state_database)

    @app.get("/health")
    def health():
        return {"status": "ok", "service": "condition-watchdog", "core_version": "4.1.0"}

    @app.get("/ready")
    def ready():
        checks = {
            "core_database": config.core_database.exists(),
            "runtime_pipeline": (config.runtime_dir / "run_condition_monitoring_pipeline.py").exists(),
            "metadata_schema": config.metadata_schema.exists(),
            "state_database_parent": config.state_database.parent.exists(),
        }
        return {"ready": all(checks.values()), "checks": checks}

    @app.get("/status")
    def status():
        c = db()
        try:
            return {
                "jobs": counts_by_status(c),
                "instances": instance_status(c),
                "core_database": str(config.core_database),
                "output_dir": str(config.output_dir),
                "inbox_dirs": [str(p) for p in config.inbox_dirs],
            }
        finally:
            c.close()

    @app.get("/jobs")
    def jobs(status: str | None = None, limit: int = Query(default=100, ge=1, le=1000)):
        c = db()
        try:
            return [_decode(row) for row in list_jobs(c, status=status, limit=limit)]
        finally:
            c.close()

    @app.get("/jobs/{job_id}")
    def job(job_id: str):
        c = db()
        try:
            row = c.execute("SELECT * FROM watchdog_jobs WHERE id=?", (job_id,)).fetchone()
            if row is None:
                raise HTTPException(status_code=404, detail="job not found")
            return _decode(dict(row))
        finally:
            c.close()

    @app.get("/metrics", response_class=PlainTextResponse)
    def metrics():
        c = db()
        try:
            counts = counts_by_status(c)
            lines = ["# TYPE vira_watchdog_jobs gauge"]
            for state, count in sorted(counts.items()):
                lines.append(f'vira_watchdog_jobs{{status="{state}"}} {count}')
            lines.append(f"vira_watchdog_core_database_exists {1 if config.core_database.exists() else 0}")
            return "\n".join(lines) + "\n"
        finally:
            c.close()

    return app
