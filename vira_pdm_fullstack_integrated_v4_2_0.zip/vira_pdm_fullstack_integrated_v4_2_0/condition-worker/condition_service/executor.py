from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path
from threading import Event
from typing import Any, Mapping

from .config import WatchdogConfig
from .types import PreparedCapture


def _metadata_has_energy(metadata: Mapping[str, Any]) -> bool:
    electrical = metadata.get("electrical") or (metadata.get("monitoring_config") or {}).get("electrical") or {}
    if not isinstance(electrical, Mapping):
        return False
    try:
        voltage = electrical.get("rated_voltage_v") or electrical.get("rated_line_voltage_v")
        return float(voltage) > 0 and 0 < float(electrical.get("power_factor")) <= 1
    except (TypeError, ValueError):
        return False


def build_command(config: WatchdogConfig, prepared: PreparedCapture) -> list[str]:
    metadata = json.loads(prepared.staged_metadata_path.read_text(encoding="utf-8"))
    script = config.runtime_dir / "run_condition_monitoring_pipeline.py"
    cmd = [
        sys.executable, str(script),
        "--metadata", str(prepared.staged_metadata_path),
        "--bundle-dir", str(prepared.staged_archive_dir),
        "--database", str(config.core_database),
        "--nominal-profile", str(prepared.nominal_profile),
        "--output-dir", str(config.output_dir),
        "--module-dir", str(config.runtime_dir),
        "--extractor", str(config.runtime_dir / "mcsa_enhanced_agah_algorithms.py"),
        "--config", str(config.fault_scoring_config),
        "--vibration-config", str(config.vibration_config),
        "--rul-config", str(config.rul_config),
        "--segment-index", str(prepared.candidate.segment_index),
        "--dtype", config.dtype,
        "--endian", config.endian,
        "--scale-mode", config.scale_mode,
        "--operating-regime", prepared.candidate.operating_regime,
        "--execution-mode", "production",
        "--diagnostic-validity", "PRODUCTION_CONTRACT",
        "--timezone", config.timezone,
        "--run-id", prepared.run_id,
        "--no-database-backup",
    ]
    if prepared.staged_raw_dir is not None:
        cmd += ["--raw-dir", str(prepared.staged_raw_dir)]
    if prepared.vibration_baseline is not None:
        cmd += ["--vibration-baseline", str(prepared.vibration_baseline)]
    if prepared.rul_baseline is not None:
        cmd += ["--rul-baseline", str(prepared.rul_baseline)]
    if config.skip_vibration:
        cmd.append("--skip-vibration")
    if config.skip_rul:
        cmd.append("--skip-rul")
    if config.store_raw_blob:
        cmd.append("--store-raw-blob")
    if config.plant_id:
        cmd += ["--plant-id", config.plant_id]
    if config.zone_id:
        cmd += ["--zone-id", config.zone_id]

    if config.rated_voltage_v is not None:
        cmd += ["--rated-voltage-v", str(config.rated_voltage_v)]
    if config.voltage_basis:
        cmd += ["--voltage-basis", str(config.voltage_basis)]
    if config.power_factor is not None:
        cmd += ["--power-factor", str(config.power_factor)]
    if config.energy_window_seconds is not None:
        cmd += ["--energy-window-seconds", str(config.energy_window_seconds)]

    configured_by_service = config.rated_voltage_v is not None and config.power_factor is not None
    if config.skip_energy_if_unconfigured and not configured_by_service and not _metadata_has_energy(metadata):
        cmd.append("--skip-energy")
    if config.verbose:
        cmd.append("--verbose")
    return cmd


def _tail(path: Path, max_chars: int = 12000) -> str:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
        return text[-max_chars:]
    except Exception:
        return ""


def execute(config: WatchdogConfig, prepared: PreparedCapture, log_path: Path, stop_event: Event | None = None) -> tuple[bool, dict[str, Any]]:
    command = build_command(config, prepared)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    terminated_by_watchdog = False
    with log_path.open("a", encoding="utf-8") as handle:
        handle.write("$ " + " ".join(command) + "\n")
        handle.flush()
        proc = subprocess.Popen(command, cwd=config.runtime_dir, text=True, stdout=handle, stderr=subprocess.STDOUT)
        while proc.poll() is None:
            if stop_event is not None and stop_event.is_set():
                terminated_by_watchdog = True
                proc.terminate()
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=5)
                break
            time.sleep(0.25)
        returncode = int(proc.returncode if proc.returncode is not None else -999)
        handle.write(f"\nreturncode={returncode}\n")

    summary_path = config.output_dir / prepared.run_id / "run_summary.json"
    summary: dict[str, Any] = {}
    if summary_path.exists():
        try:
            summary = json.loads(summary_path.read_text(encoding="utf-8"))
        except Exception as exc:
            summary = {"success": False, "error": f"could not parse run_summary.json: {exc}"}
    success = returncode == 0 and summary.get("success") is True and not terminated_by_watchdog
    detail = {
        "returncode": returncode,
        "command": command,
        "summary": summary,
        "terminated_by_watchdog": terminated_by_watchdog,
        "log_tail": _tail(log_path),
        "log_path": str(log_path),
    }
    return success, detail
