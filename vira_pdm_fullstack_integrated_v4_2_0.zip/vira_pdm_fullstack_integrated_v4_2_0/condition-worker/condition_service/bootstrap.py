from __future__ import annotations

import shutil
import sqlite3
from pathlib import Path

from .config import WatchdogConfig


def ensure_directories(config: WatchdogConfig) -> None:
    for p in [*config.inbox_dirs, config.core_database.parent, config.state_database.parent, config.output_dir,
              config.staging_dir, config.quarantine_dir, config.log_dir]:
        p.mkdir(parents=True, exist_ok=True)


def _columns(c: sqlite3.Connection, table: str) -> set[str]:
    return {str(row[1]) for row in c.execute(f"PRAGMA table_info({table})")}


def apply_backend_compatibility(c: sqlite3.Connection) -> dict[str, object]:
    """Add only compatibility fields required by the uploaded FastAPI ORM.

    The rule-core v4.1 schema remains authoritative.  The uploaded backend ORM
    maps Sensor.sample_rate, while the rule core stores sample_rate_hz.  SQLite
    does not auto-migrate an existing table through SQLAlchemy create_all(), so
    we keep both representations and synchronize the legacy display field from
    the scientific numeric field.
    """
    changed: list[str] = []
    if "sensors" in {str(r[0]) for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}:
        cols = _columns(c, "sensors")
        if "sample_rate" not in cols:
            c.execute("ALTER TABLE sensors ADD COLUMN sample_rate TEXT")
            changed.append("sensors.sample_rate")
        c.executescript(
            """
            CREATE TRIGGER IF NOT EXISTS trg_sensors_sample_rate_insert
            AFTER INSERT ON sensors
            WHEN NEW.sample_rate_hz IS NOT NULL AND (NEW.sample_rate IS NULL OR NEW.sample_rate='')
            BEGIN
              UPDATE sensors
                 SET sample_rate = printf('%g Hz', NEW.sample_rate_hz)
               WHERE id = NEW.id;
            END;

            CREATE TRIGGER IF NOT EXISTS trg_sensors_sample_rate_update
            AFTER UPDATE OF sample_rate_hz ON sensors
            WHEN NEW.sample_rate_hz IS NOT NULL
            BEGIN
              UPDATE sensors
                 SET sample_rate = printf('%g Hz', NEW.sample_rate_hz)
               WHERE id = NEW.id;
            END;
            """
        )
        c.execute(
            "UPDATE sensors SET sample_rate=printf('%g Hz',sample_rate_hz) "
            "WHERE sample_rate_hz IS NOT NULL AND (sample_rate IS NULL OR sample_rate='')"
        )
    return {"changed": changed}


def ensure_core_database(config: WatchdogConfig) -> dict[str, object]:
    ensure_directories(config)
    created = False
    if not config.core_database.exists():
        shutil.copy2(config.database_template, config.core_database)
        created = True
    c = sqlite3.connect(config.core_database, timeout=60.0)
    try:
        c.execute("PRAGMA foreign_keys=ON")
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA synchronous=NORMAL")
        c.execute("PRAGMA busy_timeout=60000")
        compatibility = apply_backend_compatibility(c)
        integrity = c.execute("PRAGMA integrity_check").fetchone()[0]
        fk = c.execute("PRAGMA foreign_key_check").fetchall()
        tables = c.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchone()[0]
        c.commit()
    finally:
        c.close()
    if integrity != "ok":
        raise RuntimeError(f"core database integrity_check={integrity}")
    if fk:
        raise RuntimeError(f"core database foreign_key_check failed: {fk[:5]}")
    return {
        "created": created,
        "database": str(config.core_database),
        "table_count": int(tables),
        "integrity": integrity,
        "backend_compatibility": compatibility,
    }
