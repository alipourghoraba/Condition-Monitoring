# Production profiles

The v4.1 current/MCSA fault scorer requires a **real healthy nominal profile**. The watchdog intentionally does not fabricate one.

With the supplied `watchdog_config.json`, place the MOTOR_01 profile at:

```text
/data/profiles/MOTOR_01/nominal-load.json
```

which corresponds to this host path when using the default Compose file:

```text
./data/profiles/MOTOR_01/nominal-load.json
```

Optional calibrated artifacts can also be mounted here and referenced from `config/watchdog_config.json`:

- vibration baseline JSON / DPMM artifact paths
- RUL healthy baseline JSON
- trained SVM/FSCNN/supervised model artifacts if enabled and configured

Do not use the same capture being diagnosed as its own production nominal profile.
