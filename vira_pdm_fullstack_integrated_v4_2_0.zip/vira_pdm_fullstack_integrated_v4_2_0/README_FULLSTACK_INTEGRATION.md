# Vira PDM Full-Stack Rule-Core Integration v4.2.0

This kit integrates the validated Vira rule-based condition-monitoring core with the existing FastAPI backend and React/Vite frontend while keeping the scientific algorithms isolated from web application concerns.

## What this package fixes versus the earlier watchdog-only bundle

1. `vira.db` is now the authoritative application + processing database.
2. The watchdog keeps orchestration state in a separate `watchdog.db`.
3. The backend receives read APIs for MCSA, vibration, RUL, health, telemetry, processing runs and watchdog state.
4. The existing backend ORM is made compatible with the core schema (`sensors.sample_rate` legacy field is synchronized from `sample_rate_hz`).
5. A React condition-monitoring page, API client and React Query hooks are supplied.
6. Docker Compose runs **condition-worker + existing FastAPI backend + existing React frontend** against the same persistent DB/output folders.
7. A Windows installer copies the integration files into the actual project at `D:\Fault_Detector\Technical\pdm` and patches the backend router + frontend route.

## Final runtime architecture

```text
DAQ / acquisition software
        |
        v
host capture folder
metadata.json + CT_A/B/C + VIB + optional encoder
        |
        v
condition-worker container
  discovery -> stability -> schema validation -> strict preflight
  -> fingerprint/idempotency -> subprocess rule core -> post-validation
        |
        +--------------------> /data/outputs
        |
        +--------------------> /data/state/watchdog.db
        |
        v
/data/db/vira.db  <---------------- FastAPI backend
        |                              |
        |                              v
        +------------------------ React frontend
```

The browser never writes processing results and never calls the worker directly. The rule core writes diagnostic state; FastAPI reads it; the frontend consumes FastAPI.

## Database ownership

### `vira.db`
Authoritative application + condition-monitoring database. The v4.1 clean template contains 40 tables including:

- application: users, plants, zones, assets, sensors, alerts, work orders, spares, preferences
- current/MCSA: `mcsa_analysis_runs`, `mcsa_feature_values`, `mcsa_fault_evidence`
- vibration: `vibration_analysis_runs`, `vibration_feature_values`, `vibration_fault_evidence`, `vibration_method_executions`, `vibration_model_results`
- health: `health_assessments`, `asset_health_history`
- RUL: `rul_indicator_history`, `rul_component_state`, `rul_estimates`
- orchestration audit: `pipeline_stage_results`, `processing_runs`
- telemetry and energy: `sensor_telemetry`, `energy_records`

### `watchdog.db`
Service-only state:

- `watchdog_jobs`
- `watchdog_instances`
- `watchdog_locks`

This avoids mixing file-watch/retry state with scientific processing records.

## Backend API added by this kit

All routes are mounted below the existing `/v1` prefix and use the existing JWT authentication dependency.

```text
GET /v1/condition/overview
GET /v1/condition/assets/{asset_id}/snapshot
GET /v1/condition/assets/{asset_id}/mcsa
GET /v1/condition/assets/{asset_id}/vibration
GET /v1/condition/assets/{asset_id}/rul
GET /v1/condition/assets/{asset_id}/health
GET /v1/condition/assets/{asset_id}/telemetry/latest
GET /v1/condition/runs
GET /v1/condition/runs/{run_id}
GET /v1/condition/watchdog
GET /v1/condition/watchdog/jobs/{job_id}
```

`/snapshot` returns the latest asset/health/current/vibration/RUL/energy/sensor/processing state in one request so the UI does not need many round trips for the asset detail panel.

## Frontend supplied

The overlay adds:

```text
src/types/condition-monitoring.ts
src/lib/condition-monitoring-api.ts
src/hooks/useConditionMonitoring.ts
src/components/ConditionEngineBadge.tsx
src/pages/ConditionMonitoring.tsx
```

The page displays:

- rule-engine online/offline state
- queue state and processing counts
- plant asset health
- latest MCSA evidence
- vibration evidence
- RUL state and availability
- current/vibration health split
- latest processing run
- active diagnostic evidence

The installer auto-registers `/condition-monitoring` when the local frontend `src/App.tsx` contains React Router `<Routes>...</Routes>`.

## Important source-availability note

The files uploaded to ChatGPT included the frontend package/config/README but not the actual `src/` tree. For that reason this kit cannot preserve or edit every exact existing sidebar/layout component inside the ZIP itself. Instead, `install_into_pdm.py` copies the fully implemented integration source into **your actual local** `pdm-frontend/src` and automatically patches `src/App.tsx` when it matches the documented React Router structure. It never deletes your UI source and creates backups before edits.

The backend source uploaded here included `main.py`, `models.py`, `config.py`, `database.py` and dependencies, but not all router files. The integration therefore adds a self-contained router/service without replacing the existing routers.

## Installation on the real project

Extract this kit anywhere, then in PowerShell:

```powershell
cd <extracted-kit>
.\scripts\install_into_pdm.ps1 -PdmRoot "D:\Fault_Detector\Technical\pdm"
```

The installer expects:

```text
D:\Fault_Detector\Technical\pdm\
  pdm_backend\
  pdm-frontend\
```

It creates/copies:

```text
D:\Fault_Detector\Technical\pdm\
  condition-worker\
  docker-compose.fullstack.yml
  .env.fullstack
```

and patches the backend/frontend in place with backups.

## Configure acquisition and profiles

Edit:

```text
D:\Fault_Detector\Technical\pdm\.env.fullstack
```

Example:

```env
VIRA_INBOX_HOST=D:/Fault_Detector/Data/inbox
VIRA_PROFILES_HOST=D:/Fault_Detector/Data/profiles
VIRA_DB_HOST=D:/Fault_Detector/Data/db
VIRA_STATE_HOST=D:/Fault_Detector/Data/state
VIRA_OUTPUTS_HOST=D:/Fault_Detector/Data/outputs
VIRA_STAGING_HOST=D:/Fault_Detector/Data/staging
VIRA_QUARANTINE_HOST=D:/Fault_Detector/Data/quarantine
VIRA_LOGS_HOST=D:/Fault_Detector/Data/logs
JWT_SECRET_KEY=<strong-random-secret>
VITE_API_URL=http://localhost:8000/v1
VITE_WS_URL=ws://localhost:8000/v1
```

Put healthy nominal profiles under the configured profile folder, for example:

```text
D:/Fault_Detector/Data/profiles/MOTOR_01/nominal-load.json
```

Without a valid nominal profile the watchdog intentionally enters `BLOCKED_PROFILE`; it does not invent a healthy reference.

## Start all three services

From the PDM root:

```powershell
docker compose --env-file .env.fullstack -f docker-compose.fullstack.yml up -d --build
```

or use:

```powershell
<kit>\scripts\run_fullstack.ps1 -PdmRoot "D:\Fault_Detector\Technical\pdm"
```

Services:

```text
Frontend    http://localhost:8080
Backend     http://localhost:8000
API docs    http://localhost:8000/docs
Watchdog    http://localhost:8088
```

After login, open:

```text
http://localhost:8080/condition-monitoring
```

## Validate the deployment

Watchdog:

```powershell
Invoke-RestMethod http://localhost:8088/ready
Invoke-RestMethod http://localhost:8088/status
```

Backend root:

```powershell
Invoke-RestMethod http://localhost:8000/
```

Authenticated condition endpoint:

```text
GET http://localhost:8000/v1/condition/overview
```

Schema compatibility can be checked with:

```powershell
python <kit>\scripts\verify_schema_compatibility.py `
  --database D:\Fault_Detector\Data\db\vira.db `
  --models D:\Fault_Detector\Technical\pdm\pdm_backend\app\models.py
```

Expected result:

```text
PASS: backend ORM is compatible; core tables present; ... integrity=ok
```

## SQLite deployment policy

The current full-stack deployment intentionally keeps SQLite because the v4.1 processing contract and tests are validated against it. The worker runs one processing job at a time. Both worker and backend use the same DB file; the worker enables WAL and `busy_timeout=60000`.

Do not run multiple rule-core writers against the same SQLite DB. PostgreSQL should be a later persistence-adapter project rather than an untested connection-string switch, because the current scientific core uses SQLite-specific persistence.

## Capture lifecycle

```text
DISCOVERED
 -> WAITING_FOR_FILES
 -> STABILIZING
 -> PREFLIGHT
 -> READY
 -> PROCESSING
 -> POST_VALIDATING
 -> COMPLETED
```

Error/exception states:

```text
REJECTED_DATA
BLOCKED_PROFILE
RETRY_WAIT
FAILED
QUARANTINED
```

A processing job is considered complete only after output and DB post-validation; a subprocess return code alone is not enough.

## Scientific semantics retained

- MCSA evidence percentages are diagnostic evidence, not calibrated fault probabilities.
- Vibration evidence scores are multi-method evidence, not calibrated probabilities unless a trained calibrated model explicitly provides one.
- RUL may legitimately be unavailable while a processing run is successful.
- Proxy/maintenance thresholds do not silently become physical end-of-life thresholds.
- Missing trained DPMM/SVM/FSCNN artifacts cause those optional methods to skip rather than fabricate inference.

## Verification performed on this kit

- watchdog service tests: 4 passed
- Python compile check: passed
- backend query smoke test against the clean v4.1 schema: passed
- bootstrap compatibility migration: passed
- clean database has 40 core/application tables and zero seeded processing rows

