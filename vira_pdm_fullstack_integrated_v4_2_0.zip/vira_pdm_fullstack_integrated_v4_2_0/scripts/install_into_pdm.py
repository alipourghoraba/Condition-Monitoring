from __future__ import annotations

import argparse
import json
import re
import shutil
from datetime import datetime
from pathlib import Path


def copy_tree(src: Path, dst: Path) -> list[str]:
    copied=[]
    for p in src.rglob('*'):
        if not p.is_file():
            continue
        rel=p.relative_to(src)
        out=dst/rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p,out)
        copied.append(str(out))
    return copied


def backup(path: Path, backup_root: Path) -> None:
    if not path.exists(): return
    rel=Path(path.name)
    target=backup_root/rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path,target)


def patch_backend_main(path: Path, backup_root: Path) -> bool:
    text=path.read_text(encoding='utf-8')
    if 'condition_monitoring.router' in text:
        return True
    backup(path,backup_root)
    # Independent import avoids touching the existing multi-line router import.
    marker='from app.routers import condition_monitoring\n'
    if marker not in text:
        insert_after='from app.dependencies import ApiError\n'
        if insert_after in text:
            text=text.replace(insert_after,insert_after+marker,1)
        else:
            text=marker+text
    include='app.include_router(condition_monitoring.router, prefix=V1)\n'
    anchor='app.include_router(websockets.router, prefix=V1)\n'
    if anchor in text:
        text=text.replace(anchor,anchor+include,1)
    else:
        root_marker='\n\n@app.get("/", tags=["Health"])'
        text=text.replace(root_marker,'\n'+include+root_marker,1)
    path.write_text(text,encoding='utf-8')
    return 'condition_monitoring.router' in text


def patch_frontend_app(path: Path, backup_root: Path) -> tuple[bool,str]:
    if not path.exists():
        return False,'src/App.tsx not found; overlay files copied but route was not auto-registered.'
    text=path.read_text(encoding='utf-8')
    if 'ConditionMonitoring' in text and '/condition-monitoring' in text:
        return True,'route already present'
    if '</Routes>' not in text:
        return False,'App.tsx does not contain </Routes>; route requires manual registration.'
    backup(path,backup_root)
    imp='import ConditionMonitoring from "@/pages/ConditionMonitoring";\n'
    if imp not in text:
        # Put after final import at the beginning.
        matches=list(re.finditer(r'^import .*?;\s*$',text,re.M))
        pos=matches[-1].end() if matches else 0
        text=text[:pos]+'\n'+imp+text[pos:]
    route='        <Route path="/condition-monitoring" element={<ConditionMonitoring />} />\n'
    text=text.replace('</Routes>',route+'      </Routes>',1)
    path.write_text(text,encoding='utf-8')
    return True,'route /condition-monitoring registered in src/App.tsx'


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--pdm-root',default=r'D:\Fault_Detector\Technical\pdm')
    args=ap.parse_args()
    kit=Path(__file__).resolve().parents[1]
    pdm=Path(args.pdm_root).resolve()
    backend=pdm/'pdm_backend'
    frontend=pdm/'pdm-frontend'
    if not backend.exists() or not frontend.exists():
        raise SystemExit(f'Expected {backend} and {frontend}')
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_root=kit/'backups'/stamp
    backup_root.mkdir(parents=True,exist_ok=True)
    report={'pdm_root':str(pdm),'backend':{},'frontend':{},'docker':{},'backup':str(backup_root)}

    # Backend overlay assumes uploaded project layout app/main.py.
    copied=copy_tree(kit/'backend_overlay'/'app',backend/'app')
    main_py=backend/'app'/'main.py'
    if not main_py.exists() and (backend/'main.py').exists():
        # Defensive support for a flattened checkout.
        (backend/'app').mkdir(exist_ok=True)
        raise SystemExit('Backend appears flattened. Move backend Python files under pdm_backend/app before applying this kit.')
    report['backend']['copied']=copied
    report['backend']['main_patched']=patch_backend_main(main_py,backup_root/'backend')
    shutil.copy2(kit/'deploy'/'Dockerfile.backend',backend/'Dockerfile')
    report['backend']['dockerfile']=str(backend/'Dockerfile')

    # Frontend integration files + route patch.
    copied_front=copy_tree(kit/'frontend_overlay'/'src',frontend/'src')
    ok,msg=patch_frontend_app(frontend/'src'/'App.tsx',backup_root/'frontend')
    shutil.copy2(kit/'deploy'/'Dockerfile.frontend',frontend/'Dockerfile')
    shutil.copy2(kit/'deploy'/'nginx.frontend.conf',frontend/'nginx.conf')
    report['frontend']={'copied':copied_front,'route_patched':ok,'route_message':msg,'dockerfile':str(frontend/'Dockerfile')}

    # Copy compose launcher and env into pdm root so contexts stay simple.
    shutil.copy2(kit/'deploy'/'docker-compose.fullstack.yml',pdm/'docker-compose.fullstack.yml')
    env_target=pdm/'.env.fullstack'
    if not env_target.exists(): shutil.copy2(kit/'deploy'/'.env.fullstack.example',env_target)
    worker_target=pdm/'condition-worker'
    if worker_target.exists(): shutil.rmtree(worker_target)
    shutil.copytree(kit/'condition-worker',worker_target)
    report['docker']={'compose':str(pdm/'docker-compose.fullstack.yml'),'env':str(env_target),'worker':str(worker_target)}

    report_path=kit/'INSTALL_REPORT.json'
    report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
