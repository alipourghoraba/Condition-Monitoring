param([string]$PdmRoot = "D:\Fault_Detector\Technical\pdm")
$ErrorActionPreference = "Stop"
python "$PSScriptRoot\install_into_pdm.py" --pdm-root "$PdmRoot"
Write-Host "Integration overlay installed. Review INSTALL_REPORT.json in the kit folder." -ForegroundColor Green
