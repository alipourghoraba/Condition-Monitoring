from __future__ import annotations

import argparse
import re
import sqlite3
from pathlib import Path


def parse_backend_models(path: Path) -> dict[str, list[str]]:
    lines=path.read_text(encoding='utf-8').splitlines()
    out: dict[str,list[str]]={}
    table=None
    for line in lines:
        m=re.search(r'__tablename__\s*=\s*["\']([^"\']+)',line)
        if m:
            table=m.group(1); out.setdefault(table,[]); continue
        if table:
            m=re.match(r'\s+(\w+):\s+Mapped\[.*?\]\s*=\s*mapped_column\((.*)',line)
            if m:
                attr,rest=m.group(1),m.group(2).strip()
                cm=re.match(r'["\']([^"\']+)["\']',rest)
                out[table].append(cm.group(1) if cm else attr)
    return out


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--database',required=True)
    ap.add_argument('--models',required=True)
    args=ap.parse_args()
    db=sqlite3.connect(args.database)
    try:
        tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
        problems=[]
        for table,cols in parse_backend_models(Path(args.models)).items():
            if table not in tables:
                problems.append(f'missing table: {table}'); continue
            actual={r[1] for r in db.execute(f'PRAGMA table_info({table})')}
            for col in cols:
                if col not in actual: problems.append(f'{table}.{col} missing')
        required={
            'mcsa_analysis_runs','mcsa_feature_values','mcsa_fault_evidence','health_assessments',
            'pipeline_stage_results','vibration_analysis_runs','vibration_feature_values',
            'vibration_fault_evidence','vibration_method_executions','rul_indicator_history',
            'rul_component_state','rul_estimates','processing_runs'
        }
        for table in sorted(required-tables): problems.append(f'core table missing: {table}')
        integrity=db.execute('PRAGMA integrity_check').fetchone()[0]
        fk=db.execute('PRAGMA foreign_key_check').fetchall()
        if integrity!='ok': problems.append(f'integrity_check={integrity}')
        if fk: problems.append(f'foreign_key_check={fk[:5]}')
        if problems:
            print('\n'.join(problems)); return 2
        print(f'PASS: backend ORM is compatible; core tables present; table_count={len(tables)}; integrity=ok')
        return 0
    finally:
        db.close()

if __name__=='__main__': raise SystemExit(main())
