param([string]$PdmRoot = "D:\Fault_Detector\Technical\pdm")
$ErrorActionPreference = "Stop"
Set-Location $PdmRoot
docker compose --env-file .env.fullstack -f docker-compose.fullstack.yml up -d --build
docker compose --env-file .env.fullstack -f docker-compose.fullstack.yml ps
