param([string]$PdmRoot = "D:\Fault_Detector\Technical\pdm")
Set-Location $PdmRoot
docker compose --env-file .env.fullstack -f docker-compose.fullstack.yml down
