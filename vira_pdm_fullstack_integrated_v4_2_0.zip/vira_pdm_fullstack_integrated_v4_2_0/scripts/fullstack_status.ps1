param([string]$PdmRoot = "D:\Fault_Detector\Technical\pdm")
Set-Location $PdmRoot
docker compose --env-file .env.fullstack -f docker-compose.fullstack.yml ps
Write-Host "`nWatchdog:" -ForegroundColor Cyan
try { Invoke-RestMethod http://localhost:8088/status | ConvertTo-Json -Depth 8 } catch { Write-Warning $_ }
Write-Host "`nBackend:" -ForegroundColor Cyan
try { Invoke-RestMethod http://localhost:8000/ | ConvertTo-Json -Depth 8 } catch { Write-Warning $_ }
