from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user, not_found
from app import models
from app.services import condition_queries as q

router = APIRouter(prefix="/condition", tags=["Condition Monitoring"])


def _authorized(_user: models.User = Depends(get_current_user)) -> models.User:
    return _user


@router.get("/overview")
def get_overview(db: Session = Depends(get_db), _user: models.User = Depends(_authorized)):
    result = q.overview(db)
    result["watchdog"] = q.watchdog_status(limit=20)
    return result


@router.get("/assets/{asset_id}/snapshot")
def get_asset_snapshot(asset_id: str, db: Session = Depends(get_db), _user: models.User = Depends(_authorized)):
    result = q.asset_snapshot(db, asset_id)
    if result is None:
        raise not_found("Asset")
    return result


@router.get("/assets/{asset_id}/mcsa")
def get_mcsa(asset_id: str, limit: int = Query(20, ge=1, le=200), db: Session = Depends(get_db), _user: models.User = Depends(_authorized)):
    return q.mcsa_history(db, asset_id, limit)


@router.get("/assets/{asset_id}/vibration")
def get_vibration(asset_id: str, limit: int = Query(20, ge=1, le=200), db: Session = Depends(get_db), _user: models.User = Depends(_authorized)):
    return q.vibration_history(db, asset_id, limit)


@router.get("/assets/{asset_id}/rul")
def get_rul(asset_id: str, limit: int = Query(100, ge=1, le=500), db: Session = Depends(get_db), _user: models.User = Depends(_authorized)):
    return q.rul_history(db, asset_id, limit)


@router.get("/assets/{asset_id}/health")
def get_health(asset_id: str, limit: int = Query(200, ge=1, le=1000), db: Session = Depends(get_db), _user: models.User = Depends(_authorized)):
    return q.health_history(db, asset_id, limit)


@router.get("/assets/{asset_id}/telemetry/latest")
def get_latest_telemetry(asset_id: str, points_per_sensor: int = Query(50, ge=1, le=500), db: Session = Depends(get_db), _user: models.User = Depends(_authorized)):
    return q.latest_telemetry(db, asset_id, points_per_sensor)


@router.get("/runs")
def get_runs(asset_id: str | None = None, status: str | None = None, limit: int = Query(100, ge=1, le=1000), db: Session = Depends(get_db), _user: models.User = Depends(_authorized)):
    return q.processing_runs(db, asset_id=asset_id, status=status, limit=limit)


@router.get("/runs/{run_id}")
def get_run(run_id: str, db: Session = Depends(get_db), _user: models.User = Depends(_authorized)):
    result = q.processing_run(db, run_id)
    if result is None:
        raise not_found("Processing run")
    return result


@router.get("/watchdog")
def get_watchdog(limit: int = Query(50, ge=1, le=500), _user: models.User = Depends(_authorized)):
    return q.watchdog_status(limit=limit)


@router.get("/watchdog/jobs/{job_id}")
def get_watchdog_job(job_id: str, _user: models.User = Depends(_authorized)):
    result = q.watchdog_job(job_id)
    if result is None:
        raise not_found("Watchdog job")
    return result
