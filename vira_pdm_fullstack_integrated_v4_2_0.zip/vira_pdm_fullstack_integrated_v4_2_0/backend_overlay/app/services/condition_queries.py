from __future__ import annotations

import json
import os
import sqlite3
from pathlib import Path
from typing import Any

from sqlalchemy import text
from sqlalchemy.orm import Session


def _row(row) -> dict[str, Any] | None:
    return dict(row._mapping) if row is not None else None


def _rows(result) -> list[dict[str, Any]]:
    return [dict(r._mapping) for r in result]


def _decode(value: Any) -> Any:
    if not isinstance(value, str) or not value:
        return value
    try:
        return json.loads(value)
    except Exception:
        return value


def _decode_fields(item: dict[str, Any] | None, *names: str) -> dict[str, Any] | None:
    if item is None:
        return None
    for name in names:
        if name in item:
            item[name] = _decode(item[name])
    return item


def overview(db: Session) -> dict[str, Any]:
    asset_summary = _row(db.execute(text("""
        SELECT COUNT(*) AS asset_count,
               SUM(CASE WHEN status='online' OR status='Online' THEN 1 ELSE 0 END) AS online_count,
               AVG(COALESCE(health_score, health)) AS average_health,
               SUM(CASE WHEN COALESCE(health_score,health) < 50 THEN 1 ELSE 0 END) AS critical_count,
               SUM(CASE WHEN COALESCE(health_score,health) >= 50 AND COALESCE(health_score,health) < 80 THEN 1 ELSE 0 END) AS warning_count
          FROM assets
    """)).first()) or {}
    latest_run = _row(db.execute(text("""
        SELECT id,asset_id,run_id,status,started_at,finished_at,output_dir,error,summary_json
          FROM processing_runs ORDER BY COALESCE(finished_at,started_at) DESC LIMIT 1
    """)).first())
    _decode_fields(latest_run, "summary_json")
    latest_health = _rows(db.execute(text("""
        SELECT a.id AS asset_id,a.name,a.type,a.status,
               COALESCE(a.health_score,a.health) AS health_score,a.health_updated_at,a.rul,
               h.current_health_score,h.vibration_health_score,h.overall_health_score,
               h.diagnostic_validity,h.timestamp AS assessment_at
          FROM assets a
          LEFT JOIN health_assessments h ON h.id=(
               SELECT h2.id FROM health_assessments h2 WHERE h2.asset_id=a.id
               ORDER BY h2.timestamp DESC LIMIT 1)
         ORDER BY COALESCE(a.health_score,a.health) ASC, a.name ASC LIMIT 100
    """)))
    active_mcsa = _rows(db.execute(text("""
        SELECT m.asset_id,e.fault_code,e.fault_name,e.severity,e.evidence_pct,e.coverage_pct,
               e.recommended_action,m.timestamp
          FROM mcsa_fault_evidence e JOIN mcsa_analysis_runs m ON m.id=e.analysis_id
         WHERE UPPER(COALESCE(e.severity,'HEALTHY')) <> 'HEALTHY'
         ORDER BY m.timestamp DESC,e.evidence_pct DESC LIMIT 20
    """)))
    active_vib = _rows(db.execute(text("""
        SELECT v.asset_id,e.fault_code,e.fault_name,e.severity,e.evidence_score,e.source_method,
               e.theoretical_frequency_hz,e.matched_frequency_hz,v.timestamp
          FROM vibration_fault_evidence e JOIN vibration_analysis_runs v ON v.id=e.analysis_id
         WHERE UPPER(COALESCE(e.severity,'HEALTHY')) <> 'HEALTHY'
         ORDER BY v.timestamp DESC,e.evidence_score DESC LIMIT 20
    """)))
    rul = _row(db.execute(text("""
        SELECT COUNT(*) AS estimate_count,
               SUM(CASE WHEN rul_available=1 THEN 1 ELSE 0 END) AS available_count,
               MIN(CASE WHEN rul_available=1 THEN rul_median_hours END) AS minimum_rul_hours
          FROM rul_estimates
    """)).first()) or {}
    return {
        "assets": asset_summary,
        "latest_run": latest_run,
        "asset_health": latest_health,
        "active_faults": {"mcsa": active_mcsa, "vibration": active_vib},
        "rul": rul,
    }


def asset_snapshot(db: Session, asset_id: str) -> dict[str, Any] | None:
    asset = _row(db.execute(text("SELECT * FROM assets WHERE id=:id"), {"id": asset_id}).first())
    if asset is None:
        return None
    _decode_fields(asset, "health_details_json")
    health = _row(db.execute(text("""
        SELECT * FROM health_assessments WHERE asset_id=:id ORDER BY timestamp DESC LIMIT 1
    """), {"id": asset_id}).first())
    _decode_fields(health, "details_json")
    mcsa = _row(db.execute(text("""
        SELECT * FROM mcsa_analysis_runs WHERE asset_id=:id ORDER BY timestamp DESC LIMIT 1
    """), {"id": asset_id}).first())
    if mcsa:
        _decode_fields(mcsa, "report_json")
        mcsa["faults"] = _rows(db.execute(text("""
            SELECT fault_code,fault_name,severity,evidence_pct,coverage_pct,triggered_feature_count,
                   expected_feature_count,present_feature_count,recommended_action,details_json
              FROM mcsa_fault_evidence WHERE analysis_id=:aid ORDER BY evidence_pct DESC
        """), {"aid": mcsa["id"]}))
        for f in mcsa["faults"]:
            _decode_fields(f, "details_json")
    vib_analyses = _rows(db.execute(text("""
        SELECT * FROM vibration_analysis_runs WHERE asset_id=:id ORDER BY timestamp DESC LIMIT 8
    """), {"id": asset_id}))
    for a in vib_analyses:
        _decode_fields(a, "report_json")
        a["faults"] = _rows(db.execute(text("""
            SELECT * FROM vibration_fault_evidence WHERE analysis_id=:aid ORDER BY evidence_score DESC
        """), {"aid": a["id"]}))
        for f in a["faults"]:
            _decode_fields(f, "details_json")
    rul = _rows(db.execute(text("""
        SELECT * FROM rul_estimates WHERE asset_id=:id ORDER BY timestamp DESC,component ASC LIMIT 30
    """), {"id": asset_id}))
    for r in rul:
        _decode_fields(r, "reason_codes_json", "indicator_details_json", "trend_diagnostics_json")
    processing = _row(db.execute(text("""
        SELECT * FROM processing_runs WHERE asset_id=:id ORDER BY COALESCE(finished_at,started_at) DESC LIMIT 1
    """), {"id": asset_id}).first())
    _decode_fields(processing, "summary_json")
    energy = _row(db.execute(text("""
        SELECT * FROM energy_records WHERE asset_id=:id ORDER BY timestamp DESC LIMIT 1
    """), {"id": asset_id}).first())
    sensors = _rows(db.execute(text("""
        SELECT id,name,type,channel_index,sample_rate_hz,sample_rate,unit,status,processing_status,
               processing_error,last_processed_at,raw_capture_id,raw_sample_count,raw_duration_seconds
          FROM sensors WHERE asset_id=:id ORDER BY channel_index,id
    """), {"id": asset_id}))
    return {
        "asset": asset,
        "health": health,
        "mcsa": mcsa,
        "vibration": vib_analyses,
        "rul": rul,
        "processing": processing,
        "energy": energy,
        "sensors": sensors,
    }


def mcsa_history(db: Session, asset_id: str, limit: int = 20) -> list[dict[str, Any]]:
    rows = _rows(db.execute(text("""
        SELECT * FROM mcsa_analysis_runs WHERE asset_id=:id ORDER BY timestamp DESC LIMIT :lim
    """), {"id": asset_id, "lim": limit}))
    for item in rows:
        _decode_fields(item, "report_json")
        item["faults"] = _rows(db.execute(text("""
            SELECT * FROM mcsa_fault_evidence WHERE analysis_id=:aid ORDER BY evidence_pct DESC
        """), {"aid": item["id"]}))
        for f in item["faults"]:
            _decode_fields(f, "details_json")
    return rows


def vibration_history(db: Session, asset_id: str, limit: int = 20) -> list[dict[str, Any]]:
    rows = _rows(db.execute(text("""
        SELECT * FROM vibration_analysis_runs WHERE asset_id=:id ORDER BY timestamp DESC LIMIT :lim
    """), {"id": asset_id, "lim": limit}))
    for item in rows:
        _decode_fields(item, "report_json")
        item["faults"] = _rows(db.execute(text("SELECT * FROM vibration_fault_evidence WHERE analysis_id=:id ORDER BY evidence_score DESC"), {"id": item["id"]}))
        item["methods"] = _rows(db.execute(text("SELECT * FROM vibration_method_executions WHERE analysis_id=:id ORDER BY method_name"), {"id": item["id"]}))
        for f in item["faults"]:
            _decode_fields(f, "details_json")
        for m in item["methods"]:
            _decode_fields(m, "features_json", "diagnostics_json")
    return rows


def rul_history(db: Session, asset_id: str, limit: int = 100) -> list[dict[str, Any]]:
    rows = _rows(db.execute(text("""
        SELECT * FROM rul_estimates WHERE asset_id=:id ORDER BY timestamp DESC,component ASC LIMIT :lim
    """), {"id": asset_id, "lim": limit}))
    for item in rows:
        _decode_fields(item, "reason_codes_json", "indicator_details_json", "trend_diagnostics_json")
    return rows


def health_history(db: Session, asset_id: str, limit: int = 200) -> list[dict[str, Any]]:
    rows = _rows(db.execute(text("""
        SELECT * FROM asset_health_history WHERE asset_id=:id ORDER BY COALESCE(timestamp,date) DESC LIMIT :lim
    """), {"id": asset_id, "lim": limit}))
    for item in rows:
        _decode_fields(item, "details_json")
    return rows


def processing_runs(db: Session, asset_id: str | None = None, status: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
    sql = "SELECT * FROM processing_runs WHERE 1=1"
    params: dict[str, Any] = {"lim": limit}
    if asset_id:
        sql += " AND asset_id=:asset_id"
        params["asset_id"] = asset_id
    if status:
        sql += " AND status=:status"
        params["status"] = status
    sql += " ORDER BY COALESCE(finished_at,started_at) DESC LIMIT :lim"
    rows = _rows(db.execute(text(sql), params))
    for item in rows:
        _decode_fields(item, "summary_json")
    return rows


def processing_run(db: Session, run_id: str) -> dict[str, Any] | None:
    item = _row(db.execute(text("SELECT * FROM processing_runs WHERE id=:id OR run_id=:id LIMIT 1"), {"id": run_id}).first())
    _decode_fields(item, "summary_json")
    return item


def latest_telemetry(db: Session, asset_id: str, points_per_sensor: int = 50) -> dict[str, list[dict[str, Any]]]:
    sensors = _rows(db.execute(text("SELECT id,name,type,unit FROM sensors WHERE asset_id=:id ORDER BY channel_index,id"), {"id": asset_id}))
    result: dict[str, list[dict[str, Any]]] = {}
    for sensor in sensors:
        rows = _rows(db.execute(text("""
            SELECT timestamp,offset_seconds,value,unit,capture_id,point_index
              FROM sensor_telemetry WHERE sensor_id=:sid ORDER BY timestamp DESC,point_index DESC LIMIT :lim
        """), {"sid": sensor["id"], "lim": points_per_sensor}))
        rows.reverse()
        result[str(sensor["id"])] = rows
    return result


def watchdog_state_db() -> Path:
    return Path(os.getenv("WATCHDOG_STATE_DB", "/data/state/watchdog.db"))


def watchdog_status(limit: int = 50) -> dict[str, Any]:
    path = watchdog_state_db()
    if not path.exists():
        return {"online": False, "database": str(path), "reason": "watchdog state database not found", "jobs": {}, "instances": [], "recent_jobs": []}
    try:
        c = sqlite3.connect(path, timeout=5.0)
        c.row_factory = sqlite3.Row
        counts = {str(r[0]): int(r[1]) for r in c.execute("SELECT status,COUNT(*) FROM watchdog_jobs GROUP BY status")}
        instances = [dict(r) for r in c.execute("SELECT * FROM watchdog_instances ORDER BY heartbeat_at DESC LIMIT 10")]
        jobs = [dict(r) for r in c.execute("SELECT * FROM watchdog_jobs ORDER BY discovered_at DESC LIMIT ?", (max(1, min(limit, 500)),))]
        for j in jobs:
            for key in ("preflight_json", "post_validation_json", "summary_json"):
                j[key] = _decode(j.get(key))
        return {"online": True, "database": str(path), "jobs": counts, "instances": instances, "recent_jobs": jobs}
    except Exception as exc:
        return {"online": False, "database": str(path), "reason": str(exc), "jobs": {}, "instances": [], "recent_jobs": []}
    finally:
        try:
            c.close()
        except Exception:
            pass


def watchdog_job(job_id: str) -> dict[str, Any] | None:
    path = watchdog_state_db()
    if not path.exists():
        return None
    c = sqlite3.connect(path, timeout=5.0)
    c.row_factory = sqlite3.Row
    try:
        row = c.execute("SELECT * FROM watchdog_jobs WHERE id=?", (job_id,)).fetchone()
        if row is None:
            return None
        item = dict(row)
        for key in ("preflight_json", "post_validation_json", "summary_json"):
            item[key] = _decode(item.get(key))
        return item
    finally:
        c.close()
