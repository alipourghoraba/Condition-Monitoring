# Condition-monitoring service package.
